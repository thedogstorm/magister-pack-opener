// Laat een onverwachte fout zichtbaar zien in plaats van dat er stil niets gebeurt.
(() => {
  const show = m => {
    let e = document.getElementById('mpo-err');
    if (!e) { e = document.createElement('p'); e.id = 'mpo-err'; e.style.cssText = 'color:#ff8a8a;font:12px/1.4 system-ui,sans-serif;margin:10px;'; document.body.append(e); }
    e.textContent = 'Er ging iets mis: ' + m + ' (stuur deze tekst naar support)';
  };
  addEventListener('error', ev => show(ev.message));
  addEventListener('unhandledrejection', ev => show((ev.reason && ev.reason.message) || String(ev.reason)));
})();
