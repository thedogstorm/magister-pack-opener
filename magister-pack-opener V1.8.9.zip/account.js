(() => {
const $ = id => document.getElementById(id);
const S = chrome.storage.local;
const syncUrl = typeof MPO_SYNC_URL === 'string' ? MPO_SYNC_URL.trim() : '';
const site = (typeof MPO_SITE === 'string' && MPO_SITE.trim()) || (syncUrl && new URL(syncUrl).origin) || '';
const ask = m => new Promise(res => chrome.runtime.sendMessage(m, r => res(r || { ok: false, error: (chrome.runtime.lastError || {}).message })));
const mask = c => c.slice(0, 6) + '…' + c.slice(-4);
async function render() {
  $('a-off').hidden = !!syncUrl;
  if (!syncUrl) { $('a-out').hidden = $('a-in').hidden = true; return; }
  const { acct, outbox = [], lastSync, acctErr } = await new Promise(r => S.get(['acct', 'outbox', 'lastSync', 'acctErr'], r));
  $('a-out').hidden = !!acct; $('a-in').hidden = !acct;
  if (site) { $('a-site').href = site; $('a-site').textContent = 'je website'; }
  $('a-err').textContent = acctErr || '';
  if (!acct) return;
  $('a-who').textContent = mask(acct.code);
  $('a-st').textContent = (lastSync ? 'Laatst gesynchroniseerd: ' + new Date(lastSync).toLocaleString('nl-NL') : 'Nog niet gesynchroniseerd') + ' · in wachtrij: ' + outbox.length;
  $('a-det2').checked = !!acct.details;
}
$('a-go').onclick = async () => {
  const m = $('a-msg'); m.textContent = 'Bezig…';
  try {
    const o = new URL(syncUrl).origin + '/*';
    if (!(await chrome.permissions.contains({ origins: [o] })) && !(await chrome.permissions.request({ origins: [o] }))) throw new Error('Zonder toestemming voor ' + new URL(syncUrl).host + ' kan de extensie niet koppelen.');
  } catch (e) { m.textContent = e.message; return; }
  const r = await ask({ type: 'link', code: $('a-code').value, details: $('a-det').checked });
  m.textContent = r.ok ? (r.warn || '') : (r.error || 'Koppelen mislukt.'); if (r.ok) $('a-code').value = '';
  render();
};
$('a-sync').onclick = async () => { $('a-err').textContent = ''; const r = await ask({ type: 'flush' }); if (!r.ok) $('a-err').textContent = r.error || 'Synchroniseren mislukt.'; render(); };
$('a-un').onclick = async () => { await ask({ type: 'unlink' }); render(); };
$('a-det2').onchange = async () => { await ask({ type: 'details', on: $('a-det2').checked }); render(); };
chrome.storage.onChanged.addListener(render);
render();
})();
