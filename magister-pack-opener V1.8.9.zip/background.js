// Sturen van geopende packs naar het account op je website. Doet niets zolang er niet is gekoppeld.
// De website herkent je aan de koppelcode (SP-XXXX-XXXX-XXXX-XXXX), die bij elke synchronisatie meegaat.
importScripts('config.js');
const S = chrome.storage.local;
const get = k => new Promise(r => S.get(k, r));
const set = o => new Promise(r => S.set(o, r));
const url = () => (typeof MPO_SYNC_URL === 'string' ? MPO_SYNC_URL.trim() : '');
const allowed = async () => !!url() && chrome.permissions.contains({ origins: [new URL(url()).origin + '/*'] });
const RARITY = ['Common', 'Rare', 'Legendary', 'Mythic', 'Icon', 'Perfect'];
// Het Magister-id gaat nooit mee: alleen een afgeleid nummer, zodat dezelfde kaart niet dubbel telt.
const hex = async t => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)))].map(b => b.toString(16).padStart(2, '0')).join('');
const normCode = t => { const c = String(t || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); return /^SP[A-Z0-9]{16}$/.test(c) ? 'SP-' + c.slice(2).match(/.{4}/g).join('-') : null; };

async function queue(cards) {
  const { acct, outbox = [] } = await get(['acct', 'outbox']);
  if (!acct) return;
  const m = new Map(outbox.map(c => [c.key, c]));
  cards.forEach(c => m.set(c.key, { ...(m.get(c.key) || {}), ...c }));
  await set({ outbox: [...m.values()] });
}
const fail = (msg, status, detail) => Object.assign(new Error(msg), { status, detail });
let busy = null;
const flush = force => busy || (busy = doFlush(force).finally(() => { busy = null; }));
async function doFlush(force) {
  const { acct, outbox = [] } = await get(['acct', 'outbox']);
  if (!acct || (!outbox.length && !force) || !(await allowed())) return;
  for (let i = 0; i === 0 || i < outbox.length; i += 200) {
    const batch = outbox.slice(i, i + 200), snap = new Map(batch.map(c => [c.key, JSON.stringify(c)]));
    let r;
    try { r = await fetch(url(), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: acct.code, version: chrome.runtime.getManifest().version, cards: batch }) }); }
    catch (e) { throw fail('Geen verbinding met de website.'); }
    if (r.status === 401 || r.status === 403) {
      const msg = 'De website herkent je koppelcode niet (meer). Kopieer op de website je huidige code en koppel opnieuw.';
      await set({ acct: null, outbox: [], acctErr: msg }); throw fail(msg, r.status);
    }
    if (!r.ok) {
      let t = ''; try { const j = await r.json(); t = String(j.error || j.message || '').slice(0, 120); } catch (e) {}
      const msg = 'Synchroniseren mislukt (' + r.status + ')' + (t ? ': ' + t : ''); await set({ acctErr: msg }); throw fail(msg, r.status, t);
    }
    const cur = (await get('outbox')).outbox || [];
    await set({ outbox: cur.filter(c => snap.get(c.key) !== JSON.stringify(c)), lastSync: Date.now(), acctErr: '' });
  }
}
async function link(rawCode, details) {
  if (!url()) throw new Error('De website is nog niet ingesteld (config.js).');
  const code = normCode(rawCode);
  if (!code) throw new Error('Dit lijkt geen koppelcode. Die begint met SP- en heeft vier groepen van vier tekens.');
  if (!(await allowed())) throw new Error('Geen toestemming voor ' + new URL(url()).host + '.');
  await set({ acct: { code, details: !!details, since: Date.now() }, acctErr: '' });
  const cards = [];   // eerder geopende packs: alleen het niveau
  for (const [k, v] of Object.entries(await get(null))) if (/^s\d+$/.test(k)) for (const [id, t] of Object.entries(v)) cards.push({ key: await hex('mpo:' + k.slice(1) + ':' + id), tier: t, rarity: RARITY[t] });
  await queue(cards);
  try { await flush(true); }   // altijd één bericht sturen: zo blijkt meteen of de website de code kent
  catch (e) {
    if (e.status >= 400 && e.status < 500 && e.status !== 429) { await set({ acct: null, outbox: [], acctErr: '' }); throw new Error(e.status === 401 || e.status === 403 ? 'De website herkent deze code niet.' : e.message); }
    return { warn: e.message + ' De packs staan in de wachtrij en worden later verstuurd.' };
  }
  return {};
}
chrome.runtime.onMessage.addListener((m, sender, send) => {
  if (sender.id !== chrome.runtime.id) return;
  (async () => {
    if (m.type === 'card') {
      const { acct } = await get('acct'); if (!acct) return {};
      const c = { key: await hex('mpo:' + m.pid + ':' + m.id), tier: m.tier, rarity: RARITY[m.tier], opened_at: new Date(m.openedAt).toISOString() };
      if (acct.details && m.d) Object.assign(c, { vak: m.d.subject, cijfer: m.d.grade, omschrijving: m.d.desc, weging: m.d.weight });
      await queue([c]); await flush().catch(() => {}); return {};
    }
    if (m.type === 'flush') { await flush(true); return {}; }
    if (m.type === 'link') return link(m.code, m.details);
    if (m.type === 'unlink') { await set({ acct: null, outbox: [], acctErr: '' }); return {}; }   // alleen lokaal; op de website maak je een nieuwe code om de oude te laten vervallen
    if (m.type === 'details') { const { acct } = await get('acct'); if (acct) await set({ acct: { ...acct, details: !!m.on } }); return {}; }
    return {};
  })().then(r => send({ ok: true, ...r }), e => send({ ok: false, error: String(e.message || e) }));
  return true;
});
chrome.runtime.onStartup.addListener(() => flush().catch(() => {}));
