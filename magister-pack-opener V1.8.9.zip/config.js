// Adres van de sync-functie van je Base44-website, bijvoorbeeld 'https://jouwapp.base44.app/functions/syncGrades'.
// Leeg laten = de accountfunctie staat uit en er gaat niets uit de browser naar een server.
const MPO_SYNC_URL = 'https://stormproductionsgroup.base44.app/functions/syncGrades';
// Adres van je website zelf (alleen voor de link "je website" in het tabblad Account). Mag leeg.
const MPO_SITE = '';
