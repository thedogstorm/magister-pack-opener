(() => {
const TIERS = [['common','Common',-1,'#e2474b'],['rare','Rare',5.5,'#cfd6e3'],['legendary','Legendary',7,'#f5a623'],['mythic','Mythic',8.5,'#8a6cff'],['icon','Icon',9.5,'#ffe9a8'],['perfect','Perfect',10,'#f6d675']];
const tierOf = g => TIERS.reduce((k, t, i) => g >= t[2] ? i : k, 0);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = g => g.toFixed(1).replace('.', ',');
const rnd = (a, b) => a + Math.random() * (b - a);
const mono = s => s.replace(/[^a-z]/gi, '').slice(0, 3).toUpperCase();
const fitDesc = t => t.length <= 10 ? 4.4 : t.length <= 18 ? 3.4 : t.length <= 30 ? 2.5 : 1.9;
let logoUrl = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXMAAAEHCAYAAABcCaZFAABKSElEQVR42u29eZRl113f+znDvXVrrq6eW1J3q1vzbFu2bMtgeZ4wlo2H4CQEG1iQ2CQrAfSA90hghSyyksgLEh44BHCAGBtMMM9gY2OD7RjbwrbAkyzJGltSt6Qeq2u8dYdz3h+/vfvse/rcGu9wzr2/r9ZZVV2trnvO2Xt/9/f327/Bi+MYhUKhUBQbvr4ChUKhUDJXKBQKhZK5QqFQKJTMFQqFQqFkrlAoFErm+UFFh1GhUCiZFxujHSZ03RgUCoWSeR+wAlSBsEO/r6pTQtEDTOsrUHQa4QA8w3ONQq+lNijPXIH56v5dAJScnwM0gVXgBPCUEruiSxgDjgA7zHxsmLm3UcFl5+xpYAoYAZ4B7tdXq2ReZFwG/N/AIWAmNdl9873v/Mwl7wYQp97FSeDDwAeUzBVdwCRwGHg78AOIWy8AIkPozQzyjlJ/tnN23MzhBvDnwC8A5/UVK5kXFR5wC3Awg7A9M/G9FGlnqZ4IeBa4Gvg+4Iwh9WWdIooOYo+Zr/8I2GnI3HPmbGzmZJwi7shc7p9HDZGXEbdNqK93uFF0n/m4UTN1R9mkJ77nPKfvXO4iwSyuJnAN8IPAFebn6t9UdAo7gfcCs8Y9EtDqFvRTQsValdYtWDakXXaIf8VYqFfr61UyLzIuMRPbW+P/iVMK3f2zewVmgY0D1wH/zPx7NV0VncAR4J3Afoeo4zZWo7eB3xc7YmTWqH6FknkhsRc4aszNcIMLYK2F0XRIvQzcDrxDlbliGxhxvn8p8BpDvJ5DxluFa33uRFyNCiXzQmLaTOBRQ8CbVTZZKsceQI0aBfV28zkTOlUUW4D1Y7/AqPIDZp6VafV/b2XdBs73HrDP/HlUX7uSedEwaxRJelJvRaG7SskzimrGqPM7kXAyhWIr82ov8E8Q192Yo9Zdt1+T9of0We5A+31orglD4qPoQaiSecFQQXzb+83kjTu08Kwf034/BrwNuMl8nkKxGTSA1wK3GXGQJTbWizNfb87aQ9RZo86124ySeeEUzxhyiu+zPd+jfQ9ZcenjwPORcMWdOl0UmxQcNyLx5FfQGkEVp/7c3CYJWwvgMkepK5TMC3PfJWC3WQSNbf6+mNaQRUgOVT2jzp+j00WxCSIvG1V+i/nez1DgPts7uHfJfNqsB+t+USiZFwITxqQMkTR+G1+eTuX3Nrkg3LjfwFFLY0iG3Rt1yijWIHCLEeAlwMsNyY5wse/bzjkbP+5lzMfNXJPADWYtzOlwKJkXaeEcddROnLEItqJu0n+2G8SIMZVfDFyp00aRgarZ9McR//VPIok85TYiI3bW4HYVum8Ezg627n9XFBxFNccmaPVDBh36ve1S/61ifwdShOshnTqKNebmW4DrkUJYkSH6kTZztRNuFkvme4AlHQJV5kXCuNmI0n5ur0OLox2ZHwZeCdyqU0eRgWVDqO8kcbuMGMXud3G92YCAGR0CJfOiwCZE7ERS+Utkl7rd6ALw1nk37lVGSuTeCvy4WTiTOoUUDo4AP4NU8Ryh1X2Snk/t5ttWBIlV+7uQktCa2q9knnvYSb7HmLCWwLv9HLGz0KaAO4DXAQu6cBQGU8CLgFeRJO+sVX+l0+t4xHzuLjTWXMm8AIgQ3+Be89WnMwdIa5G4uxht9boZJKvvCNuPcVcUH+PAC43FVkIOIa1adit5rmX5dUJsVNDEISXzgqDqqI/QUT9eDz7bpvrbEqQ3m8WrB06KEeD7EfdKBXG/ue6SqIf3sVuHQ8m8KLgUOYi0Psl2kSzrxeWm1bf77+DiQkhupMsI4l65E3G5WHWmGD5FPokUZLvTERm1Nuo52oAV2G7+roeGsQr2tPl8hZJ57jBhFkWYIt9evCu3yUVsVNA7kZh3xfBhCSn38FokmsQtxez1eJ15xmI8gB7MK5nnHDaSZS+9qzEeZSgnV0HtQA68Xm0WkmL48E6kkFaZi33g6Vo/bkOJbpD5KJLUNkNrRqpCyTxXWDFfDyCulnbmabdhF6RN9x8DfgRx/Wgt6eHCu5BQwEnWdvf1al4GRuxMofVZlMxzjBEkTfoyQ+jpBbMeoUdtrnYL0Maup+PXsyorXgW8FclK1eqKg4l0JcIXOGPepLUwm8fFUSrpOPIsS287aDi//2Y6lxWtUDLvOAKjgKZTBNstszVrM7B1YNILchT4x2aB13VaDSQWne93Ae9GKmmOIgePeYCdi7tRt9/QoUimmI/4qHemVJCfmsyugo46uEga5mtIq0/U/v0YEp52Cvi8IfVlnWIDhUNmrK8CXsbah/Gddv2t17Q8NHO0jGRHq5tFlXmuYavSZRFqlpKmCwvKdenEqZ+/BDkQnVEzdyBxDjlY/FHEN227XPl9Xktul6zQiB5Ph0vJPM9m7i5D6F4GwW6UiNM+zY3Uig6M4imT+NHTVoC9t1cgcce2FKkeig7WenkpUgq5mRIT6YzOIHVttj75emc7WX9nC8Jdj7gjR9H+tUrmOcVhozp6fd8xG0vgCBA30C1If9IrSKJwFMXHYeA9xvIqcfFheL9gCb1k7mfKzMMKmtqvZJ5THDGTNCvCxJJuu+iAuM21FWLP+nd1o9ZmkXC1fwGcUGU+MLgG+AnjXqkb4gydOdELwk6r8ay5GJj7OmAsSRUTSua5wwHEX14mf/5Aq9ytn3wGuB34HtR3OQgYQ+rYvxIJkQ0dFWzPUKI+zLmsn/nm/vagiUNK5jnEKBKWaCfoYh/Mx7X8m35qYU8aJfez5nv1WxYbdyDnILOGxEe5uBXcelZgt+ej+/MQOcNRKJnnDvaA0bbeCjMWiJeDe/QcdVRCekC+XRdWYTFlrjcgafIVWnt6blQx93pNh8DlJIegCiXzXJH5pY7CLeXs/lwFZonctgp7L3JwplUVi4c64ie/3ZBiYH5Wy/la8oDrjCWhB6BK5rnDXhIfYLyOCuqHSo8yzO5p5MD2B1H/ZRGxH3g9cvBe4eIEtbych3gZ93WpsSoUSua5U74vRDLwSkim21quDvtsa11eBy9r2qZ7OJYRn/lbSJoXKPILt8cswL9BwktHSGK/Q5I8g9iZa532ja83f9cSFbYj1j60HK6Sec4QGJU0ThJ6lUX4eXy/ZZLaLbbuuar0fMJuwlUkntym7JdTY+rlUJ2n511AcmCrUDLPDcaR4kEVRwWnY8vz8j6zlFMJqWT3RuRgqqpTL5ewtXT2IK6xQxljGTsknpf1E5EdVbNPhYOSeZ4wgRwm2ka5RYzbDswzvAxJB9dQxfxiD/A6xE8+tsZ8y+s8dF1/s2j1RCXzHCFE/JbpZKFux/F2mszLiJvlHUhnIpTUcykcrkWajUwa8VCm1Z3iJoflxQr0U2RuXZE3cHHtf4WSeV9gFbntem4XUbOA79m29boZeDOt3ZIU+YDt6XolyblMQGtRrTzUYtmIOg/NhqQhsUrmuYCt+nYdElHgs36XoDwicghhEmlq8GLER6tJHfnBq4A7ubjmipfalDfj7vDoDflnVVCcQgrTqd9cybzvCEmK7fupBVZE2D6N44hfdh/qasmLBfgK4LVmfEYcKzDKIPK8KfOI7IzoihEP2qhiCJD3QY6RjLsZWms8w8V+yzxvTNbstQWZpo0KXAZ+Rqdh33EZ8MPA8w2xZx20BxlzM4vYoz4RfpRhOdiQ3h20tr1TqDLvOWqG+GxUQVyQ+25H6LGzyJqG0F+u07Cvihzge4EXIZEsQYbKLaI1aDeV/ea51J2nZN73CbnXmIqd7OnZLyvDvvOSsTZmkOSUozoV+4JlpAn3m8xYtFsj/hbnbi/Pd/w2AuKguRRK5n1FA4mVnaL1EKrIZG5TrX1jdTwP8Z9P6HTsOWaAdyENmksFFwtwsWvHR85l9qIFt5TM+4xZQ3b2QMrtpVgE8k7HwNvQNptEFBsSfzdSmW9Wp2RPMIEcQr8BqVW+k9baOhupgZK3dZxeF7Yf6G4kDFazjpXM+6409pKUHx0EpBtF+8YMfiNS/1zRfQRI85AfNmTXSBFi0ay/tWrEVMzGpVFTSuZ9J75LWDutOu+knUXiMXIAas36EPg+5BBO0X2UkSzPG8xYuH1l/QF6zsg86ziaPKRkngMF5ZrADNhCs884goSPvR54CZrk0U3YNn4/YN77KElTkUGaY02HzMd0TimZ9xs7SGLM077MjdZ3zotCT7tX3DOAMnLI+zzgrcYa0XCyzmMK6fr0W0YgVMzXqM3aWGt+tTu76cf8TNcssiJh1DzbZUgWtWKAEeZ84V02gISWlUXoIUkdo8BrkPj6u3R6dhy2IuINJMXPilqJcyNzzGYcTyNnAwpV5n1T5VcwOMX114vCmTBm/xHgJlVSXcFBJHLIWkfNlIU0CPPLXdM2K3SapLCbHoQqmfcck8bdMCydUmokKdfXGNI5rFN0SxjlYh/xDcDbDOGVzNcmxc4qXg+RIxT2m++185CSec8RGGVuMz+9AXz3rj81dAhoBxLdcjuwS6fpprGSUqGTSEz595r3WePiJJq037xI9fLboeR8HTXz6rxODyXzXmLcmIY7HPUUDfA4pAmjZMzidyG+Tm3Ku7W5bWvIHwFuNURuic3dSAc9OzIwc0jT+pXMew6P5NBmEFV5FpnbUDJ7MDcOPBfpSjStU3XTCEmKtL0HieGfMn83Yv4+GBIy94wwOqpzScm8H+Q2YSaeNyRjkU77bxh3wL9GDkN1EW4O84a034uUtt1LUhMn3RR80OEZcXAA9ZkrmfcYh0kaUrhtuwbZDHbJxaZnTxnz+C4k1V+z+DaOaUPmr0LawNmzl5JDaPGQKHMfab14NXBap4aSea9xkFa/pj/gY5EOK7PJRONIJMZLkAp4ivUxihz0/ShwuSF1L6XIh4XILcrIAbsmoimZ91ypHiGJAR4WpHtG2g5FI8A7gBt1ym4IJSST9rUkbdOatNbGcStYBkOwzivI+YHtq6tQMu8JQnOVGB6/5loEP2JM5DeQJH8osjFirn9Ocs6wzPBErrSbQ2WH0Ms6TZTMe4XLEZ956EzGYRiLdrU8bOOE24C3mJ+5zSy0iFLre3wnkng1S1JkynWttKtmmbaMBumdrCLRLFejDZ4HEnkbVFv4aMaYxz5JRbthJ6gZ827eADwG/HkBNuV+4HuRioijaOSGi7KxWDQJTZV5zzaXKaOoJri42/iwo2IU5w+S1HKxbgSFxJL/kFGfaVdCnOF6GKbQxJKZPwd0miiZ92rSjTkq1I3wiIZ4nDwkbhqkvvutwCuN6azV8ASXm3fyQseqs/Mm1nVOyWxwO837GNEpo2TeTSwgZUoPp1S5N6Rj446PJagAyeb7dyRt5obdZz6KhG6+DgnftO34YofQ0zXxvU1eg4AAaV5dMUJAoWTeVexEohB8VVSZCt2S9x7gZ43CGvZmvYeBtyOhm2NDLADWQt0Igr3m3eihuZJ517GPpLBUkSvWdXvMppHO8tcOsck8Y76+FbiF1ggf17rRA+LW2ua24JhCybyrmHUWZaRD1HbcQrPRvQtJV58YwvcwB7wCeCkX165RIdCKERLXyqVoeKKSeZexE8n8POSQ+bAvyvQY2S45q8Zkfj4SwWFV6jCZzweAf4b4gUskNXysb9xz5s8wK3S7jkLkwPw69ABUybzLmERCE0cKYkX0C9bnWUJ85y9H6rfsHCLFtQuJKb8R6RUbOsRlNzxQN4trqfhIrZ+rGa4yGUrmfcAM4mYJdAGuOWaBIXKrtg4Dd5qvw2DFjCJulX+FhCSmE8vs4bmnZH4BtjbNGIPVW1eRY2U+TnaDXfWft6osHBfCBPB6xOUyDHU3KsDPG0tkHInUyLJeNKLlYgQkCXkKJfOuLdA9SFMGz1GfuihbyclNpPINeZeMq+EdwAsG+B2MkJwTvBGpNWItFXeDi1IiQIVAQuQ+4jfXgm1K5l1V5VeR1I7wubjG9zAT+Vo/twd9z0PC9C4ZwHcwhhz6jgA/TWtfVI1a2fymOE1yaK5QMu/4vVxjlFesanxDbgN3s1s1hPdiJIFm0KIVlpHole831keYUt7xBja/YV/r9iyhYkTTlL4WJfNuYMqoBe2EsjW1bmvZ7EUOQ48M4DM/12xUJVpT9VWZr7/OXTHgIyUhJtBWhErmHcYo4ivHfA0yFKm6W1oVVpRyM9h3NonE6f9jJNKjgkQIFR3PAV6NZHo2SfzkbvegCPWRrzdv7Jq6CikDsaSvRsm80/dxkNZqiXFqsSrWRuSQ+k7gTchB4SzFL5G7A2nM/FrEfTShpL0lWAsmQFxWWnFTybwr93G9IR6NC9447EYXIeF5dRKf6F7gZxDfaFELcVmX28uMKr+SxFfuZnUGzqXzZ20it+vtKNogXMm8S6R0OeIzVxW+/XfpI2cQh42iPVrgZ5kwVsZNxiXQQEolu8pc58zGidy+r93GgtMzKiXzjqkuex9XIYcxPq01WfSAq/3Y2YOt0KjxCq1p7ONIGN8LKF7kwgTiHvq/kA5CtrO8JXj3+bOslbV6qipkTe1CD0CVzDuAFZLwuYox+Wzj3cY6ykJx8ftxC5LFwKJDbu9w1HlRFu8+o8ZfiCST2QgWG16ntUW2LwQmaI3XVyiZbxmrJCn8dsFapRWliCpCoxXauSLcK/3eRpBIkFcaQi/Ku1tGfP7XmGfw2jx7mqBUiW8MIXKwvENfhZJ5p1A25nM5ReLqB90c3OSZyLglPIcIXwfcZiyivGMHUqP8NiTCqZyaqzo3ti8AfCOkptGuQ0rmHcTVJCGJ7fouqvJan8SbzvdulMcuJOHmDYYg8wpLKtcA70XKEoxnWCBsYB7EXOx+GmbyTmfIBkj5hyldT0rmnbyHS9cwnxXrwxJ501m0Pq0Fy6YR//MraK3JkadohioS//wakn6eSsjdI3jrM1cyVzLfNiyRHNUJte0xTJ8npKsrgoR/vtwoMquC8+Z2eR6SvTpunqWJxM9v1NcfZSh5FQfJpp8m8x269pTMOzW5AqR8q6eqfFsqaz03lCXGa5FWawH5K8Z1A1L18ZAzP7ZyYKsH5Be/jzjjZxVD6BoZpGTeEbM6RFL5S7Rm8KmPfHPjGKbeoRtvbaNcPKPEbkUaQe/Jyf2PIqGIb0aqIqati2CNeevWqsmqY67RT9nKPEKiyXYhyUMKJfNtY79RCErY2x/LoI1lY2vcxEhkyH7g3fQ/xrhC4mp7lblqtHYOip2NCJ0nHbHiXGLfbzZSbfCsZL5tRXYpSWafojNj6qfIMJ1QVEYiRd5Lf+OMrTVxC1J/5WqSXIOmc21GWbc7LB1mpe5aam74aoyUfDiom6SS+XZRQgpCjaJ+u24jchRuaAj95UioYr8IfdGM+w8jKftNMxdGUqpc3STdWeuhUeb7lcyVzLeLaSQ7cSylHrIuxdYUutt+z35fIsm6fTdwXR/uz0ZSfC8ShmjbmJVS92xj5b01rI20G0HnS7bF4jvvbZIkZPUISV1zdbcomW8JZeQAxtcF2BO4RFc3yuylSDjgZT2+F9vA+zXm65SZD9b89xwrInTIXePNt0bkZLw7a6GVGIwGJkrmfSbzfWRHLCg6O85pxeqRxJq/Cylq1Ut3Sw3pV/oaQyQlxM3i3l9amSuRdwaRMx/KhtT3GlW+qq9HyXyzGDOTZ2dONpZhUuVu2v9upOnDq5BD0Yke3c8s4ivf3WYjV0ut++veZgiXzTpUQaVkviWMIJEsOwyxK7pP5hZ2AVu1GwDvRJold3NOWEtgJ/CfkRosbjlbNy5+vU0pbWmko3j8da5hHXsvReQ+cmZymVo+SubbWdh7nHvQidRbBA6JhkYpvxKp3dItVA2RvwQ5+Jw2nx045KIHmN0ndS/DStpLMSpqKnJI5mNGmQfrKC5F5xayt84ivxIplfucLt7HlcAPkTQiCVOEvt7Ya9Gt7RF5OsIpMpvqwZT1pCgYwj6qcpvCDeLDVX9dbxd1uujSScT18mrgNPAocL7Dn30pkq5/k5l7rstDN/D+zgnb6UvPrlSZb9rE34H46dr5MFWpd3/s3cuGBu5DDkNvR8rRdlKt3WiUv42c2Mz82+h80Fo+m58HARJ3ruVwlcy39LnTJJEsStb5sNJs7fPLgDvN4t7RIbfG9wBvM+p8vI2FoOjfehxDkocUSuab/twZJCxNU7XzY2rb6Ja9wBuRQ8oKW489niQppPVW5ODTjaLRjTw/PDBtLKcY9ZsrmW8C1qybUTLPBSJnXOycGAfekyLkzWLB/J6XAzcjNUA2mpav6C0qSB15dWsqmW8KVwFX0FprWxd3fxGnvveNQn83W0/1n0LcNz/ijPdImw1ce3b2F7PmWtT3r2S+WWV+yJjcZVXnuZwPPtAA3oIklWw21X/U/PsfA15gFL6NYHHL2mpVxHzAIzkjUWWuZL4pMrfdhUoDqgSKRlJp90cFOaAeQ9LuL2dzqf4rZsN+qSEIWw0x3Q1IkQ8eCM04zZixUiiZbwhuizM16fIzF1xCXzTqehZpM/fCTajzUcQ//h6j6mfUAsv9Rh4gbrEpNDxRyXyDmEA6yuymNfNP0T8Lwi5odxzGEHfIiCHj9wKv3eDvnDb/7/cb033VIQx7aY/XfPGALbZ1tVmXGtGiZL4mbObntCGLyDHxBkmhF+1ZsiIY3J/ZptvXmcU+tc7v2wv8oCGHiK1Hwyh6N/4lWquYKpTM10RolNqss8CLpsrWiraIaG0EUIToDL/NM0ZIA4uGo95fh1RWLK/x+3YCP4C4ZUoUN9Qt3TN0kKNsLJmPIlm/6vpUMt/Q540ZZT4I6jtm402C4wI+m718s9gvQVL91yrEdTNJKd2mGe+YYrvSvDVIvm6uQTgPqCCdv4oospTMe/x580aZpxvI5pno0urMRd18rZqruUkln0eyspUM7Veb4h8a5XY98C/a/J5bgZ9xCMH+vnRRr7T/PMuH3s/aPFHGhm3/3EC6JDXNfc4By23GvmjipIRELTWUGpXMN4I9qcVetAlv0USqCr4f+FtD5g3z8yKaqe2aPaSJdRp4PvCjtEa37EWqId6KHJh6A6rufGf8nwI+BHx7AMjcVi6dREJKVZkrma+LgxSrwJbbPMNtt9ZEYql/H/iAWdhLRrU1uDijsuiqzV3040hm6HPNz6aRlP0fN+qu4aj7or6DOOPPdoMKkVIFfwr8LnCvY6UVEW5jkJ3IQbdGmCmZt8Ukclq+31FuRULkmNxNs6CbwJPAh4EvGTJfpfXQkAFZGK67KASOAv/IbM6XIF2KjpKU0g3aKP6iPrvrZqsj9d//GPgG8LTjmmgWnAumjKtFybxg6GVzigXgsHGxjBRcnVplfookW+53zCb1auCsec4iN9zwM8xwl8xHgdcDDyMREC8lO2Qx7S/3C/Ls6cgk+w5KxiL7NeBBZ6Ovme8btHbx6acVvBmhgjNfdyFus3mlSCXzdpgyJnm54CTXNAr8OEl52K8hvvPnIglRbiTIoIR6uXHnARL98EaSrlE+Fx8aRgUgs42iZkTJl4BPIh2ZAB5Dzk92pZR80cRKYITWZajPXN0sa6BilOtOEn9qkUw5j9bu8fPAIyS+0ingb4D/z/xdlKFMi+xe8Rz15vaTPILUwQ7Nu6ga0osoXjim3XzSWbH2WjUulf+CuNcsThhit2cFjYKOvc38PKhkrmS+3mdNInHHXkHflfu+qkaZu2FcTwKfAO5LkbnHxTHpRawW6HZ3t2Q9QZIcFBd8A8sajybJGciyUeWfpzXdfQk441hiRSNzP7VZh/SvP7CiAGQekfiRlzIUbztFGGeopo1c3Zjs6eSRecfNMo8Up3oA+G1jji9mPE/We8kzqafVqe+8k5ikhovnkEARLa90kpTdnKy1MQ/8HfCLyAFh1fm3TyPRTFm/y9388r552/IalyERS2NKkUrmWagi0Q67SA6L4k1OtLwoU5s8ciq1qEGSSO5FwtZs2dclLk4LL3p6eNpSsX8OKF7xtIjsbF77tWKsrU+YjetkhnpfJDn8LKXmS9HG1YYojqBQMs9AhaQm9jjF9MnZxdkwJP5km01rAfgY8Dmj6MbbqN2iPbuXcrVshOyLUhUxSqly63KIjQvlc+ZaTlmWdj6cdzb2cobqLxInBEi4qRZIUzLPxE7EZ45jvhWN0BqOybwCPNPm/zsH3IMchq6SpHtrPe98u1nS5O6ZjfnLwB8ad0pWHHndzIcq7V1pRdu4d6ubRck8C6NItIc1QZu0ZlbG6yjBfpN+Oub4acQ3vmJ+NpJhktoMwb8wSm7ZeS6/wGY4qftf72rnlsmDEk/X3EnHhVfNxvxnxgpbccYxvRE8bv4fN848oBix5mn3Xwhcy/qljhVDSOY+kjA0Q7GbUTQdZf5tkqiFVZKDUBdngA8i/lZV5vl3s7gkb8f5D40yX1lH1S8hh6CrFD8c1QcuReooKZTML8K1SB3zgOL4y9tFyFgy3wg529jzJTR2tyhroW7G63PGunp0A//2PJINW82wMIvYrOQwUnpjUqeGknn6cy6n+J2/m1zcfGIjeD/wLZLKipv994reEJhbEfE08N+QXIL1fMcREs1yvKDK3D30tfe+C41oKRR6lRjQBG5AfHAh4ncca7Og1lpsG/1/O2VyZ2189kDz9CbuYRX4f5Eoh5cYFTdLaxyyCoHuj+Fac8u6VhpIeOkHgO+asVoPK4iLxTPzuoglHNx6ND5y5rPbrNnTSpW6IC3GDXmVSbrWpEk574RmMzmbyKHY+U0u2E8hmYMnU2STVkSK/owtDpE9A/wRkkcAGwvRs7HmKwUdyzjFByESRqyHoErmFzBtTDarWMIUmeeZyN26JFa5rRhzeomL/aPr4aPAZ8ym5i4eLTfafxeLTds/g1TAPGZ+NrpBco6RaplzJAflblelomxm7juZRn3mSuYpVT7DYNS09pHs1VNsrW71MSTM7RskBbo0wqU/5G3HtOko69PAXwH/02zadvPeyKbdQBLE5mmtZ1+kxClS9zzJYPTrVTLfJkYc8/SGDHWy2VoqvYw7z4qjtgv+JPDEFsl8Bfg68N9J6rbU0MPQfsF2hVo1Y/6wGZsVJGN5eRO/q2o2g29ycXOSomxubuZrGamGeYlOEyVze6pvu7qXHXdFERvG2tKmC4jPfKsdZU4glff+ypBJneL3jyw6YmNtfRHJ3IXNu9Awc+MExY41t+KlYsRYBfGdK4aYzC0B+kiBrQpJ9EyeY2+zVLLbOWYB8Y1uR3mdRZKJHqC1M32W5aKqvXvjbBtsrCLx5B9Gwme3ksZeMRvzGS7O/CySOnd5oWLehdZoUTK/4Gfez8WtuIqIhjG957a5WOeRyoofMr/P+m7dK+1+UkLf/lx0ScuGD64iXaLuAe43VtdW3nXJ+ZwVBiPjNzQWtcaaDzmZ2+L9gdndgzWUQLeV9Ub+/7X+nf35KPAQ4hdd2eZ9rhg1+HXzZ9sIuk5rp3dV5luf267FkyUk5pCziz9Aoozcsdmqi+VhkmqLRRo/Kx6s6LJ+/2kkrFjV+RCTuXVN7EN8bj7FTpLBqOh5OuPjtrU83mcIPd2ZSF0s3Z3rp43I+BMkOWilQ5+zQHZ1xaKMY7qW+5WIm1TDZ4eYzH1jnl1OfxIPOtkEwjajOM/GMgI3iqox7z/okEmZpFPPIDSxyAO8DJVeQWqu/BnSQajaoc86CzxI4i4rIhfYyokBcBXSeUjJfMiVeQWpvuY2oyjipLA+7QWjzDul4kaMS+UvSCorphsoU3BrJg+ugzRsKOJ/J4le6RTOA4+Zzb9IG3GcYT17xqreqfMv/+hmbZZFYC9wsyEtv8ATIjIEsNRBIrekAuJr/bB5T1cifspmDzbcQSbxtIXm5go0gd9Dyiuc7/BnB4gLxx6AxuS/s1Q6A9T6zkvGUtyFJrcNtTLHTIadjtugyOTQQHyhz3bh9y8jdbP/zhkXN6pFVdH2SMpFE3gE+H3gO+ZnneyoUyVJKks3vyjau/OMwLgUCdlUDDGZl5GwxCLUp1hvYjeRmixPdXHD+BPgs8aqWVU1tO0xcxtN2DFcQaJXnkwRfKfQdMjcPfMo4ljadVsyVrZiiMl8BAlrKrKLxSWHUySV9LqBLwIfR0oGWB9mhLpatjpe6XZwNSSW/GO0Ntle7TCZN1KbdBHnvtv6zjcWtiLH6KbPfAZ4DlKsx7aK8za4CNnGAvC2+f9nfb5VKGe7aGHYju+fNUTzK2Yz1FT/jc2XtJUTOxuhVeUPAL+FxIJ3K266icSvP+QQoJ9zZe6l5n2QEnz70RotQ63Mp5zJPAg+3yWj4LpNrmeQBJa/NYtKe4dujZw8xyK0pW0/C/wx4iNf6dJnN81cOYdEKgUUx2fuhnC65XunkUYViiEl8xnEzzYIB3iRWZzzbK6S3lbH5Dzi132M4pdA6AUBZb1DzyHSmtkcbTx/N8fQtgZ8xnyWPcz2C/ge7bucAA6gBbeGksxHjTKfpZgVErPIfA6JM+82bEr/F4GPMBjd3vsFm+y1CHyCpHRCt2FLJdcG5D0GSHii1mgZQjIPEb/vtfSuBnmnTXT3ipGU77M9+HzbDOEM8OuIf3fFEEPE5uvADxvse2mQtHL7feBvengPTSTscYGk61DRyXyPEWcaojhkZO4jbhbbwLnoaCAHWmd69HnL5h0+hfSifNyo9TjjUnK/mEjr5l1Ukdj9TyFhpb28h3OGzBsUPxrJN+LscjSyaujIPEAOPycKNPhxxp/dzLiHe0jmGEU5C/wP4NskbcwU62+81rVyBknZ//s+zKUzjjIvErIEg4dEpd2kc3D4yNwOfoX8h2WtRejuz1bofOr3eqgZUvptJBFlJYMcVJG3vgv73hpIEa1HSFr09XIenTefWx8AAgyNMFNlPoRkfjlSNjNg8+F1efCvp+91he4mC2Wh4qjzryEd4+839xKlTPqoy+OZd9hzjch5J0+Yd/ZAn+bPs4jfvF4wJd7O0j6A+MtPKm0OF5mXkLKZfhtyzPvk9lMT+2wfVHnV+ewa8FGkKYaNY06T2bArcrdL07PAzyORQGN9uqcVJJR1sYBrIGuzLBlrWw9Ah4DMK873E4bMg9REzmN97qxiSK6v3EMOz/p5kFtFinx91Kj0UZJOMCFJr9Vhn8u2uuVnkDDER+h+XsBamDMiYFCyeKeRwAbFgJO5qw5HDZEXLZIlziD6GClp2g/1O5F6p/cgtVsec8x3r829DxuahsifQHzlNsOzH8rcWlWL5mpQ3MqJ7jWJRKhVlDoHm8zt4tmLdCeZdsjcL8A7aLfYasDn6I+vcDG1WZ42ZP5BQ17BGu92mDoU2XDE08BvInXK7XzslzIfB77CxYW3ikTiaWEzDdyCxJwrBpjMcZTQtFGSXoZqL9KEtv7p83S2st5WYEnpBPCXxo1gmz8Pu8/cxnV/EikjPJGTe1pCwhOLGnHk5jIESAao1mgZIjKfRFJ/Rwtq/sfOu7EZhGdyRJgriJvlI8ZaSKf7p4ljUBS6+1zp56kDXzCKfI7ehyJmoUqSOBQNAE8ESH+CfUqbw0Pm40aZ24iQoh3MeSkCWUWiEvJ0iHUWyWr8fIYaHET3SpRSidZqaiJusCWkIuL/pn/RK1lYJckCHYQxGUGSAbVW0JCQuVv61pJj4HyfxzotbvMMVwFaU3kph2N3AvhlJNJm2ahTNzwvK0JnEBahfQ77vPNIlM9fmb9fztn9niapq5NX8ZJel17G38XIGdi1Zj2PoRh4Mt/PxbGoXgEUuu8QuF14tiZLne7Vv94qlo2b5f1IudV6l8c1D4TjKvUqcpbxiCHyMzm992dJGjwXGfb+KyStIBUDTObjSPPXXSQx2kV1s3jGTL6X/h9+tsM541r4krEebMatl9qYotSzFZXQLZE3Ef/tIvAbwLdybHUcQwqmFd0qsnNpHLiCYvf0VTJfBxVjhu0nSSyIC/5eVo0yz3Nd6ieRUMUTqfvMcrMMQg0XW6N8CSmg9RWjzpdyer/PGHVedDK3JYWtMlcyH2Ay95GwJWuCuQqxCOrckp97r6Ex5fPeZODzJI2g62YTitoQeJELc7mhmN8EPmQ2sbxiCok8Olegd+623HOvCEnpD5HaS3uVPgeXzD3EVz5KkiFWRDXimvMLhszznvRRRQ4Bv0TSDameuu+iH4BaRV5H/ONfAL6BHIDm2TVh8xSK7jO3JSMqSNKQVk/M4QB1crFdYga7TGsoWVEGPn2qP4/ELRchg+9e4M+R6nY3kUQf2OcqCpHHXOzbt/PIRrB8Bfgl83dj5C+CxcK6fs5ycYx80c4vyub9l80cC4xwW0ExcGS+jIQkFq2GedqC8JyNaNEo3WpBnuMvkMNne24RFkiRN1Ik56WI3KbFnzRWiCWS5Rw/U4Uk6iZKbVbNNgIi7xtsycwtN+RYMWBuFpAa5rtTk5SCKFsvReQrxoxfKNB4LiBt0r6AJHiUzHU652rQJtU0HfVtSaRmLt8Q9weR5sxFUrangPtSP7PP1cy5CyZyyLxkvp9CIloGoSWkknkGxsyOPeIsxKL6aG0a/zmK5xt8GKlP8oQx848jh1VxAeZh5KjwOEX2pxFX0sed/7coOG3mkmv5ZZVeLoLgsUECu9DqiQNL5lMkNVmqBX8vtu3Xs87mVBScRSI9PmDGYYqLzy38nM7FLKVXcjapz5hnmyvIHLP3+CwSorjquFhsxcui5mIcIKm/pBggMh9FkglmzeKLaPV9Fmmy2qiJeUOMRUy0mTPE9zlDHG52a17JwaO1rIJr5q8C/8eo8iJ2ujmHROC4NehDWsN3i7AurBURIO5UVeYDSOY+Uk3NHoqUnElLQSasW4S/aZ7hFMV0FS0jWYcfdkhkhfwXfLJ+2QDxJ9uN9bOGyM867ooiITAbLGYsbBXCsM0GljeO8FNjFAIHjSWuGEA3y0Gjmrw25nIRSNH6MhuGDM+Q/4ShdigDX0Zqnx/LsXulHXnYapVPAZ9GMnEXCzoWNjJq3iHEdIhiXIBnwNmIrkaiphQDqMyvM26WvIdZrTVRm44yfwTpu7lQ0LE9b8bh/UiH+uU2m2xeMkK9jHk5h4Qhfpb8FtLa6PxaMM9QynjfcQF5YzeSPKTVEweQzA8jdcy9DSzWPMPe59MFNektqoYkvgP8KRLV0nQI3MZtu8ldeXn3kUOAfwg8WvB1FhllbqsneikiL1pEiz2srhhrfEapdHDI/DxwvTHtA1qbCRRtsvpIWN8x52cTBR3fs+brR4yr4rRRuza+2Q0D7Dehu3NkCfHxvw+JXik6mubdf5mkAqeb11AEde7WabEHt5eYr3NKpYND5vuR7M8SSYehJsUs6GRV0zJJ5MRiwcd5Ean5/TkzRlaVN1LEkgfSs3PmN8z9DgJWDOHNm43UK7CLBZLMzx0UM7pIybwNKmaHLjsmpZu6XJQqfV6K5I4zOOnKFZJQxWPmWbP8tv0cr9hsoKtIpcE/NhbSoOCs2VRrGfOuaKLHWt+70Z6gA0XmZSREqUjFnNqRiSX0JuI6skWERgdgnCtIgaoPGjdG3VHDfk7e/wJyTvFnSPTKIGHeIXPXtVVEV6S93x20tohU9BHbra0wYcj8eSnTsYiJNpFRHOeRQ8OT5LfhwUYwQuKftcWovmHG/GbgzY5KHMkYt15W93MTyz5mNpxBQ4z4zW3/0iBDAOW5wmj6Xm19loNKo4NB5la17iJJfigikdsqjx6Jf/O88/dFLPPZrtXdw0h0y/PMuAWIW6mfRZOaSPTNk+beHh7AtVZFXC1PIyG8Np2/aNasW0ExREITJyj+udJFuOOuu7f07z73n36qkGRu20gdcCZnkTe2mjH1zw7wBl5H2q39OfB2JJw0vUjJUOhZSm2zJNDu39fNe/848NcD/O5PIu6j6531EjmCIu9lcNPfl838mR0EMs8g7+uBG4Arkd7Gu4FJwxW2GN9pJLHtYaQy5tfd39NLYt8OmVeMYi0hfrOidx6xZLZMsePLXUySnfR0Gvgj4MVGVTWdudAr94ob8bQIfArxlU+nrKJBwnmz8N3aRUVteI7ZkMYR3/mpIlqwKQI/DHwf8Grge8iIn791YoGAKmEY8MW52axfuYyUoP4M8Bd33HX3A70i9u2QedVZlJcUQFmsRyy2tOf8AJH5QpvJNo5khf468O+AI85mZg9GRzqgxtNKzlX/TZJepfch/TwfJd/NJraLMZISEeOp91NEMbQMHAIuQzKmi0riPwT8U+CV9gcH/ePs4Sx7wgV2evMcHvXYETapjHg061Wq1RXeNBUSMcJCMMP/eXKB06V9LAa7xp4MD78GeA3wn4EvAv8L+O077rq70U1S366bZdTsZuUCE7kLWzf7BIONyFhWnwLuQA6zrB+3m2rRnSOr5n2fQ+rHfHnAidzOrzMk0SzpxKGioWKs8kuKsv5TJP7TwL80mxH7gzNcudPn2p1NdtaeZTZ+hp3ROabjRcZWF/BXl2kuNIjimFJYwg9kmawEY1x91U7mQo+5MOZsGPLg/Dj3nYo5tlS63atM3g78B+C/Anffcdfdi90g9e2S+TRwjVEc6w1m3CGV103zsYbUnX50wEllxTGJ/wdwo3G3jJKUZs1yQXXSErKW3JeRdnfzDD7qyAGojeUvUntFO2axIwhKSH2Wy4tgWThE/m7g3wKH9genuHHkSV64O2aydpLJsM5Uo0HQPE/YPE/YWKTUXCVs1CFq4Hsevu/hUceLPAhgsrnKZH2RA97TLIUVFsIJDvsV7jg4xbko5MHFXdy7eP3sE6vjvwj8JPDvgV+74667O0ro2yXzcaRVXJn2J/NFUuyriO/vKYYH9yPp/geQjkTdTJSKHFJrGgL/LWMJ2X6Zg4yamV/2+d1zijyHJdryHOmcBM8IutxXTzREfg1wN/D6ykSFW0ZP8PyRx7iCYxyonmRXsErUWGXl2XlGx0rUG1UatYhmE5oBlHwzVFFMTERkgkyDuA7NFUJgOoCREPZPTzPfiFj1AnaXdrJnR8RDwbXcszC5c3ne/1XgrcBP3XHX3V/plEoPOzA5n0PiX82akEXoRm57TZ4dEoXoYhH4n2aiv9WQatChDTki8cHbMgJL5l03gP+EJDItD8m7riERLd8EXmrWjSXyvGcb2yJtvvM1MhziNqjOsxr/TaB8/ex3uH1ygcvrJ7jEm2cnK3jVszTiKngRJT+isbosxfUDMzKeTx0fYh8vgDiKL6yKiAZBEF94K74HtcUFSp5P4Jc55J9jl/dVbhw9zp6VJo8duIm/O3HNS5B+vT8FvK8TKn27SmCCpAt8urdhUdL4LZnb8LhhI3PrdvkocI8hHDt2ndyAGyTRDx7wVeNeWR6y99wAvkviN48Ksj5smYsoRfA+4jfPXaMKh8jvBn5nale5/KLZL/G6mQd4xfh3udF7iOm5R1g98TDlqEoQRwRRZL6CH6eoMg6BkNi5ICQipOlB5Bk1G0OpCeUmjDUipuqL7G0cY/TJL/PmA2d4afkb3LrjXnbuDi/cW+p++0LmUyRxlyHFPgSNkWShswwfVpC6LR8gaWS96qjqTsyx2FFzzwD/rUO/v0iwZSEeTSlZvyDrI7352DGdRdx0eSTyDwP/5vDEM7y68b/58evOc3P0XSrPPkBlaY7xMGR6YoaAAD+WopB+lArMiz28mNYLCGLw44gghiDy8COPsOkTNkPCZkipGRI2Qry6R60Be2d8xk8e54Xx0/z01Sd5E3/JVeEJazV8CpjYDqF3gszHKH6MuX0XS0OmFNOEfg8SIlintVhaekG3u9rBrXnzpDEv/wY5m6gwPI2B3QgWa/kUpZhbVna37/zd3hwS+ceAd1wyU+Ptlz3N2w8v4n/nr5k4e5qJ2iphs0EYxwRejHeRCvfxYiFoP/bxY/CJ8OPk8uIILzYKPrabgH9hNXjmpCHAY7RUZtQPqSxVmTjzFDueuodXTj7Bm3c9zk1ST+7VwCeBma0S+nZIeA/SXShd9c1PXRRosj5CweJlO4wnkSzM+0l6ucabJHT3cmuuhEjSzEPAz5E0Ay4xONUpN0LmdaPMV8nurpTXtTFiLrcJtZWwu5AzF+hz5yGHCP8EeOOLp7/NT+z6LNfO3UPlyYfYTZlJ38f3QvB84qhOHK0S+xGxH+N5Hp7nEeARxAHynydkHkdC6EQEXnzh8jz5d7HvyUKx254nHSg9IkqRD1UIS2VKfoi3VGdq7ji3effxrssf58Vj3wW4HXF3Blsh9O1MoCnjKytSmdt2sPc/zMrc4n7gD4wrZIXWGuPxBsjKJX9L6LYHpv3dqySRK42Cz53NYNW805PmfVg3Rd43s3bizJL5mOECG9rabyL/TeAHbtvf4I27j3FN9V72rR5nsl6l0oAgkj7a8QWvX3v6usi9ckGRt/93sXhmzGX+vg5BZBS/F1KOfMYbVWYWH+WShX/gjQdOcrP3LZC8jw+lnqfrZL7DqPNmasCLqphsAsvckJP5HPB54wY5aUg3cFR2u8tLXa5G8ZGQvHvM711MuXeGaQNdMO/1rHnuRsHcLH7Gn0eMOp80llY/8a+Bn3jR+CleN3YvR4KzeIuLBDmUC57n4/sBE81Frmk8xtuOLHOI7wK8DUky6hmZTzI4tYxtCN152lcbHBbY5hAfAh435LNsrpU1rioSCWOvunMtAQ8aF85JFFUz16oUuwcAjmUxbq6+PI9RsbcD77ticoJX7nuGy1fvIzr5GCOIvzuvGIlXmVg9wTXlE7xq30n2lY8B/Dxw52bU+XZMot1IwpBn1EWpwBPSJrCcU565gC8hdcVfhrjUNjJX2q2YGvC7SA0WhWx+9wPPHQAytzxyGIlo6bll6xDerwK8aOIhdtceYrx+kkoYUWqAn2NHXuxB06tTn3uEl+2MqTUDPlK/jpW5pV8FPn3HXXcvbSQGfatkPoGEI02RHJIVGTGShbikPNNCOH8JfJ3EL9ru3WWVR01vlo8YV4ui1QochPMC28nqsj5u2P8PcOtt3rd46c5lxk8/wWi0SCmK8n+67kU0m3VG4hrjy49y21TAw3MP8yX2HwJ+Bakf0zUyH0d8ZNOOIk+HLuWN4KOMCege1D1myHyUYjaj6Aaeon1pg5GUa2azf+9iGFL50xvlOeTsYHYAnicw4301Usa416r8IPBL49EKdx55lksXvwGNM5Sihjl0hDi2S36zRmVCuK0SZpMeaq/97/diH6/uMVEKieae4dLpCq8cG2VxZZFvLl/5k8Af3HHX3V9dT51v1Wdui9KP0RqqVDTXilWVdaR58BLDEya32c07jVXnYgt/n0X6w4RzZr41B+BZPMMJl/ZpU/5ZwH/+1NMcHjlNfPZpKs0aQVSMIDs/hqDZpOxFUIWJ6kluGT3O7dMn3OfbkHm0GcyYr4eQPpI2tCpsM8Ae/W8l546om8XmNkeoIwd0D1Gc6IJeopvup9UhU+UWn3HWSUSxXZW+sdT3I2dpvVTlh4B/vn/xPr7v6Arx8gLeyChRbELUvIiGFxF7G6EHo6Czri3TTrsNJfk7jwYlbxXqK1TKPn61wUz9LIfDc9y04xTAW4Db1jsM3SyZ1xxlbhMIfONqKZo6jwyZ25oTDxuzdxiJRdF7rJJE9hS9F4ANUZw0Vy8zen8C4HkzJ9lf+y5hdZG44YnrIpZ6Kc3cB0xLIhLNhnmZESyc40CwyDXhs/Z/+vFOK3MbDzxBksbv50yJZz2jn7Fo3GSnJpospOgtlpHziEGpT+MhARE76IGr0lGpP3zpdImb9qwwU32Cseoc5VoDz/jKW9T2Wi6XFgUe0fl6gVm/z/neudfYi2jWm8zS4MbRkxxt3gfwLmDHWup8q3vWGHJoZXfkIpiIaUK37hTralH3iqKXqCKNKhoMRpeuCDlb6WXi0JuAffuiRzkysUxp6QSj8QpBswlNrw29RRt4jF69rmyW8vyYkl/GXz7HYf8kr7t6wv7tOzqpzG2S0JWIj6y0zk6dB6WeVSvEM2au/fl3GZ6UckU+MEWSDQrF95n7hsxfZIRepQefeyfAruX7GK+dIKw18aMIPK/lxmyp8cRvvhHF3e0SU7Yol/ndnn9hEjRjD7yYUm2JmaVjXNp4ouV5O0XmDWAfSYuxIiLdezFyFJJC0SvMI7kN9pymiH0A0lwSGpHXqwi3116/42munF0krC3gReIjJ/Ag8Igx1Q7zvE16CbHHnpTxkj83Cb1VxqJFphpnOTK6CNIkeqydq2WzZF5HSl26frGiKIp0cssoSRTBwySHuwpFr/CYIfXFAXiW0Fjq+7vNCYbMbgb27QpPc3Q2Jm7KjlgPfWolj0ZglLgtR2uu3JGSKcjV9CEixI/K+JFPkyYNr04ceQTxCgfGzth/8tJOKfNlkszPovn50gWgQpLwxKcYjLRqRbHwLBL2OQgRVDbWfNaxeruJ2wB2RPPsDKsEzQjiALxAzG3T+afFTeLl0+CJPIy7xb2iC2RVjmrsK823PHe73XSzmEVqsriDGBd08tlqic+gIYmK/ijzunFNrJdBnXfxFBtrfY+x3k93+fNuBphp1BhbbTIa1SnTJI4AP0iI/MJbjFoJPW5H8G30bbw9v3mc/hgviWLxLjBoZD4nwvf8C9+PNqtcN10SljLP3QllDlJ/YYJilbvNqrlu+xfOIQdRmsKv6AfmzNwr+gG8jQqrIAW3ur35XLPHi5mmSlhbokzSt7PVT+7SVD5fsdfiBorMz3yzu0eUohrjzUVu8J8FKZnQETKfAS5HUvndt5Nn1eC1GUmrJE6bBaVFthT9wDOI37zIbj4b2ttAzqIu7wEnHNrtP8NUOAf1c3g2fsFV2nFxu1nGUZRcNPFo4Mux3uFOkPmYuS4xA+YVdNKln/2MWUwKRa9RQZpULFD8Gi11s6bGkBot3U4c2jvlzTMZrBJGq/jxNgth5Rh+DGHcIBAyHwWmsyJaNvPEvnGx7EB87UHq369H7v2OO08rnxCJIvg0Gsmi6J/VeMKIiaKTuT25qyIRLZd040MMiYXAxHi8xJjXpBL4EEUbYBWHrtaruRL7rVfH2Wgzvz/Cj6qMJ5H7051ws+xEwo+K1iLOLa7l/qyG1NhuKq8o+jQvHwOODQiZB8ba2N1lfhiRD4wICQi80jphh36hlbpHhOfVCONay/Nvh8xjJGFoBAlBKqKLJUr9eRU4zmCkUyuKhyqS4/AUxT8ADc0zjBpVHnZ5LVNnjDiahKgCXnmAp0lEyVRXdJ9/u2S+k6Raov2lzQKoChtX7vrxGua+z6oyV/QRc8jhe52Lw3ydtJfcq3JbKsPGmndTCq/ITjhKwyvTjEKK20t+feLyY9JuoZXtkvkycA0SE9vY4H3kpYqiLdPrqoWKIfdlQ+gKRb9wkqSuvissmiQNsvMuOEJz2bT+W5Dkwo7C6bZztkrAudUaVX+teuXtpKm/9pUDEvdItvHID5hbvBBwd267ZD5rVLlPa/GquAAmYjtlcwJNFlL0H08ZhV7PED5RQdZXnBJvO8juUNUpnJiLxljCIwp8kyQ0mNK86YWsemNU/TGM8FzJaiG3GTLfZQbIbeBsibyIjSkWkCbDSuaKfuNpJLXfLXTtrtEi+BBcIvcRl+xMFz/vscfiXSw3A0qlkMAvtpvFtSxc31rs+6wGIUulHSwFOwAeXcv9sBGMmoGZIDn8jLewIfRzornfN5FwsONotURFPnCWJES26sxVGwJcJMEUGOE30cXP+A7AQjxKFI4RecX3mcde6yA3fagHsBJUOB/s4onmoQvPvR0y983glB2lYDcQ6yNb75Am7Zrpl3JoGnP2LImvUqHoJ04aK3HEWIwRrfX3i8BU7roOgBcba75b+HuApXAHy/44TcL131KOfOLroR41aXgxtQDqlQnuO3WBMv+hE2R+OckpdZAxkEVxr9hrxSwiDUtU9BtLSJhsk9YGKmT8uQiw/UB3dlGdfxlg3p/m2ZWQphe2LvMtN2LujyLP8vlHiDJfDss8Pn+Bcr/UCTK/xrha3OiUIk2yyFEPDWPKPmF+PqZ8ougjls3VMFZuJcOiLJIyt2S+uxtryxz+PQl867w3xfEln0Yw0ka3FYScLhC63Letcx75HjV/hFPVEkgdqa9kHX5uRZlPO6q8KJPMwvZatC6hZeTgSQ9AFf1GYCxFO0eDgj+Ph7iMpuhuR7JP3HN2H49Eh1jyZ4g9n6bn0zCOqciLChTlEhF5CYkTQN0PWQ4mWAhmORPvBvj4eiS9EYwAR0hiSe2/9dsMpLfGz/u1CdQcSyIyLpZlo4KWlU8UfcazFDvfwY1kCcx1iO42d/5TgG/wXJ6OZolHxolLZbxSSORH+D54no/nhXL5/pav7r65iNgXt1BsCL00EhKMz3BqdZZ7j0Utz7sdMh9HDjKmUm6VImSmpdWPRRV4ADkIVSjy4KKYQ+oEFV2RW16JjSU/1Y0PMq6GrwBffco7yENLYzSmLmOxHhOEote8GPzYpMHn2X8e+3iRL24VfCIvwi97NMenOR5cxjfP7wTJRfjYdsl8BOkcMl7wiTbquFvmgQfRVnGKvNjYYik+gRyCNjLIvgiq3P1zZETg3i5/9u8unn2C76yM82z5AH55Ar9aI4h8fCI8ahDXMlr95Ak+xBW85hiRFxJ5EPsNTtci7ouPcjy8FuB3nE1sy2Q+hhxkBAOycOrGrVInOQhVKPqNcyShss0UkRfBCs4KjJhFQpq7ifcDJx7zr+Cb1T1E03tYqEv7OC/yW+2FHCvzuO7hUyGOy1T9Cue9Sb4zN8YDtYOY+fAbG9gSNuRmuW0TkynP6f1Nc391s3AWaY0cUCj6AVs46dtGYPgFWU9p68K95zLSD3Rftz7QUal3P17bwyefmuLU1F7qM2VqnkdMCLG5cp5UFEUxURwzt1ilWtrNico1PF66kcfPjALcDZxcS5VvlMx9Yypl1WSJ25B5nidcHekuZP2TqswVecAcEm/eYDByH2yV0nEk3rybeB/wwP3x5dzz7AhLk0dYCSvUPYg9N2ajHSX0ea/0Isoj0IxXGR2fYGTPNdxfv4avV68EORT/lQ06azZkPh0gO1EoXsfcyqMpWEdCEs8ofyhyhDPAeZKoK5dtini24xurd6KbrhZHrf5Cox7wmcdnOTnyXFYrO1ilRt2XhKI4k+qSHMLYi/r2kv0gxisv0wiWKY9PcHxxjC+ev4JHz00A/AIwt54q3wiZj5qJtIvkUKOosPfeQPyTq8ofipzB1jVvpNZoEc+r7DNMIFEtXYs3N0T3J8DvPVl6Ln/z1F7mx69kqTTNiu9Tt28v9sXlEpXlq6G/2O89rcWe1F5p+j6NKCaOgcoMz5aP8snHRvn706MAn2ADvnLXFFoP0yQpuTHid3ZjzGNH9W6FXDupBNZ8f+ZaQXzlI+piUeTQ1XIfScCBn6HS82rxuo01bJb1WeBapKP8/T24j38JvOTjpy45ujc8xYt3LFGJnqE5f4ooigiiEOIx80prosiDiIguFr8xIZG2KqLfFMqtBw2avk8ch/iez0i9RjB7HZ89fwt/G1wD0dK8eR42oso3QoAl4Apa28RtNYU/7Wf3aS3atd1rIxOuYch8Aa2WqMgfakjKtu2CRYZgyuOVtdYxvLEfuKrb1oUhvHngxwA+9cwBvrJylFNjh1kdm6HplSVqBJ+mZ4jIxHX3QoULr/vOSIprJwqgGo5zMjzEPywf5tNnLuFsfQngR4FHNkrkGyHzCnCTMxDuyXraZ54e4LUOSrtVQTFa4/IdF8tpBrXPlKLIWEHOc+IMIVIk+MatMoEET1zai2cwxPdZ4MeOx3v4yLM38lcnJlmcvpIoEOdC5NdoBjXqYY2mHxlfeiiJO90gcpJKjd4FimoQRhDE0qh5uTzFtyZu5Y+fuZTjdR/g54CPbIbIN0LmI8BRQ+YuUUfrkGk/JmCcUvt+hplaR/yS59CEIUX+YCOtmmuIpqLAM2KwjBTd6gkfGAL8beDnzq2W+crKzXzm+G5OT1zFYmmKWgiR3yDyoOH1orqwjxf7+JEhdV/U+GrgsxjO8MzIUb7tX8cn5o7yjfoegP8C/MetfNJ6PvNxpCZLxfy/3jr+OzvpGqx/YOp3/K21TvooQ/VMAMeAx9TNosipm+VhJKltJmUNBwVS6J5jDZfMNYFE6/QK/xEIji3O/vIn6y+i4d3LKw4E7F14hOaZ4+CN4Ps+oRfhEUFkCsh3uA6LF0d4sXGv+D71ckA19InHd3EiuoyvNm7iC3OHeOz8CEiI5c84m1LHyHwMCfqfIWmG3C6+J63E4w2YinGHCT0dnxtmWBlzhsyfRA8/FflCxajy+dT6cVW6nzOVHrURaH7KSrcRLcd7pc7vuOtugP8ALJxc5df+8uwhSjt2cUUEB3eMUa6dZ6y5RK1ZpxxD4Pvd2ym9CPyAuBxQG59ivrKHp5qX8uW5ffxt7SinFwKAXwR+aatEvh6ZB4bQS0bVeusMqkvMzZRSj8nOtOwkmaeLZpUyNpN5xF++oNyhyBmsuDgNPG6s4gmz9iKzfvJ2zpMl2Ow9ls0zVZC0/r2s0fKsgxgBVh1C/6/Ak+cau3739x7cNXP1jlFetvcZbhz/JqXqE3iNMkG9jl/3oNHsSoXEhtdk1Wuw7MG8v5unSs/lI8cu5dsrs/Z/eTfwge0Q+XpkvmDMvVNIF/t2A5nVC7TpkHyU8bN2an07CNch99gslIeVNxQ5xnng02b+7iCJO8/7gX26NsuIEU8zSMW/iR7eBy4x3nHX3R8FvgX8xoPn9rzq/uPnufPwQW6ojHB4EqZr5xldPkfJW8KPGgSeuEfso/hxlhGSdqfYOjANqUlOyKofUg1GWQkqTB48ymNzIV87UeHv5sc5FsyCVH18D/C17ZB4cg/xulab25AiXucF5v2gpqGqXFEAjBtla6PCuhoK3WVSjfOw7oxKB/hpJD0+3Fs5wy2jZ7hl+hw3Tp3CP/ddvJXzTATg12t4MXj+CEEMpagmvvVMv0QoGUBRE4JV8b1PTDNX2sGZyX0ciw/whSdGOBlcx33zF3Kn/j3wb7erxjdL5gqFQlF4OIR+CEmT/xGAK4KnuYT7OTh6niM7x9g/GjHVXKDcWMRfXSJsVClHVYK4TcxEXMbzpohLY9QqJaojU5ysVnhwIeDriwEPRZdwvHG1/b//CPhlpKhax4hcyVyhUAwzqd8M/KQl9eld+5lqnGJX82kuqR3j8vJJjlQW2TuyRLR8loBa5u+rM8ZqeR/H69M8WJvmWHM3J2r7OBPsZ2H1gkHyIeDXMQ2ZO0niSuYKhUJJXbAH+KfA25By3wBcHzzNweAZdgXzTJXrbZV51R/j5Oo4x9nFV1cOuX/1TeAjwP9CDrW7QuJK5gqFYpgxgim255A6SF7Nq4DvAZ6PlCLYKB4DvgZ8AfhrnOidbpK4krlCoVC0V+sW40h9qkuRAmgTSNhzA8kmP41E6zxCKimqFwSuZK5QKBRbI/e26DV5K5krFArFAEIrByoUCoWSuUKhUCiUzBUKhULREfz/bGxzQRMEkUQAAAAASUVORK5CYII=';
const logo = () => `<img class="lgi" alt="" src="${logoUrl}">`;

const STYLE = `
:host{--f:Bahnschrift,'DIN Condensed','Arial Narrow','Roboto Condensed',system-ui,sans-serif}
*{box-sizing:border-box;font-family:var(--f)}
[hidden]{display:none!important}
button{cursor:pointer;border:0;font-weight:700}
.ov{--w:min(300px,64vw,calc(60vh*.7));position:fixed;inset:0;pointer-events:auto;overflow:hidden;contain:layout paint;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#f4efe2;text-align:center;background:linear-gradient(180deg,#06070c,#0d1019)}
.gl{position:absolute;left:50%;top:50%;width:90vmin;height:90vmin;margin:-45vmin 0 0 -45vmin;background-color:var(--tc,#d6ae52);opacity:.3;-webkit-mask:radial-gradient(closest-side,#000,transparent);mask:radial-gradient(closest-side,#000,transparent);transition:background-color 1s;pointer-events:none}
.hd{position:absolute;top:20px;left:22px;font-size:13px;letter-spacing:.3em;text-transform:uppercase;color:#d6ae52}
.tl{position:absolute;top:12px;right:16px;display:flex;gap:8px;z-index:5}
.tl button{padding:7px 14px;background:none;border:1px solid rgba(214,174,82,.45);color:#e7d7a8;font-size:12px;letter-spacing:.18em;text-transform:uppercase}
.st{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:28px;min-height:62vh;padding:0 16px;pointer-events:none;transition:opacity .3s}
.st button{pointer-events:auto}
.hint{margin:0;font-size:12px;letter-spacing:.3em;text-transform:uppercase;color:#cdbb86;animation:pls 2.4s ease-in-out infinite}
@keyframes pls{50%{opacity:.5}}
.fl{position:absolute;inset:0;background:var(--fc,#fff);opacity:0;pointer-events:none}
.fl.go{animation:fl .7s ease-out}
@keyframes fl{8%{opacity:var(--fp,.8)}to{opacity:0}}



.pt{position:absolute;inset:0;pointer-events:none}
.pt i{position:absolute;left:var(--bx,50%);top:var(--by,50%);width:var(--z);height:var(--z);border-radius:50%;background:var(--c);animation:bst 1.5s cubic-bezier(.2,.7,.3,1) forwards}
@keyframes bst{40%{transform:translate(var(--x),var(--y));opacity:1}to{transform:translate(var(--x),calc(var(--y) + 180px));opacity:0}}
.rg{position:absolute;left:50%;top:50%;width:60px;height:60px;margin:-30px 0 0 -30px;border-radius:50%;border:2px solid var(--c);animation:rg .9s ease-out forwards}
@keyframes rg{to{transform:scale(14);opacity:0}}
.shake .st{animation:shk .45s}
@keyframes shk{20%{transform:translate(-6px,3px)}40%{transform:translate(6px,-3px)}60%{transform:translate(-4px,2px)}80%{transform:translate(3px,-1px)}}

.pack{position:relative;font-size:calc(var(--w)/20);width:15em;height:23em;padding:0;background:none;overflow:visible;animation:lev 4s ease-in-out infinite;will-change:transform}
@keyframes lev{50%{transform:translateY(-.5em)}}
.aura{position:absolute;inset:-4em;background:radial-gradient(closest-side,rgba(214,174,82,.28),transparent);animation:pls 3s ease-in-out infinite}
.half{position:absolute;inset:0;display:none;will-change:transform}
.whole{position:absolute;inset:0}
.split .whole{display:none}
.split .half{display:block}
.pf{position:absolute;inset:0;border-radius:.5em;overflow:hidden;background:linear-gradient(90deg,#07080d,#1a1e2d 22%,#0d1018 50%,#1a1e2d 78%,#07080d);box-shadow:inset 0 0 0 1.5px rgba(214,174,82,.8)}
.pf::before{content:"";position:absolute;inset:0;background:linear-gradient(118deg,transparent 0 30%,rgba(255,255,255,.06) 30% 50%,transparent 50%),linear-gradient(62deg,transparent 0 56%,rgba(214,174,82,.14) 56% 72%,transparent 72%),linear-gradient(180deg,rgba(214,174,82,.16),transparent 30%,transparent 70%,rgba(214,174,82,.16))}

.cr{position:absolute;left:0;right:0;top:0;height:2.4em;background:repeating-linear-gradient(90deg,rgba(0,0,0,.4) 0 .1em,rgba(255,255,255,.32) .1em .2em,transparent .2em .34em),linear-gradient(180deg,#4a3306,#d9b24c 28%,#f6e3a0 46%,#b88a2a 68%,#3f2b05)}
.cr::after{content:"";position:absolute;left:0;right:0;top:100%;height:1.4em;background:linear-gradient(180deg,rgba(0,0,0,.55),transparent)}
.cr.b{top:auto;bottom:0;transform:scaleY(-1)}
.pk{position:absolute;left:0;right:0;top:2.4em;height:3.2em;background:repeating-linear-gradient(90deg,rgba(255,255,255,.09) 0 .25em,rgba(0,0,0,.2) .25em .6em,transparent .6em .95em);-webkit-mask:linear-gradient(180deg,#000,transparent);mask:linear-gradient(180deg,#000,transparent)}
.pk.b{top:auto;bottom:2.4em;transform:scaleY(-1)}
.lg{position:absolute;left:50%;top:50%;width:10.5em;transform:translate(-50%,-50%);filter:drop-shadow(0 .3em .5em rgba(0,0,0,.6))}

.lgi{display:block;width:100%;height:auto}
.pf s{position:absolute;top:0;bottom:0;left:-40%;width:30%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.2),transparent);animation:sh 3.6s ease-in-out infinite}
@keyframes sh{0%,35%{transform:translateX(0) skewX(-20deg)}to{transform:translateX(480%) skewX(-20deg)}}
.tear{animation:tear .8s both}
@keyframes tear{20%{transform:translateX(-.3em) rotate(-1.5deg)}40%{transform:translateX(.3em) rotate(1.5deg)}60%{transform:translateX(-.5em) rotate(-2.5deg) scale(1.03)}80%{transform:translateX(.5em) rotate(2.5deg) scale(1.05)}to{transform:scale(1.08)}}
.split .half.t{animation:ft .9s cubic-bezier(.3,.6,.3,1) forwards}
.split .half.b{animation:fb .9s cubic-bezier(.3,.6,.3,1) forwards}
@keyframes ft{to{transform:translate(5em,-18em) rotate(14deg);opacity:0}}
@keyframes fb{to{transform:translate(-4em,18em) rotate(-12deg);opacity:0}}
.split .aura{opacity:0;animation:none}
.slit{position:absolute;left:-40%;right:-40%;top:46%;height:.5em;background:#fff;border-radius:50%;opacity:0;box-shadow:0 0 3em 1em rgba(255,236,190,.9)}
.split .slit{animation:slit .9s ease-out forwards}
@keyframes slit{0%{opacity:1;transform:scale(.1,1)}30%{opacity:1;transform:scale(1,4)}to{opacity:0;transform:scale(1.6,14)}}

.seg{font-size:calc(var(--w)/20);display:flex;flex-direction:column;align-items:center;gap:1.4em;animation:sin .6s cubic-bezier(.16,1,.3,1) both;will-change:transform,opacity}
.seg.out{animation:sout .38s ease-in both}
@keyframes sin{from{opacity:0;transform:translateX(5em)}}
@keyframes sout{to{opacity:0;transform:translateX(-5em)}}
.k{margin:0;display:flex;align-items:center;gap:1em;font-size:.9em;letter-spacing:.42em;text-transform:uppercase;color:#d6ae52}
.k::before,.k::after{content:"";width:3em;height:1px;background:linear-gradient(90deg,transparent,#d6ae52)}
.k::after{transform:scaleX(-1)}
.seg h2{margin:0;font-weight:800;line-height:1.02;letter-spacing:.02em;max-width:min(18em,90vw);text-wrap:balance}
.ul{width:12em;height:2px;background:linear-gradient(90deg,transparent,#d6ae52,transparent);animation:grow .9s .25s cubic-bezier(.16,1,.3,1) both}
@keyframes grow{from{transform:scaleX(0)}}
.seg .crest{position:relative;left:auto;top:auto;font-size:1.35em;--e1:#f3d98a;--e2:#9a6c14;--c1:#1d2557;--c2:#0a0e24;--tx:#f3d98a}

.cw{--u:calc(var(--w)/20);position:relative;font-size:calc(var(--w)/20);width:20em;height:28.4em;animation:rise .9s cubic-bezier(.16,1,.3,1) both;will-change:transform}
@keyframes rise{from{opacity:0;transform:translateY(5em) scale(.92)}}
.cw.slam{animation:slam .5s cubic-bezier(.2,1.4,.4,1)}
@keyframes slam{from{transform:scale(1.07)}}
.halo{position:absolute;inset:-5em;background:radial-gradient(closest-side,var(--g),transparent);opacity:.7;pointer-events:none}
.card{position:absolute;inset:0}
.edge,.in{position:absolute;clip-path:polygon(0 6%,11% 0,89% 0,100% 6%,100% 90%,50% 100%,0 90%)}
.edge{inset:0;background:linear-gradient(160deg,var(--e1),var(--e2))}
.in{inset:.35em;overflow:hidden;background:radial-gradient(120% 60% at 78% 0,rgba(255,255,255,.38),transparent 62%),linear-gradient(165deg,var(--c1),var(--c2))}
.pat{position:absolute;inset:0;background:repeating-linear-gradient(45deg,rgba(255,255,255,.07) 0 1px,transparent 1px 1.5em),repeating-linear-gradient(-45deg,rgba(255,255,255,.07) 0 1px,transparent 1px 1.5em)}
.sh{position:absolute;top:0;bottom:0;left:-45%;width:35%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.35),transparent);transform:translateX(0) skewX(-18deg)}
.shine .sh{animation:sw 1.3s ease-out both}
@keyframes sw{to{transform:translateX(480%) skewX(-18deg)}}
.fr{position:absolute;inset:0;width:100%;height:100%;color:var(--tx);pointer-events:none}
.rt{position:absolute;left:calc(var(--u)*1.5);top:calc(var(--u)*7.5);transform:translateY(-50%);font-size:5em;font-weight:800;line-height:1;white-space:nowrap;color:var(--tx);z-index:2;font-variant-numeric:tabular-nums}
.tr{position:absolute;left:calc(var(--u)*1.6);top:calc(var(--u)*10.5);font-size:.95em;font-weight:700;letter-spacing:.24em;text-transform:uppercase;color:var(--tx);z-index:2}
.tr::after{content:"";display:block;width:2.2em;height:2px;margin-top:.7em;background:var(--tx);opacity:.5}
.crest{position:absolute;left:10.2em;top:2.8em;width:8.4em;height:9.4em;display:grid;place-items:center;clip-path:polygon(50% 0,100% 22%,100% 78%,50% 100%,0 78%,0 22%);background:linear-gradient(160deg,var(--e1),var(--e2))}
.crest i{position:absolute;inset:.3em;clip-path:inherit;background:linear-gradient(160deg,var(--c2),var(--c1))}
.crest b{position:relative;font-size:3.1em;font-weight:800;line-height:1;letter-spacing:.02em;color:var(--tx)}
.nm{position:absolute;left:calc(var(--u)*1.8);right:calc(var(--u)*1.8);top:calc(var(--u)*14.3);text-align:center;font-size:1.9em;font-weight:800;line-height:1;letter-spacing:.06em;white-space:nowrap;overflow:hidden;color:var(--tx)}
.rule{position:absolute;left:2em;right:2em;top:17em;height:1px;background:var(--tx);opacity:.4}
.rule::after{content:"";position:absolute;left:50%;top:-.25em;width:.5em;height:.5em;margin-left:-.25em;transform:rotate(45deg);background:var(--tx)}
.stats{position:absolute;left:1.8em;right:1.8em;top:18.1em;height:5.6em;display:grid;grid-template-columns:1fr 5.4em;color:var(--tx)}
.stats div{display:flex;flex-direction:column;justify-content:center;align-items:center;gap:.5em;min-width:0;padding:0 .6em}
.stats div+div{border-left:1px solid color-mix(in srgb,var(--tx) 40%,transparent)}
.stats small{font-size:.75em;letter-spacing:.24em;text-transform:uppercase;opacity:.75}
.stats span{font-weight:800;line-height:1.05;text-align:center;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;max-width:100%;word-break:break-word}
.r-common{--e1:#ff9d92;--e2:#6f0f16;--c1:#e0454c;--c2:#8a1a22;--tx:#fff1ec;--g:rgba(226,71,75,.55)}
.r-rare{--e1:#fff;--e2:#7f8aa0;--c1:#e9edf4;--c2:#9aa5ba;--tx:#1b2230;--g:rgba(207,214,227,.5)}
.r-legendary{--e1:#ffe08a;--e2:#a84a05;--c1:#ffc14d;--c2:#e8750f;--tx:#3a1a00;--g:rgba(255,160,40,.6)}
.r-mythic{--e1:#b9a6ff;--e2:#2a1a7a;--c1:#4b2bb8;--c2:#150b4a;--tx:#f1eaff;--g:rgba(138,108,255,.6)}
.r-icon{--e1:#fffdf2;--e2:#c9a34a;--c1:#fff4cf;--c2:#e6c46a;--tx:#3a2a00;--g:rgba(255,233,168,.7)}
.r-icon .in{background:radial-gradient(120% 60% at 78% 0,rgba(255,255,255,.6),transparent 62%),linear-gradient(150deg,#fffaf0,#f2d98a 45%,#bfe6f2 75%,#f5d1ea)}

.nx{position:relative;z-index:5;padding:13px 32px;background:linear-gradient(180deg,#f3d98a,#c99a2e);color:#1f1600;font-size:15px;letter-spacing:.2em;text-transform:uppercase}
.nx:hover{filter:brightness(1.08)}
.gate{position:fixed;inset:0;display:grid;place-items:center;pointer-events:auto;background:linear-gradient(180deg,#06070c,#0d1019);contain:layout paint}
.gate>div{display:flex;flex-direction:column;align-items:center;gap:14px;width:min(340px,86vw);padding:34px 28px 26px;background:linear-gradient(180deg,#141828,#0b0e18);border:1px solid rgba(214,174,82,.55);color:#f4efe2;text-align:center}
.gate h2{margin:0;font-size:34px;font-weight:800;line-height:1}
.gate p{margin:0 0 8px;font:15px/1.5 system-ui,sans-serif;color:#b8bdd0}
.gi{width:78px}
.gh{background:none;color:#8f96b0;font-size:13px;letter-spacing:.18em;text-transform:uppercase;padding:6px}
.pill{position:fixed;right:18px;bottom:18px;pointer-events:auto;padding:11px 18px;background:#0d1019;color:#f1dfa6;border:1px solid rgba(214,174,82,.7);font-size:13px;letter-spacing:.18em;text-transform:uppercase;box-shadow:0 6px 24px rgba(0,0,0,.45)}
.rl{position:absolute;left:50%;top:50%;width:var(--l);height:2px;margin-top:-1px;transform-origin:0 50%;background:linear-gradient(90deg,var(--c),transparent);transform:rotate(var(--a)) scaleX(0);animation:rl .8s ease-out forwards}
@keyframes rl{30%{transform:rotate(var(--a)) scaleX(1);opacity:1}to{transform:rotate(var(--a)) translateX(70px) scaleX(1);opacity:0}}
.pil{position:absolute;left:50%;top:-10%;bottom:-10%;width:26vmin;margin-left:-13vmin;background:linear-gradient(90deg,transparent,color-mix(in srgb,var(--c) 65%,transparent),transparent);opacity:0;animation:pil 1s ease-out forwards}
@keyframes pil{0%{opacity:0;transform:scaleX(.2)}25%{opacity:.8;transform:scaleX(1)}to{opacity:0;transform:scaleX(1.5)}}
.rn{position:absolute;top:-20px;left:var(--l);width:4px;height:12px;border-radius:2px;background:var(--c);opacity:0;animation:fall 2s linear var(--d) forwards}
@keyframes fall{0%{opacity:1;transform:translateY(0)}to{opacity:1;transform:translateY(115vh)}}
.gl.pu{animation:gp .7s ease-out}
@keyframes gp{40%{transform:scale(1.25)}}
.sk{position:absolute;left:var(--l);top:var(--t);width:var(--s);height:var(--s);background:linear-gradient(#fffbe6,#f6d675);clip-path:polygon(50% 0,60% 40%,100% 50%,60% 60%,50% 100%,40% 60%,0 50%,40% 40%);opacity:0;animation:skup var(--d) ease-out forwards}
@keyframes skup{0%{opacity:0;transform:scale(.3)}20%{opacity:1}to{opacity:0;transform:translate(var(--dx),var(--dy)) scale(1) rotate(160deg)}}
.fs{position:absolute;left:50%;top:50%;width:var(--z);height:calc(var(--z)*.5);background:var(--c);border:1px solid #fff1c2;animation:fs 1.3s cubic-bezier(.2,.7,.3,1) forwards}
@keyframes fs{40%{transform:translate(var(--x),var(--y)) rotate(var(--r));opacity:1}to{transform:translate(var(--x),calc(var(--y) + 260px)) rotate(calc(var(--r)*1.6));opacity:0}}
.tw{position:absolute;left:var(--l);top:var(--t);width:var(--s);height:var(--s);margin:calc(var(--s)/-2) 0 0 calc(var(--s)/-2);background:linear-gradient(#fff8d8,#f6d675);clip-path:polygon(50% 0,60% 40%,100% 50%,60% 60%,50% 100%,40% 60%,0 50%,40% 40%);opacity:0;animation:tw 1.8s ease-in-out var(--d) infinite;pointer-events:none;z-index:3}
@keyframes tw{0%,100%{opacity:0;transform:scale(.3) rotate(0)}50%{opacity:1;transform:scale(1) rotate(45deg)}}
.punch{animation:pn .5s ease-out}
@keyframes pn{from{transform:scale(1.06)}}
.rumble .st{animation:rb .14s linear infinite}
@keyframes rb{25%{transform:translate(2px,-1px)}75%{transform:translate(-2px,1px)}}
.tear.long{animation-duration:1.7s}
.dark .st{opacity:.45}
.dark .gl{opacity:.08}
.royal{background:radial-gradient(ellipse at 50% 105%,rgba(120,40,170,.38),transparent 60%),linear-gradient(180deg,#05030a,#130a20)}
.royal .k,.royal .hint{color:#f6d675}
.royal .k::before,.royal .k::after{background:linear-gradient(90deg,transparent,#f6d675)}
.royal .ul{background:linear-gradient(90deg,transparent,#f6d675,transparent)}
.royal .seg h2{background:linear-gradient(180deg,#fff6c9,#f6d675 55%,#b88a2a);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
.pack.royal .aura{background:radial-gradient(closest-side,rgba(246,214,117,.6),rgba(150,70,220,.3) 60%,transparent)}
.pack.royal .pf s{animation-duration:1.8s}
.r-perfect{--e1:#fff6c9;--e2:#7a5200;--c1:#241247;--c2:#06030c;--tx:#f6d675;--g:rgba(246,214,117,.8)}
.r-perfect .edge{background:var(--pedge)}
.r-perfect .in{background:var(--pface)}
.r-perfect .pat{background:repeating-linear-gradient(45deg,rgba(246,214,117,.18) 0 1px,transparent 1px 1.5em),repeating-linear-gradient(-45deg,rgba(246,214,117,.18) 0 1px,transparent 1px 1.5em)}
.r-perfect .rt,.r-perfect .crest b{background:linear-gradient(180deg,#fff6c9,#f6d675 50%,#b88a2a);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
.r-perfect .sh{animation:sw 2.8s ease-in-out infinite}
.r-perfect .halo{background:radial-gradient(closest-side,rgba(246,214,117,.6),rgba(140,60,200,.3) 60%,transparent);animation:pls 2.4s ease-in-out infinite}
.cw{--pface:radial-gradient(120% 55% at 78% 0,rgba(246,214,117,.4),transparent 62%),radial-gradient(90% 60% at 15% 100%,rgba(140,60,200,.6),transparent 70%),linear-gradient(165deg,#1d1040,#07040f 55%,#33091f);--pedge:linear-gradient(160deg,#fff6c9,#e3b94f 30%,#8a5a00 55%,#f6d675 80%,#fff1b0)}
.mo{position:absolute;inset:0;opacity:0;-webkit-mask-size:260% 260%;mask-size:260% 260%;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat}
.mo1{background:linear-gradient(135deg,#7a3fc0,#2a0f4d 55%,#160a30);-webkit-mask-image:linear-gradient(135deg,#000 38%,transparent 62%);mask-image:linear-gradient(135deg,#000 38%,transparent 62%);--p0:100% 100%;--p1:0 0}
.mo2{background:linear-gradient(45deg,#7a5200,#e3b94f 40%,#fff6c9 55%,#f6d675 70%,#a87a1a);-webkit-mask-image:linear-gradient(45deg,#000 38%,transparent 62%);mask-image:linear-gradient(45deg,#000 38%,transparent 62%);--p0:100% 0;--p1:0 100%}
.mo3{background:var(--pface);-webkit-mask-image:linear-gradient(180deg,#000 38%,transparent 62%);mask-image:linear-gradient(180deg,#000 38%,transparent 62%);--p0:0 100%;--p1:0 0}
@keyframes wipe{from{opacity:1;-webkit-mask-position:var(--p0);mask-position:var(--p0)}to{opacity:1;-webkit-mask-position:var(--p1);mask-position:var(--p1)}}
.morph .mo1{animation:wipe 1.2s ease-in-out both}
.morph .mo2{animation:wipe 1.2s ease-in-out .6s both}
.morph .mo3{animation:wipe 1.4s ease-in-out 1.2s both}
.moe{position:absolute;inset:0;clip-path:polygon(0 6%,11% 0,89% 0,100% 6%,100% 90%,50% 100%,0 90%);background:var(--pedge);opacity:0}
.morph .moe{animation:fadein 2.2s ease-in .3s both}
@keyframes fadein{to{opacity:1}}
.fl2{position:absolute;left:-100%;top:-100%;width:300%;height:300%;opacity:0;transition:opacity 1s;background:linear-gradient(135deg,transparent 0 8%,rgba(246,214,117,.5) 14%,transparent 22%,rgba(150,70,220,.5) 32%,transparent 42%,rgba(246,214,117,.45) 52%,transparent 62%,rgba(180,40,80,.4) 72%,transparent 82%,rgba(246,214,117,.5) 90%,transparent 100%)}
.morph .fl2,.r-perfect .fl2{animation:flow 7s ease-in-out infinite alternate}
.morph.late .fl2,.r-perfect .fl2{opacity:1}
@keyframes flow{to{transform:translate(33.3%,33.3%)}}
.flowicon .in{background-size:300% 300%,300% 300%;animation:iflow 1.4s ease-in-out infinite alternate}
@keyframes iflow{to{background-position:100% 0,100% 0}}
.crest i::after{content:"";position:absolute;inset:0;background:linear-gradient(160deg,#241247,#06030c);opacity:0}
.morph .crest i::after{animation:fadein 1.4s ease-in 1.1s both}
.tr{transition:opacity .25s}
.tr.fo{opacity:0}
.morph .rt,.morph .nm,.morph .stats,.morph .crest b,.morph .fr{transition:color 1.2s}
.morph .tr{transition:opacity .25s,color 1.2s}
.eo{position:absolute;left:var(--l);top:var(--t);font-size:var(--s);font-style:normal;line-height:1;opacity:0;animation:eo 2.4s ease-out var(--d) forwards}
@keyframes eo{0%{opacity:0;transform:translate(-50%,-50%) scale(.2) rotate(var(--r))}12%{opacity:1;transform:translate(-50%,-50%) scale(1.25) rotate(var(--r))}22%{transform:translate(-50%,-50%) scale(1) rotate(var(--r))}70%{opacity:1}to{opacity:0;transform:translate(-50%,calc(-50% + 150px)) scale(.9) rotate(calc(var(--r)*-1))}}
@media (prefers-reduced-motion:reduce){.pack,.aura,.hint,.pf s{animation:none}}
`;

const host = document.createElement('mpo-root');
host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;pointer-events:none';
const root = host.attachShadow({ mode: 'open' });
const sheet = new CSSStyleSheet();
sheet.replaceSync(STYLE);
root.adoptedStyleSheets = [sheet];
root.innerHTML = '<div class="ov" hidden><div class="gl"></div><div class="hd"></div><div class="tl"><button class="mute"></button><button class="skip">Overslaan</button></div><div class="st"></div><div class="pt"></div><div class="fl"></div></div>';
document.documentElement.appendChild(host);

const $ = s => root.querySelector(s);
const ov = $('.ov'), st = $('.st'), pt = $('.pt'), fl = $('.fl'), gl = $('.gl'), hd = $('.hd');
let skip = false, busy = false, muted = false, ac = null, mg = null, nb = null;
const pend = new Set();
$('.skip').onclick = () => { skip = true; [...pend].forEach(f => f()); };
const mute = $('.mute');
try { muted = localStorage.getItem('mpoMute') === '1'; } catch (e) {}
const paint = () => { mute.textContent = muted ? 'Geluid uit' : 'Geluid aan'; };
paint();
mute.onclick = () => { muted = !muted; paint(); try { localStorage.setItem('mpoMute', muted ? '1' : '0'); } catch (e) {} if (!muted) audio(); };

// Geluid wordt live gesynthetiseerd; de ruisbuffer wordt maar een keer gemaakt.
const audio = () => { try { if (!ac) { ac = new (window.AudioContext || window.webkitAudioContext)(); const c = ac.createDynamicsCompressor(); mg = ac.createGain(); mg.gain.value = .6; mg.connect(c); c.connect(ac.destination); nb = ac.createBuffer(1, ac.sampleRate, ac.sampleRate); const a = nb.getChannelData(0); for (let i = 0; i < a.length; i++) a[i] = Math.random() * 2 - 1; } if (ac.state === 'suspended') ac.resume(); } catch (e) { ac = null; } };
const tone = (f, d, o = {}) => { if (!ac || muted) return; const t = ac.currentTime + (o.at || 0), x = ac.createOscillator(), g = ac.createGain(); x.type = o.type || 'sine'; x.frequency.setValueAtTime(f, t); if (o.to) x.frequency.exponentialRampToValueAtTime(o.to, t + d); g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(o.v || .15, t + (o.a || .02)); g.gain.exponentialRampToValueAtTime(.0001, t + d); x.connect(g); g.connect(mg); x.start(t); x.stop(t + d + .05); };
const noise = (d, o = {}) => { if (!ac || muted) return; const t = ac.currentTime + (o.at || 0), s = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain(); s.buffer = nb; s.loop = true; f.type = o.type || 'bandpass'; f.frequency.setValueAtTime(o.f || 1000, t); if (o.to) f.frequency.exponentialRampToValueAtTime(o.to, t + d); g.gain.setValueAtTime(o.v || .1, t); g.gain.exponentialRampToValueAtTime(.0001, t + d); s.connect(f); f.connect(g); g.connect(mg); s.start(t); s.stop(t + d + .05); };
const NOTES = [262, 330, 392, 523, 659, 784];
const sfx = {
  charge: () => { tone(70, .8, { to: 240, v: .25, a: .4 }); noise(.8, { f: 300, to: 2200, v: .07 }); },
  split: () => { tone(95, .8, { to: 30, v: .6 }); noise(.5, { type: 'lowpass', f: 4000, to: 300, v: .25 }); tone(1320, .9, { v: .05, at: .05 }); tone(1760, .9, { v: .04, at: .1 }); },
  seg: () => { noise(.35, { f: 500, to: 3000, v: .1 }); tone(880, .5, { v: .06, at: .1 }); tone(1320, .4, { v: .03, at: .1 }); },
  rise: () => tone(160, 1, { to: 520, type: 'triangle', v: .06, a: .5 }),
  tick: () => tone(rnd(1500, 2100), .02, { v: .012 }),
  sad: () => { [[311, 0], [294, .32], [277, .64]].forEach(([f, at]) => tone(f, .3, { type: 'triangle', v: .11, at })); tone(262, 1, { to: 185, type: 'triangle', v: .12, at: .96 }); },
  beat: () => { tone(58, .22, { to: 38, v: .35 }); tone(58, .22, { to: 38, v: .25, at: .24 }); },
  charge10: () => { tone(60, 1.6, { to: 300, v: .3, a: .9 }); noise(1.6, { f: 200, to: 5000, v: .09 }); for (let i = 0; i < 7; i++) tone(60, .15, { to: 38, v: .2, at: .2 + i * .22 }); },
  roll: () => { for (let i = 0; i < 14; i++) tone(70 + i * 5, .12, { to: 45, v: .07 + i * .012, at: i * .075 }); noise(1.1, { f: 400, to: 4000, v: .07 }); },
  boom10: () => { tone(80, 1.2, { to: 25, v: .7 }); noise(1, { type: 'lowpass', f: 5000, to: 150, v: .3 }); [1568, 2093, 2637].forEach((f, i) => tone(f, 1.2, { v: .05, at: .05 + i * .07 })); },
  perfect: () => { [262, 330, 392, 523, 659].forEach(f => tone(f, 2.6, { v: .05, a: .35, at: .1 })); [784, 1047, 1319, 1568, 2093].forEach((f, i) => tone(f, .8, { type: 'triangle', v: .05, at: .5 + i * .12 })); noise(1.4, { f: 4000, to: 10000, v: .06, at: .3 }); },
  morph: () => { [262, 330, 392, 523].forEach(f => tone(f, 2.8, { v: .05, a: 1.4 })); for (let i = 0; i < 12; i++) tone(700 + i * 150, .5, { type: 'triangle', v: .03 + i * .004, at: i * .22 }); noise(2.8, { f: 500, to: 9000, v: .06 }); tone(55, 2.8, { to: 110, v: .25, a: 1.2 }); },
  tier: j => { tone(NOTES[j], .7, { type: 'triangle', v: .14 }); tone(NOTES[j] * 2, .5, { v: .05 }); noise(.25, { f: 4000, to: 7000, v: .04 }); if (j >= 2) { noise(.4, { f: 3000, to: 9000, v: .05 }); tone(NOTES[j] * 3, .5, { v: .03, at: .05 }); } },
  final: k => {
    tone(110, .7, { to: 32, v: .6 }); noise(.7, { type: 'lowpass', f: 3000, to: 200, v: .22 });
    if (!k) { tone(262, .9, { to: 196, type: 'triangle', v: .1, at: .1 }); return; }
    [523, 659, 784, 1047, 1319, 1568].slice(0, k + 1).forEach((f, i) => tone(f, 1.6, { type: 'triangle', v: .06, at: .08 + i * .06 }));
    if (k > 2) for (let i = 0; i < 6; i++) tone(1000 + i * 260, .5, { v: .04, at: .25 + i * .08 });
  }
};
const fx = (f, ...a) => { if (!skip) f(...a); };
const sleep = ms => new Promise(r => { if (skip) return r(); const t = setTimeout(() => { pend.delete(done); r(); }, ms), done = () => { clearTimeout(t); pend.delete(done); r(); }; pend.add(done); });
const wait = sel => new Promise(r => $(sel).addEventListener('click', r, { once: true }));
const flash = (p, c) => { fl.style.setProperty('--fp', p); fl.style.setProperty('--fc', c || '#fff'); fl.classList.remove('go'); void fl.offsetWidth; fl.classList.add('go'); };
const mk = (cls, vars, life) => { const e = document.createElement(cls ? 'em' : 'i'); if (cls) e.className = cls; for (const k in vars) e.style.setProperty(k, vars[k]); pt.appendChild(e); setTimeout(() => e.remove(), life); };
const ring = c => mk('rg', { '--c': c }, 1000);
const dust = (c, n, bx = '50%', by = '50%') => { for (let j = 0; j < n; j++) { const a = rnd(0, 6.283), d = rnd(110, 300); mk('', { '--bx': bx, '--by': by, '--x': Math.cos(a) * d + 'px', '--y': Math.sin(a) * d + 'px', '--c': j % 3 ? c : '#fff7d6', '--z': rnd(3, 7) + 'px' }, 1600); } };
const rays = (c, n) => { for (let j = 0; j < n; j++) mk('rl', { '--c': c, '--a': (j * 360 / n + rnd(-8, 8)).toFixed(0) + 'deg', '--l': rnd(180, 340).toFixed(0) + 'px' }, 900); };
const rain = c => { for (let j = 0; j < 20; j++) mk('rn', { '--l': rnd(0, 100) + '%', '--d': rnd(0, 1.4) + 's', '--c': j % 2 ? c : '#fff7d6' }, 3600); };
// Hoe zeldzamer het niveau, hoe meer er bij de ring komt: vonken, lichtstralen, een lichtpilaar en gouden regen
const tierFx = (c, j, final) => {
  ring(c);
  setTimeout(() => ring(c), 160);
  dust(c, Math.min(40, final ? j * 10 + 8 : 4 + j * 5));
  if (j >= 2) rays(c, final ? 8 + j * 2 : 4 + j * 2);
  if (j >= 3) mk('pil', { '--c': c }, 1100);
  if (final && j >= 4) rain(c);
  gl.classList.remove('pu'); void gl.offsetWidth; gl.classList.add('pu');
};
// Tekst kleiner maken tot hij binnen de ruimte past
const fit = (el, maxEm, maxPx) => {
  el.style.fontSize = maxEm + 'em';
  const lim = maxPx || el.clientWidth, w = el.scrollWidth;
  if (lim > 0 && w > lim) el.style.fontSize = (maxEm * lim / w * 0.96).toFixed(2) + 'em';
};
const fitCrest = r => { const e = r.querySelector('.crest'); if (e) fit(e.querySelector('b'), 3.1, 6.4 * parseFloat(getComputedStyle(e).fontSize)); };
let gen = 0;
// Sterretjes die van een element afkomen
const sparkle = (el, n) => {
  const r = el.getBoundingClientRect(), o = ov.getBoundingClientRect();
  for (let j = 0; j < n; j++) mk('sk', { '--l': (r.left - o.left + rnd(0, r.width)).toFixed(0) + 'px', '--t': (r.top - o.top + rnd(0, r.height)).toFixed(0) + 'px', '--s': rnd(8, 18).toFixed(0) + 'px', '--dx': rnd(-50, 50).toFixed(0) + 'px', '--dy': rnd(-140, -50).toFixed(0) + 'px', '--d': rnd(1.1, 1.8).toFixed(2) + 's' }, 2000);
};
// Stukjes folie die bij het scheuren wegvliegen
const shards = n => { for (let j = 0; j < n; j++) { const a = rnd(0, 6.283), d = rnd(120, 340); mk('fs', { '--x': Math.cos(a) * d + 'px', '--y': Math.sin(a) * d + 'px', '--r': rnd(-540, 540).toFixed(0) + 'deg', '--z': rnd(8, 18).toFixed(0) + 'px', '--c': j % 3 ? '#e3b94f' : '#1a1e2d' }, 1500); } };
// Sterretjes die blijven twinkelen op de kaart
const twinkle = (c, n) => { for (let j = 0; j < n; j++) { const e = document.createElement('i'); e.className = 'tw'; e.style.setProperty('--l', rnd(-6, 106).toFixed(0) + '%'); e.style.setProperty('--t', rnd(-4, 104).toFixed(0) + '%'); e.style.setProperty('--s', rnd(.9, 2.2).toFixed(2) + 'em'); e.style.setProperty('--d', rnd(0, 1.8).toFixed(2) + 's'); c.appendChild(e); } };
const fireworks = g => [['#f6d675', 100], ['#c79bff', 450], ['#fff1b0', 800], ['#f6d675', 1150]].forEach(([c, t]) => setTimeout(() => { if (g !== gen) return; const o = ov.getBoundingClientRect(); dust(c, 22, rnd(.15, .85) * o.width + 'px', rnd(.12, .6) * o.height + 'px'); }, t));
const segFx = R => { ring(R ? '#f6d675' : '#8aa2ff'); dust(R ? '#f6d675' : '#d6ae52', R ? 18 : 6); if (R) flash(0.3); };
// Onvoldoende: duimpjes omlaag en boze gezichten verschijnen en zakken weg
const EMO = ['👎', '😡', '👎', '😠', '👎', '🤬'];
const sad = n => { for (let j = 0; j < n; j++) { const e = document.createElement('em'); e.className = 'eo'; e.textContent = EMO[j % EMO.length]; e.style.setProperty('--l', rnd(8, 92).toFixed(0) + '%'); e.style.setProperty('--t', rnd(12, 80).toFixed(0) + '%'); e.style.setProperty('--s', rnd(28, 64).toFixed(0) + 'px'); e.style.setProperty('--d', (j * 0.07 + rnd(0, 0.25)).toFixed(2) + 's'); e.style.setProperty('--r', rnd(-25, 25).toFixed(0) + 'deg'); pt.appendChild(e); setTimeout(() => e.remove(), 3200); } };
// Langzame kleurovergang van Icon naar Perfect
async function morph(c, tr) {
  c.classList.add('morph');
  fx(sfx.morph);
  ov.style.setProperty('--tc', '#c79bff'); fx(ring, '#c79bff'); fx(sparkle, c, 6);
  await sleep(700);
  tr.classList.add('fo');
  ov.style.setProperty('--tc', '#e3b94f'); fx(ring, '#e3b94f'); fx(sparkle, c, 8); fx(flash, 0.2);
  await sleep(500);
  tr.textContent = 'Perfect'; tr.classList.remove('fo');
  c.style.setProperty('--tx', '#f6d675');
  await sleep(500);
  c.classList.add('late');
  ov.style.setProperty('--tc', '#f6d675'); fx(ring, '#f6d675'); fx(sparkle, c, 10);
  await sleep(1100);
}

// Pack: gekartelde scheurlijn in het midden, bovenste en onderste helft
const poly = a => 'polygon(' + a.map(p => p[0].toFixed(1) + '% ' + p[1].toFixed(1) + '%').join(',') + ')';
const tearLine = []; for (let i = 0; i <= 20; i++) tearLine.push([i * 5, 46 + (i % 2 ? 2.6 : 0)]);
const TOP = poly([[0, 0], [100, 0], ...[...tearLine].reverse()]), BOT = poly([...tearLine, [100, 100], [0, 100]]);
const teeth = (y, dy, rev) => { const a = []; for (let i = 0; i <= 44; i++) a.push([i * 100 / 44, y + (i % 2 ? dy : 0)]); return rev ? a.reverse() : a; };
const POUCH = poly([...teeth(0, 0.7), ...teeth(100, -0.7, true)]);
const face = () => `<div class="pf"><i class="pk"></i><i class="pk b"></i><i class="cr"></i><i class="cr b"></i><div class="lg">${logo()}</div><s></s></div>`;
const pack = R => `<button class="pack${R ? ' royal' : ''}"><div class="aura"></div><div class="whole">${face()}</div><div class="half t">${face()}</div><div class="half b">${face()}</div><div class="slit"></div></button>`;

const crest = s => `<div class="crest"><i></i><b>${esc(mono(s))}</b></div>`;
const LINE = '<svg class="fr" viewBox="0 0 200 284" preserveAspectRatio="none"><polygon points="9,22 25,9 175,9 191,22 191,252 100,274 9,252" fill="none" stroke="currentColor" stroke-width="1.2" stroke-opacity=".55" vector-effect="non-scaling-stroke"/></svg>';
const card = p => `<div class="cw r-common"><div class="halo"></div><div class="card"><div class="edge"></div>${p.grade >= 10 ? '<div class="moe"></div>' : ''}<div class="in"><div class="pat"></div>${p.grade >= 10 ? '<i class="mo mo1"></i><i class="mo mo2"></i><i class="mo mo3"></i><i class="fl2"></i>' : ''}<s class="sh"></s></div>${LINE}<div class="rt">0,0</div><div class="tr">Common</div>${crest(p.subject)}<div class="nm">${esc(p.subject.toUpperCase())}</div><div class="rule"></div><div class="stats"><div><small>Toets</small><span class="t">${esc(p.desc || 'Cijfer')}</span></div><div><small>Weging</small><span>${p.weight ? '×' + String(p.weight).replace('.', ',') : '–'}</span></div></div></div></div>`;

// Walkout: een onderdeel per keer, elk schuift binnen en weer weg
async function seg(k, body, hold, fs, R) {
  st.innerHTML = `<div class="seg"><p class="k">${k}</p>${body}<i class="ul"></i></div>`;
  const h = st.querySelector('h2');
  if (h) h.style.fontSize = fs + 'em';
  fitCrest(st);
  fx(segFx, R);
  fx(sfx.seg);
  await sleep(hold);
  st.firstElementChild.classList.add('out');
  await sleep(380);
}

async function run(p, i, n, onOpened) {
  const g = ++gen;
  skip = false;
  ov.className = 'ov';
  ov.style.setProperty('--tc', '#d6ae52');
  pt.innerHTML = '';
  const k = tierOf(p.grade), T = TIERS[k], desc = p.desc || 'Cijfer', R = k === 5;   // R: een 10
  hd.textContent = `Pack ${i + 1} van ${n}`;
  let emit = 0, hb = 0;
  try {
    // 1. De pack. Bij een 10 hangt er al iets in de lucht.
    if (R) { ov.classList.add('royal'); ov.style.setProperty('--tc', '#c79bff'); }
    st.innerHTML = pack(R) + `<p class="hint">${R ? 'Er hangt iets in de lucht…' : 'Tik om te openen'}</p>`;
    st.querySelectorAll('.pf').forEach(e => { e.style.clipPath = POUCH; });
    $('.half.t').style.clipPath = TOP;
    $('.half.b').style.clipPath = BOT;
    const pk = $('.pack');
    if (R) { emit = setInterval(() => sparkle(pk, 2), 130); hb = setInterval(() => fx(sfx.beat), 1100); }
    await wait('.pack');
    audio();
    clearInterval(hb);
    pk.classList.add('tear');
    $('.hint').remove();
    if (R) {
      pk.classList.add('long');
      clearInterval(emit); emit = setInterval(() => sparkle(pk, 6), 70);
      ov.classList.add('rumble');
      [500, 1000, 1400].forEach(t => setTimeout(() => { if (g === gen && !skip) flash(0.4); }, t));
      fx(sfx.charge10);
    } else fx(sfx.charge);
    await sleep(R ? 1700 : 800);
    ov.classList.remove('rumble');
    pk.classList.add('split');
    st.classList.add('punch'); setTimeout(() => st.classList.remove('punch'), 500);
    flash(R ? 1 : 0.8); ring('#f3d98a'); shards(R ? 30 : 14);
    if (R) {
      ring('#c79bff'); setTimeout(() => ring('#fff'), 150);
      dust('#f6d675', 40); rays('#f6d675', 14); mk('pil', { '--c': '#f6d675' }, 1100);
      clearInterval(emit); emit = setInterval(() => sparkle(st, 2), 140);
    }
    fx(sfx.split); if (R) fx(sfx.boom10);
    await sleep(R ? 1000 : 850);

    // 2. Walkout: vak, toets, weging
    await seg('Vak', crest(p.subject) + `<h2>${esc(p.subject)}</h2>`, R ? 1700 : 1500, 3.2, R);
    await seg('Toets', `<h2>${esc(desc)}</h2>`, R ? 1600 : 1400, fitDesc(desc), R);
    if (p.weight) await seg('Weging', `<h2>×${String(p.weight).replace('.', ',')}</h2>`, R ? 1500 : 1300, 5, R);
    clearInterval(emit);

    // 3. De kaart loopt langs de niveaus tot het echte niveau
    st.innerHTML = card(p);
    const c = st.querySelector('.cw'), rt = c.querySelector('.rt'), tr = c.querySelector('.tr');
    const base = parseFloat(getComputedStyle(c).fontSize);
    rt.textContent = '9,9';
    fit(rt, 5, 8.2 * base);
    const rtFs = parseFloat(rt.style.fontSize);
    const setRt = t => { rt.textContent = t; rt.style.fontSize = (t.length > 3 ? rtFs * .75 : rtFs) + 'em'; };
    fit(c.querySelector('.nm'), 1.9);
    fitCrest(c);
    c.querySelector('.stats .t').style.fontSize = (desc.length <= 14 ? 1.5 : desc.length <= 26 ? 1.15 : 0.95) + 'em';
    fx(sfx.rise);
    const roll = setInterval(() => { setRt(fmt(rnd(1, 9.9))); fx(sfx.tick); }, 90);
    await sleep(900);
    for (let j = 0; j <= k; j++) {
      if (R && j === 5) {   // stilte voor de storm, daarna een lange kleurovergang van Icon naar Perfect
        ov.classList.add('dark');
        c.classList.add('flowicon');
        fx(sfx.roll);
        for (let q = 0; q < 4; q++) { fx(flash, 0.1 + q * 0.06); await sleep(180); }
        ov.classList.remove('dark');
        await morph(c, tr);
      }
      c.className = `cw r-${TIERS[j][0]}`;
      tr.textContent = TIERS[j][1]; fit(tr, .95, 8.4 * base);
      ov.style.setProperty('--tc', TIERS[j][3]);
      flash(j === 5 ? 0.7 : 0.25);
      if (j < k) fx(tierFx, TIERS[j][3], j, false);
      fx(sfx.tier, j);
      await sleep(j < k ? (R ? 450 : 600) : 350);
    }

    // 4. Het cijfer
    clearInterval(roll);
    setRt(fmt(p.grade));
    c.classList.add('slam', 'shine');
    ov.classList.add('shake');
    flash(R ? 1 : 0.85, k === 0 ? '#ff4b4b' : ''); tierFx(T[3], k, true); ring('#fff');
    if (R) {
      ring('#c79bff'); setTimeout(() => ring('#f6d675'), 200);
      fireworks(g); twinkle(c, 12);
      emit = setInterval(() => sparkle(c, 1), 180);
    }
    sfx.final(k); if (R) sfx.perfect();
    if (k === 0) { sfx.sad(); sad(14); setTimeout(() => { if (g === gen) sad(10); }, 500); setTimeout(() => { if (g === gen) sad(8); }, 1000); }
    await onOpened(p);
    await sleep(R ? 700 : 500);
    c.classList.remove('slam');
    ov.classList.remove('shake');
    st.insertAdjacentHTML('beforeend', `<button class="nx">${i + 1 < n ? 'Volgende pack' : 'Klaar'}</button>`);
    await wait('.nx');
  } finally {
    clearInterval(emit); clearInterval(hb);
  }
}

async function open(list, onOpened = async () => {}) {
  audio();
  busy = true;
  ov.hidden = false;
  for (let i = 0; i < list.length; i++) await run(list[i], i, list.length, onOpened);
  ov.hidden = true;
  st.innerHTML = '';
  busy = false;
}

const setLogo = u => { logoUrl = u; host.style.setProperty('--logo', 'url("' + u + '")'); };
globalThis.MPO = { root, open, logo, setLogo, get busy() { return busy; } };
})();
