const $ = s => document.querySelector(s), S = chrome.storage.local;
const load = cb => S.get(['enabled', 'pending', 'school', 'synced', 'err', 'requeue'], cb);
const show = v => {
  $('#n').textContent = v.pending || 0;
  const st = $('#st');
  st.className = v.err ? 'err' : '';
  st.textContent = v.err ? 'Kon cijfers niet ophalen: ' + v.err : v.synced ? v.school : 'Open Magister om te synchroniseren.';
};
load(v => { $('#on').checked = v.enabled !== false; show(v); });
$('#on').onchange = e => S.set({ enabled: e.target.checked });
$('#rq').onclick = () => {
  const b = $('#rq'), st = $('#st');
  b.disabled = true; st.className = ''; st.textContent = 'Bezig\u2026';
  S.set({ requeue: Date.now() });   // een nieuwe waarde per klik, zodat elke klik opgepikt wordt
  let t = 0;
  const iv = setInterval(() => load(v => {
    if (!v.requeue) { clearInterval(iv); b.disabled = false; show(v); }
    else if (++t > 16) { clearInterval(iv); b.disabled = false; st.textContent = 'Open eerst Magister in een tabblad. Zodra die geladen is, worden je oude cijfers als packs klaargezet.'; }
  }), 500);
};
