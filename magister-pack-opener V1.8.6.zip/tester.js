(() => {
const $ = s => document.querySelector(s);
const TN = [['Common', '#e2474b', -1, 4.8], ['Rare', '#cfd6e3', 5.5, 6.4], ['Legendary', '#f5a623', 7, 7.9], ['Mythic', '#8a6cff', 8.5, 8.9], ['Icon', '#ffe9a8', 9.5, 9.8], ['Perfect', '#f6d675', 10, 10]];
const tier = g => TN.reduce((k, t, i) => g >= t[2] ? i : k, 0);
const num = v => parseFloat(String(v).replace(',', '.'));
const fmt = g => g.toFixed(1).replace('.', ',');
const pick = a => a[Math.floor(Math.random() * a.length)];
const SUBJ = ['Wiskunde', 'Nederlands', 'Engels', 'Biologie', 'Natuurkunde', 'Scheikunde', 'Geschiedenis', 'Aardrijkskunde', 'Economie', 'Frans'];
const DESC = ['SO hoofdstuk 3', 'Proefwerk', 'Overhoring', 'Presentatie', 'Toets H5', 'Leesdossier'];
let list = [], id = 0;
try { list = JSON.parse(localStorage.getItem('mpo-tester') || '[]'); id = list.reduce((m, p) => Math.max(m, p.id), 0); } catch (e) { list = []; }
const mk = (subject, desc, weight, grade) => ({ id: ++id, subject, desc, weight, grade });
const rg = () => { const g = 6.9 + (Math.random() + Math.random() + Math.random() - 1.5) * 2.4; return Math.random() < .03 ? 10 : Math.round(Math.min(10, Math.max(1, g)) * 10) / 10; };
const rp = (g = rg()) => mk(pick(SUBJ), pick(DESC), 1 + Math.floor(Math.random() * 3), g);
const play = l => { if (MPO.busy || !l.length) return; MPO.open(l.map(p => ({ ...p }))); };
const cur = () => { const g = num($('#g').value); if (!(g >= 1 && g <= 10)) { $('#g').focus(); return null; } const w = num($('#w').value); return mk($('#s').value.trim() || 'Wiskunde', $('#d').value.trim(), w > 0 ? w : 0, g); };
const mkEl = (t, x) => { const e = document.createElement(t); if (x) e.textContent = x; return e; };

function draw() {
  try { localStorage.setItem('mpo-tester', JSON.stringify(list)); } catch (e) {}
  $('#cnt').textContent = list.length;
  const sw = list.reduce((a, p) => a + p.weight, 0), avg = sw ? list.reduce((a, p) => a + p.grade * p.weight, 0) / sw : 0;
  const c = TN.map(() => 0); list.forEach(p => c[tier(p.grade)]++);
  $('#sts').textContent = list.length ? 'Gewogen gemiddelde ' + fmt(avg) + ' · ' + TN.map((t, i) => c[i] ? t[0] + ' ×' + c[i] : '').filter(Boolean).join(' · ') : 'De lijst is leeg.';
  const box = $('#list'); box.textContent = '';
  list.forEach((p, i) => {
    const r = mkEl('div'); r.className = 'item';
    const g = mkEl('b', fmt(p.grade)); g.style.color = TN[tier(p.grade)][1];
    const s = mkEl('span', p.subject), sm = mkEl('small', (p.desc ? p.desc + ' · ' : '') + 'weging ' + fmt(p.weight).replace(/,0$/, ''));
    s.append(mkEl('br'), sm);
    const o = mkEl('button', '▶'); o.title = 'Alleen dit pack openen'; o.onclick = () => play([p]);
    const x = mkEl('button', '×'); x.title = 'Verwijderen'; x.onclick = () => { list.splice(i, 1); draw(); };
    r.append(g, s, o, x); box.append(r);
  });
}
$('#add').onclick = () => { const p = cur(); if (p) { list.push(p); draw(); } };
$('#one').onclick = () => { const p = cur(); if (p) play([p]); };
$('#all').onclick = () => play(list);
$('#clr').onclick = () => { list = []; draw(); };
$('#up').onclick = () => { list.sort((a, b) => a.grade - b.grade); draw(); };
$('#dn').onclick = () => { list.sort((a, b) => b.grade - a.grade); draw(); };
$('#mix').onclick = () => { for (let i = list.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [list[i], list[j]] = [list[j], list[i]]; } draw(); };
$('#rnd').onclick = () => { list.push(rp()); draw(); };
$('#rep').onclick = () => { for (let i = 0; i < 6; i++) list.push(rp()); draw(); };
$('#lvl').onclick = () => { TN.forEach(t => list.push(rp(t[3]))); draw(); };
TN.forEach(t => { const b = mkEl('button', t[0]); b.style.borderColor = t[1]; b.onclick = () => { list.push(rp(t[3])); draw(); }; $('#pre').append(b); });
draw();
})();
