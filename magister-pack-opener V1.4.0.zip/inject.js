// Draait in de pagina zelf. Onthoudt het Bearer-token dat Magister voor zijn eigen /api/-verzoeken gebruikt.
(() => {
  const save = (url, auth) => {
    if (/\/api\//.test(url) && /^Bearer\s+\S+/i.test(auth || '')) {
      document.documentElement.dataset.mpoTok = auth.replace(/^Bearer\s+/i, '');
    }
  };
  const header = (h, k) => {
    if (!h) return '';
    if (h.get) return h.get(k) || '';
    if (Array.isArray(h)) { const e = h.find(x => String(x[0]).toLowerCase() === k); return e ? e[1] : ''; }
    const n = Object.keys(h).find(x => x.toLowerCase() === k);
    return n ? h[n] : '';
  };
  const f = window.fetch;
  window.fetch = function (i, o) {
    try { save(String((i && i.url) || i), header(o && o.headers, 'authorization') || header(i && i.headers, 'authorization')); } catch (e) {}
    return f.apply(this, arguments);
  };
  const open = XMLHttpRequest.prototype.open, setH = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function (m, u) { this._mpoUrl = String(u); return open.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    try { if (String(k).toLowerCase() === 'authorization') save(this._mpoUrl || '', v); } catch (e) {}
    return setH.apply(this, arguments);
  };
})();
