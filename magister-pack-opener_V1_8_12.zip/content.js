(() => {
const S = chrome.storage.local;
const get = k => new Promise(r => S.get(k, r));
const set = o => new Promise(r => S.set(o, r));
const sleep = ms => new Promise(r => setTimeout(r, ms));
let packs = [], pid = null, syncing = false, dismissed = false, enabled = true, allItems = [];
// Cijfercalculator (calc.js): krijgt alleen cijfers waarvan het pack al open is of die er al waren, nooit cijfers die nog in een pack zitten.
const feed = () => { if (globalThis.MPOCalc) MPOCalc.setGrades(allItems.filter(x => !packs.some(p => p.id === x.id)), packs.length); };
if (globalThis.MPOCalc) MPOCalc.onWide = () => sync();   // calculator geopend: opnieuw ophalen, dan tot 300 cijfers

// Zolang we nog niet zeker weten of er packs klaarstaan, dekken we de cijferpagina af (hooguit GUARD ms).
const FRESH = 45000, GUARD = 6000;
let init = false, loaded = false, lastOk = 0, hint = 0, until = Date.now() + GUARD, navUntil = 0, wasGrades = false;
let firstDone;
const first = new Promise(r => firstDone = r);

const realGrades = () => /cijfers/i.test(location.href);
const isGrades = () => realGrades() || Date.now() < navUntil;   // navUntil: net op "cijfers" geklikt, URL volgt zo
const stale = () => Date.now() - lastOk > FRESH;
const tok = () => document.documentElement.dataset.mpoTok || '';

// Roept de Magister-API aan met het token dat de pagina zelf al gebruikt (inject.js).
async function api(path) {
  for (let i = 0; i < 40 && !tok(); i++) await sleep(500);
  const r = await fetch(path, { headers: { Authorization: 'Bearer ' + tok() } });
  if (r.status === 401) delete document.documentElement.dataset.mpoTok;
  if (!r.ok) throw new Error('API ' + r.status + ' ' + path.split('?')[0]);
  return r.json();
}

const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const norm = g => {
  const n = parseFloat(String(g.waarde).replace(',', '.')), v = g.vak || {};
  return n >= 1 && n <= 10
    ? { id: String(g.kolomId ?? `${v.code}|${g.omschrijving}|${g.ingevoerdOp}`), subject: cap(v.omschrijving || v.code || 'Vak'), desc: g.omschrijving || '', weight: g.weegfactor, grade: n, at: g.ingevoerdOp || '' }
    : null;
};

// Statistieken: per cijfer-id alleen het niveau (0-5), nooit het cijfer zelf.
// Omdat het per id is opgeslagen, kan een cijfer maar één keer meetellen, ook niet na "oude cijfers ook als packs".
async function addStats(list) {
  const sk = 's' + pid, st = (await get(sk))[sk] || {};
  let ch = false;
  for (const [id, t] of list) if (st[id] !== t) { st[id] = t; ch = true; }
  if (ch) await set({ [sk]: st });
}

const hash = async t => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)))].map(b => b.toString(16).padStart(2, '0')).join('');
// Packs van het account terugzetten. De website kent alleen afgeleide nummers (hash van pid en cijfer-id).
// Cijfers die nu in Magister staan, koppelen we er weer aan: ze tellen als geopend en komen niet opnieuw klaar te staan.
// De rest blijft als afgeleid nummer in de statistieken (h<pid>) en wordt overgezet zodra het cijfer weer in de lijst staat.
async function applyRestore(items, u, rq) {
  const sk = 's' + pid, hk = 'h' + pid, st = await get(['restoreCards', sk, hk]);
  const rc = st.restoreCards, s = st[sk] || {}, h = st[hk] || {};
  if (!rc && !Object.keys(h).length) return u;
  const left = { ...(rc || {}) }; let mapped = 0, ch = false;
  for (const x of items) {
    const k = await hash('mpo:' + pid + ':' + x.id), fromRc = k in left, fromH = k in h;
    if (!fromRc && !fromH) continue;
    const t = fromRc ? left[k] : h[k];
    if (s[x.id] === undefined) { s[x.id] = t; ch = true; }
    if (fromH) { delete h[k]; ch = true; }
    if (fromRc) { delete left[k]; mapped++; }
    // Op het account al geopend = hier ook geopend. Alleen bij "oude cijfers ook als packs" laten we overgezette cijfers weer als pack klaarstaan.
    if (fromRc || !rq) { if (!u.opened.includes(x.id)) u.opened.push(x.id); u.base = u.base.filter(i => i !== x.id); }
  }
  const kept = Object.keys(left).length;
  for (const [k, t] of Object.entries(left)) if (!(k in h)) { h[k] = t; ch = true; }
  if (rc) {
    const info = (await get('restoreInfo')).restoreInfo || {};
    await new Promise(r => chrome.storage.local.remove('restoreCards', r));
    await set({ restoreInfo: { ...info, done: true, applied: mapped, kept, at: Date.now() } });
  }
  if (ch) await set({ [sk]: s, [hk]: h });
  return u;
}

// Details van eerder geopende packs (vak, cijfer, omschrijving, weging) naar het account, alleen met het vinkje in het tabblad Account.
// Het cijfer zelf wordt nergens bewaard, dus dit kan alleen voor cijfers die nu in de lijst van Magister staan.
// Van wat al is doorgegeven, houdt de achtergrondfunctie een lijst met id's bij (d<pid>), zodat het niet steeds opnieuw gebeurt.
// Alleen packs die je zelf al hebt geopend gaan mee: cijfers waarvan je het pack nog niet hebt geopend blijven verborgen.
async function shareDetails(items, u, deep) {
  const dk = 'd' + pid, sk = 's' + pid, st = await get(['acct', dk, sk]);
  if (!st.acct || !st.acct.details) return;
  const done = new Set(st[dk] || []), s = st[sk] || {};
  const todo = items.filter(x => !done.has(x.id) && (s[x.id] !== undefined || u.opened.includes(x.id)));
  let sent = 0;
  if (todo.length) {
    const cards = todo.map(x => ({ id: x.id, tier: s[x.id] ?? MPO.tierOf(x.grade), d: { subject: x.subject, grade: x.grade, desc: x.desc, weight: x.weight } }));
    const r = await new Promise(res => { try { chrome.runtime.sendMessage({ type: 'share', pid, cards }, v => { void chrome.runtime.lastError; res(v || { ok: false }); }); } catch (e) { res({ ok: false }); } });
    if (!r.ok) return;   // mislukt: bij de volgende synchronisatie opnieuw
    sent = r.n || 0;
  }
  if (deep || sent) await set({ detailsInfo: { at: Date.now(), sent } });
  if (deep && (await get('detailsDeep')).detailsDeep === deep) await new Promise(r => S.remove('detailsDeep', r));   // een nieuwere klik blijft staan
}

// Alleen de id's van geopende cijfers worden bewaard, nooit de cijfers zelf.
let again = false, lastCount = 0;
async function sync() {
  if (syncing) { again = true; return; }
  if (!enabled) return;
  syncing = true;
  try {
    if (!pid) { const a = await api('/api/account'), pe = a.Persoon || a.persoon || {}; pid = pe.Id ?? pe.id; }
    const key = 'u' + pid, { requeue: rq, detailsDeep: deep } = await get(['requeue', 'detailsDeep']);
    // Gewoon: de laatste 50. Bij "ook oude cijfers", bij het delen van de details van eerdere packs of met de calculator open: tot 300 cijfers.
    const wide = !!(rq || deep), calcWide = !!(globalThis.MPOCalc && MPOCalc.wide());
    let items = [];
    for (let sk = 0; sk < (wide || calcWide ? 300 : 50); sk += 50) {
      const d = await api(`/api/personen/${pid}/cijfers/laatste?top=50&skip=${sk}`), page = d.items || d.Items || [];
      items = items.concat(page.map(norm).filter(Boolean));
      if (page.length < 50) break;
    }
    items = [...new Map(items.map(x => [x.id, x])).values()];
    let u = (await get(key))[key];
    if (u) await addStats(items.filter(x => u.opened.includes(x.id)).map(x => [x.id, MPO.tierOf(x.grade)]));   // eerder geopende packs meetellen
    if (!u) u = { base: rq ? [] : items.map(x => x.id), opened: [] };  // eerste keer: bestaande cijfers overslaan, tenzij je ze wilt
    else if (rq) { u.base = []; u.opened = []; }   // opnieuw: ook al geopende cijfers worden weer packs
    u = await applyRestore(items, u, rq);
    await set({ [key]: u });
    if (rq) { if ((await get('requeue')).requeue === rq) await set({ requeue: 0 }); dismissed = false; }   // een nieuwere klik tijdens het ophalen blijft staan
    packs = items.filter(x => !u.base.includes(x.id) && !u.opened.includes(x.id)).sort((a, b) => a.at < b.at ? -1 : 1);
    if (packs.length > lastCount) dismissed = false;
    lastCount = packs.length;
    allItems = items; feed();
    loaded = true; lastOk = Date.now(); hint = packs.length;
    await set({ pending: packs.length, school: location.hostname, synced: Date.now(), err: '', lastPid: pid });
    await shareDetails(wide ? items : items.slice(0, 50), u, deep).catch(e => console.warn('[Pack Opener] details delen', e));
  } catch (e) {
    console.warn('[Pack Opener]', e);
    until = 0;   // ophalen mislukt: niet eindeloos afdekken
    await set({ err: String(e.message || e) });
  } finally {
    syncing = false;
    firstDone();
    ui();
    if (again) { again = false; sync(); }
  }
}

const h = s => { const t = document.createElement('template'); t.innerHTML = s; return t.content.firstElementChild; };
const gate = h('<div class="gate" hidden><div><div class="gi">' + MPO.logo('gi') + '</div><h2></h2><p>Je cijfers blijven verborgen tot je ze uit een pack haalt.</p><button class="nx">Pack openen</button><button class="gh"></button></div></div>');
const pill = h('<button class="pill" hidden></button>');
MPO.root.append(gate, pill);
const q = (e, s) => e.querySelector(s);

// Het logo uit de map van de extensie; lukt dat niet, dan blijft het ingebouwde exemplaar.
const probe = u => new Promise(r => { const i = new Image(); i.onload = () => r(u); i.onerror = () => r(null); i.src = u; });
(async () => {
  const u = await probe(chrome.runtime.getURL('logo.png'));
  if (u) { MPO.setLogo(u); q(gate, '.gi').innerHTML = MPO.logo('gi'); }
})();

// Cijfers op de startpagina (kaart "Laatste cijfers", ook van andere extensies) verbergen zolang er packs klaarstaan.
// We zoeken de kop op tekst en bepalen aan de hand van de afmetingen wat de hele kaart is. De kop blijft zichtbaar.
const KEYS = ['laatste cijfers', 'cijferoverzicht', 'recente cijfers'];
const LOW = "translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')";
const XP = '//text()[' + KEYS.map(k => LOW + "='" + k + "'").join(' or ') + ']';
const has = n => { const t = (n.textContent || '').toLowerCase(); return KEYS.some(k => t.includes(k)); };
const sty = document.createElement('style');
sty.textContent = '.mpo-card *{visibility:hidden!important}.mpo-card .mpo-head,.mpo-card .mpo-head *{visibility:visible!important}';
document.documentElement.append(sty);
let mask = false;
function cardOf(h) {
  let a = h, pick = null;
  while (a.parentElement && a.parentElement !== document.body && a.parentElement !== document.documentElement) {
    const r = a.getBoundingClientRect();
    if (r.height > Math.max(380, innerHeight * .5) || r.width > innerWidth * .6) break;   // te groot: kolom of hele pagina
    if (r.height >= 90) pick = a;                                                        // groot genoeg om de hele kaart te zijn
    const p = a.parentElement;
    if (pick && [...p.children].some(c => c !== a && c.offsetHeight > 40 && !c.contains(h))) return pick;   // buren gevonden
    a = p;
  }
  return pick;
}
function clearMask() { document.querySelectorAll('.mpo-card,.mpo-head').forEach(e => e.classList.remove('mpo-card', 'mpo-head')); }
function scan() {
  if (!mask) return;
  clearMask();
  const r = document.evaluate(XP, document.documentElement, null, 7, null);
  for (let i = 0; i < r.snapshotLength; i++) {
    const h = r.snapshotItem(i).parentElement, c = h && cardOf(h);
    if (c) { c.classList.add('mpo-card'); h.classList.add('mpo-head'); }
  }
}
function setMask(on) {
  if (on === mask) return;
  mask = on;
  if (on) scan(); else clearMask();
}
new MutationObserver(ms => { if (mask && ms.some(m => m.type === 'characterData' ? has(m.target) : [...m.addedNodes].some(has))) scan(); })
  .observe(document.documentElement, { childList: true, subtree: true, characterData: true });

let last = '';
function ui() {
  if (!init) return;
  const g = isGrades(), live = Date.now() < until;
  // Voor de eerste sync gebruiken we het aantal van de vorige keer, zodat het scherm er meteen staat.
  const n = loaded ? packs.length : (live ? hint : 0);
  setMask(enabled && (n > 0 || (!loaded && live)));   // ook als je op "Later" drukt blijft de kaart verborgen
  const have = enabled && n > 0 && !MPO.busy;
  // Nog niet (recent) gecontroleerd en we staan op cijfers: eerst afdekken, dan pas kijken.
  const check = enabled && g && !MPO.busy && n === 0 && live && (!loaded || stale());
  const show = (have && (g || !dismissed)) || check;
  const sig = [show, have && !show, check, n, realGrades(), MPO.busy].join();
  if (sig === last) return;
  last = sig;
  gate.hidden = !show;
  pill.hidden = !(have && !show);
  q(gate, 'h2').textContent = check ? 'Cijfers controleren\u2026' : n === 1 ? 'Nieuw cijfer!' : n + ' nieuwe cijfers!';
  q(gate, 'p').hidden = q(gate, '.nx').hidden = q(gate, '.gh').hidden = check;
  q(gate, '.gh').textContent = realGrades() ? 'Terug' : 'Later';
  pill.textContent = n + (n === 1 ? ' pack klaar' : ' packs klaar');
}

// Reageer meteen op navigatie, niet pas bij de volgende tik van de timer.
function nav() {
  if (!init) return;
  const g = isGrades();
  if (g && !wasGrades) {
    until = Date.now() + GUARD;
    if (stale()) sync();   // vers bekijken of er nieuwe cijfers zijn
  }
  wasGrades = g;
  scan();   // de pagina kan net zijn (her)opgebouwd
  ui();
}

async function openPacks() {
  if (!loaded) await first;   // te snel geklikt: wacht tot de cijfers zijn opgehaald
  if (MPO.busy) return;       // dubbel klikken: er loopt al een pack-opening
  if (!packs.length) { ui(); return; }
  await MPO.open([...packs], async p => {
    const key = 'u' + pid, u = (await get(key))[key] || { base: [], opened: [] };
    if (!u.opened.includes(p.id)) u.opened.push(p.id);
    packs = packs.filter(x => x.id !== p.id);
    lastCount = packs.length; feed();
    await set({ [key]: u, pending: packs.length });
    await addStats([[p.id, MPO.tierOf(p.grade)]]);
    try {   // naar het account op de website, alleen als je hebt gekoppeld (de achtergrondfunctie beslist)
      const r = chrome.runtime.sendMessage({ type: 'card', pid, id: p.id, tier: MPO.tierOf(p.grade), openedAt: Date.now(), d: { subject: p.subject, grade: p.grade, desc: p.desc, weight: p.weight } });
      r && r.catch && r.catch(() => {});
    } catch (e) {}
  });
  ui();
}

q(gate, '.nx').onclick = openPacks;
pill.onclick = openPacks;
q(gate, '.gh').onclick = () => { if (realGrades()) history.back(); else { dismissed = true; ui(); } };

get(['enabled', 'pending']).then(v => {
  enabled = v.enabled !== false;
  hint = v.pending || 0;
  init = true;
  wasGrades = isGrades();
  ui();
  sync();
});
chrome.storage.onChanged.addListener(c => {
  if (c.enabled) enabled = c.enabled.newValue !== false;
  const dt = (c.detailsDeep && c.detailsDeep.newValue) || (c.acct && c.acct.newValue && c.acct.newValue.details && !(c.acct.oldValue && c.acct.oldValue.details));   // details net aangezet of gekoppeld met vinkje
  if (c.enabled || (c.requeue && c.requeue.newValue) || (c.restoreCards && c.restoreCards.newValue) || dt) sync();
});

window.addEventListener('hashchange', nav);
window.addEventListener('popstate', nav);
window.addEventListener('mpo-nav', nav);   // pushState/replaceState, doorgegeven door inject.js
// Al bij de klik op "Cijfers" afdekken, nog voordat Magister zijn pagina opbouwt.
document.addEventListener('click', e => {
  const a = e.target && e.target.closest && e.target.closest('a[href]');
  if (a && /cijfers/i.test(a.getAttribute('href') || '')) { navUntil = Date.now() + 1500; nav(); }
}, true);
document.addEventListener('visibilitychange', () => { if (!document.hidden && stale()) sync(); });
setInterval(nav, 200);
setInterval(() => { if (!document.hidden && !MPO.busy) sync(); }, 30000);
})();
