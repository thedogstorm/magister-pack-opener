// Sturen van geopende packs naar het account op je website. Doet niets zolang er niet is gekoppeld.
// De website herkent je aan de koppelcode (SP-XXXX-XXXX-XXXX-XXXX), die bij elke synchronisatie meegaat.
importScripts('config.js');
const S = chrome.storage.local;
const get = k => new Promise(r => S.get(k, r));
const set = o => new Promise(r => S.set(o, r));
const url = () => (typeof MPO_SYNC_URL === 'string' ? MPO_SYNC_URL.trim() : '');
const allowed = async () => !!url() && chrome.permissions.contains({ origins: [new URL(url()).origin + '/*'] });
const RARITY = ['Common', 'Rare', 'Legendary', 'Mythic', 'Icon', 'Perfect'];
// Het Magister-id gaat nooit mee: alleen een afgeleid nummer, zodat dezelfde kaart niet dubbel telt.
const hex = async t => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)))].map(b => b.toString(16).padStart(2, '0')).join('');
const normCode = t => { const c = String(t || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); return /^SP[A-Z0-9]{16}$/.test(c) ? 'SP-' + c.slice(2).match(/.{4}/g).join('-') : null; };

async function queue(cards) {
  const { acct, outbox = [] } = await get(['acct', 'outbox']);
  if (!acct) return;
  const m = new Map(outbox.map(c => [c.key, c]));
  cards.forEach(c => m.set(c.key, { ...(m.get(c.key) || {}), ...c }));
  await set({ outbox: [...m.values()] });
}
// Per account bewaren we welke geopende packs hun details (vak, cijfer, ...) al naar de wachtrij hebben gestuurd: een lijst met id's (d<pid>).
// Zo gaan details van eerder geopende packs precies één keer mee en niet bij elke synchronisatie opnieuw.
let dlock = Promise.resolve();
const locked = fn => { const p = dlock.then(fn); dlock = p.catch(() => {}); return p; };
const markShared = (pid, ids) => locked(async () => { const k = 'd' + pid, list = (await get(k))[k] || []; await set({ [k]: [...new Set([...list, ...ids])] }); });
const clearShared = () => locked(async () => { const ks = Object.keys(await get(null)).filter(k => /^d\d+$/.test(k)); if (ks.length) await new Promise(r => S.remove(ks, r)); });
const dropShare = async () => { await clearShared(); await new Promise(r => S.remove(['detailsDeep', 'detailsInfo'], r)); };
const fail = (msg, status, detail) => Object.assign(new Error(msg), { status, detail });
let busy = null;
const flush = force => busy || (busy = doFlush(force).finally(() => { busy = null; }));
async function doFlush(force) {
  const { acct, outbox = [] } = await get(['acct', 'outbox']);
  if (!acct || (!outbox.length && !force) || !(await allowed())) return;
  for (let i = 0; i === 0 || i < outbox.length; i += 200) {
    const batch = outbox.slice(i, i + 200), snap = new Map(batch.map(c => [c.key, JSON.stringify(c)]));
    let r;
    try { r = await fetch(url(), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: acct.code, version: chrome.runtime.getManifest().version, cards: batch }) }); }
    catch (e) { throw fail('Geen verbinding met de website.'); }
    if (r.status === 401 || r.status === 403) {
      const msg = 'De website herkent je koppelcode niet (meer). Kopieer op de website je huidige code en koppel opnieuw.';
      await set({ acct: null, outbox: [], acctErr: msg }); throw fail(msg, r.status);
    }
    if (!r.ok) {
      let t = ''; try { const j = await r.json(); t = String(j.error || j.message || '').slice(0, 120); } catch (e) {}
      const msg = 'Synchroniseren mislukt (' + r.status + ')' + (t ? ': ' + t : ''); await set({ acctErr: msg }); throw fail(msg, r.status, t);
    }
    const cur = (await get('outbox')).outbox || [];
    await set({ outbox: cur.filter(c => snap.get(c.key) !== JSON.stringify(c)), lastSync: Date.now(), acctErr: '' });
  }
}
// Het niveau mag als getal (0-5) of als naam (common, rare, legendary, mythic, icon, perfect) terugkomen, in `tier` of in `rarity`.
const TIER_NAMES = { common: 0, rare: 1, legendary: 2, mythic: 3, icon: 4, perfect: 5 };
const toTier = x => {
  for (const v of [x.tier, x.rarity]) {
    if (Number.isInteger(v) && v >= 0 && v <= 5) return v;
    if (typeof v === 'string') { const t = v.trim().toLowerCase(); if (t in TIER_NAMES) return TIER_NAMES[t]; if (/^[0-5]$/.test(t)) return +t; }
  }
  return -1;
};
async function restore() {
  const { acct } = await get('acct');
  if (!acct) throw new Error('Je bent niet gekoppeld.');
  if (!(await allowed())) throw new Error('Geen toestemming voor ' + new URL(url()).host + '.');
  if ((await get('lastPid')).lastPid === undefined) throw new Error('Open eerst Magister en log in, zodat de extensie weet om welk account het gaat. Probeer het daarna opnieuw.');
  let r;
  try { r = await fetch(url(), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: acct.code, version: chrome.runtime.getManifest().version, action: 'list' }) }); }
  catch (e) { throw new Error('Geen verbinding met de website.'); }
  if (r.status === 401 || r.status === 403) {
    const msg = 'De website herkent je koppelcode niet (meer). Kopieer op de website je huidige code en koppel opnieuw.';
    await set({ acct: null, outbox: [], acctErr: msg }); throw new Error(msg);
  }
  if (!r.ok) throw new Error('Terugzetten mislukt (' + r.status + ').');
  const j = await r.json().catch(() => ({}));
  if (!Array.isArray(j.cards)) throw new Error('De website stuurde geen lijst met kaarten terug. De sync-functie van de website moet de actie “list” kennen (zie de instructies).');
  const map = {};
  for (const x of j.cards) { const t = x ? toTier(x) : -1; if (t >= 0 && typeof x.key === 'string' && /^[0-9a-f]{16,64}$/.test(x.key)) map[x.key] = t; }
  const n = Object.keys(map).length;
  if (!n) { await set({ restoreInfo: { total: 0, done: true, applied: 0, kept: 0, at: Date.now() } }); return { total: 0 }; }
  await set({ restoreCards: map, restoreInfo: { total: n, done: false, at: Date.now() } });   // content.js past dit toe zodra Magister open staat
  return { total: n };
}
async function link(rawCode, details) {
  if (!url()) throw new Error('De website is nog niet ingesteld (config.js).');
  const code = normCode(rawCode);
  if (!code) throw new Error('Dit lijkt geen koppelcode. Die begint met SP- en heeft vier groepen van vier tekens.');
  if (!(await allowed())) throw new Error('Geen toestemming voor ' + new URL(url()).host + '.');
  await clearShared();
  // Met het vinkje voor details: de extensie deelt ook de details van packs die je al had geopend (zie content.js, shareDetails).
  await set({ acct: { code, details: !!details, since: Date.now() }, acctErr: '', ...(details ? { detailsDeep: Date.now() } : {}) });
  const cards = [];   // eerder geopende packs: alleen het niveau
  for (const [k, v] of Object.entries(await get(null))) {
    if (/^s\d+$/.test(k)) for (const [id, t] of Object.entries(v)) cards.push({ key: await hex('mpo:' + k.slice(1) + ':' + id), tier: t, rarity: RARITY[t] });
    if (/^h\d+$/.test(k)) for (const [key, t] of Object.entries(v)) cards.push({ key, tier: t, rarity: RARITY[t] });   // teruggezet: al een afgeleid nummer
  }
  await queue(cards);
  try { await flush(true); }   // altijd één bericht sturen: zo blijkt meteen of de website de code kent
  catch (e) {
    if (e.status >= 400 && e.status < 500 && e.status !== 429) { await set({ acct: null, outbox: [], acctErr: '' }); await dropShare(); throw new Error(e.status === 401 || e.status === 403 ? 'De website herkent deze code niet.' : e.message); }
    return { warn: e.message + ' De packs staan in de wachtrij en worden later verstuurd.' };
  }
  return {};
}
const kick = async () => { if (busy) await busy.catch(() => {}); return flush().catch(() => {}); };
chrome.runtime.onMessage.addListener((m, sender, send) => {
  if (sender.id !== chrome.runtime.id) return;
  (async () => {
    if (m.type === 'card') {
      const { acct } = await get('acct'); if (!acct) return {};
      const c = { key: await hex('mpo:' + m.pid + ':' + m.id), tier: m.tier, rarity: RARITY[m.tier], opened_at: new Date(m.openedAt).toISOString() };
      if (acct.details && m.d) Object.assign(c, { vak: m.d.subject, cijfer: m.d.grade, omschrijving: m.d.desc, weging: m.d.weight });
      await queue([c]);
      if (acct.details && m.d) await markShared(m.pid, [m.id]);
      await kick(); return {};
    }
    if (m.type === 'share') {   // details van eerder geopende packs (vak, cijfer, omschrijving, weging), alleen met het vinkje
      const { acct } = await get('acct'); if (!acct || !acct.details) return { n: 0 };
      const cards = [], ids = [];
      for (const x of Array.isArray(m.cards) ? m.cards : []) {
        if (!x || !x.d || !Number.isInteger(x.tier) || x.tier < 0 || x.tier > 5) continue;
        cards.push({ key: await hex('mpo:' + m.pid + ':' + x.id), tier: x.tier, rarity: RARITY[x.tier], vak: x.d.subject, cijfer: x.d.grade, omschrijving: x.d.desc, weging: x.d.weight });
        ids.push(x.id);
      }
      if (cards.length) { await queue(cards); await markShared(m.pid, ids); kick(); }   // niet wachten op het versturen zelf
      return { n: cards.length };
    }
    if (m.type === 'sharenow') {   // knop in het paneel: alles nog eens delen (ook als je de details op de website hebt gewist)
      const { acct } = await get('acct'); if (!acct || !acct.details) throw new Error('Zet eerst het vinkje voor vak en cijfer aan.');
      await clearShared(); await set({ detailsDeep: Date.now() }); return {};
    }
    if (m.type === 'flush') { await flush(true); return {}; }
    if (m.type === 'link') return link(m.code, m.details);
    if (m.type === 'restore') return restore();
    if (m.type === 'unlink') { await set({ acct: null, outbox: [], acctErr: '' }); await dropShare(); return {}; }   // alleen lokaal; op de website maak je een nieuwe code om de oude te laten vervallen
    if (m.type === 'details') {
      const { acct } = await get('acct'); if (!acct) return {};
      const was = !!acct.details, on = !!m.on;
      if (on && !was) { await clearShared(); await set({ acct: { ...acct, details: true }, detailsDeep: Date.now() }); }   // aanzetten: ook eerdere packs delen
      else { await set({ acct: { ...acct, details: on } }); if (!on) await dropShare(); }
      return {};
    }
    return {};
  })().then(r => send({ ok: true, ...r }), e => send({ ok: false, error: String(e.message || e) }));
  return true;
});
chrome.runtime.onStartup.addListener(() => flush().catch(() => {}));
