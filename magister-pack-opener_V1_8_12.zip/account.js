(() => {
const $ = id => document.getElementById(id);
const S = chrome.storage.local;
const syncUrl = typeof MPO_SYNC_URL === 'string' ? MPO_SYNC_URL.trim() : '';
const site = (typeof MPO_SITE === 'string' && MPO_SITE.trim()) || (syncUrl && new URL(syncUrl).origin) || '';
const ask = m => new Promise(res => chrome.runtime.sendMessage(m, r => res(r || { ok: false, error: (chrome.runtime.lastError || {}).message })));
const mask = c => c.slice(0, 6) + '…' + c.slice(-4);
async function render() {
  $('a-off').hidden = !!syncUrl;
  if (!syncUrl) { $('a-out').hidden = $('a-in').hidden = true; return; }
  const { acct, outbox = [], lastSync, acctErr, restoreCards, restoreInfo, detailsDeep, detailsInfo, lastPid } = await new Promise(r => S.get(['acct', 'outbox', 'lastSync', 'acctErr', 'restoreCards', 'restoreInfo', 'detailsDeep', 'detailsInfo', 'lastPid'], r));
  $('a-rs-p').hidden = !acct;
  $('a-out').hidden = !!acct; $('a-in').hidden = !acct;
  if (site) { $('a-site').href = site; $('a-site').textContent = 'je website'; }
  $('a-err').textContent = acctErr || '';
  if (!acct) return;
  $('a-who').textContent = mask(acct.code);
  $('a-st').textContent = (lastSync ? 'Laatst gesynchroniseerd: ' + new Date(lastSync).toLocaleString('nl-NL') : 'Nog niet gesynchroniseerd') + ' · in wachtrij: ' + outbox.length;
  $('a-det2').checked = !!acct.details;
  $('a-dtp').hidden = !acct.details;
  if (acct.details) {
    let m = '';
    if (detailsDeep) m = 'Bezig: open Magister (ingelogd) en laat het tabblad open staan. Zodra de extensie je cijfers heeft opgehaald, worden de details verstuurd.';
    else if (detailsInfo) {
      const keys = lastPid === undefined ? [] : ['s' + lastPid, 'd' + lastPid, 'h' + lastPid];
      const o = keys.length ? await new Promise(r => S.get(keys, r)) : {}, n = Object.keys(o['s' + lastPid] || {}).length + Object.keys(o['h' + lastPid] || {}).length, d = (o['d' + lastPid] || []).length;
      m = 'Laatst bijgewerkt: ' + new Date(detailsInfo.at).toLocaleString('nl-NL') + '. Details staan online van ' + d + ' van de ' + n + ' geopende packs.' + (d < n ? ' Van de rest staat alleen het niveau online: die cijfers staan niet meer in je lijst in Magister.' : '');
    }
    $('a-dtm').textContent = m;
  }
  const ri = restoreInfo || {};
  $('a-rsm').textContent = restoreCards ? ri.total + ' kaarten staan klaar. Laat Magister (ingelogd) open staan: ze worden dan toegepast.'
    : ri.done ? (ri.total ? 'Laatst teruggezet: ' + ri.total + ' kaarten op je account. ' + ri.applied + ' gekoppeld aan je huidige cijfers, ' + ri.kept + ' alleen in je statistieken.' : 'Er stonden nog geen packs op je account.') : '';
}
$('a-go').onclick = async () => {
  const m = $('a-msg'); m.textContent = 'Bezig…';
  try {
    const o = new URL(syncUrl).origin + '/*';
    if (!(await chrome.permissions.contains({ origins: [o] })) && !(await chrome.permissions.request({ origins: [o] }))) throw new Error('Zonder toestemming voor ' + new URL(syncUrl).host + ' kan de extensie niet koppelen.');
  } catch (e) { m.textContent = e.message; return; }
  const r = await ask({ type: 'link', code: $('a-code').value, details: $('a-det').checked });
  m.textContent = r.ok ? (r.warn || '') : (r.error || 'Koppelen mislukt.'); if (r.ok) $('a-code').value = '';
  render();
};
$('a-sync').onclick = async () => { $('a-err').textContent = ''; const r = await ask({ type: 'flush' }); if (!r.ok) $('a-err').textContent = r.error || 'Synchroniseren mislukt.'; render(); };
$('a-rs').onclick = async () => { const m = $('a-rsm'); m.textContent = 'Bezig…'; const r = await ask({ type: 'restore' }); if (!r.ok) m.textContent = r.error || 'Terugzetten mislukt.'; else render(); };
$('a-dt').onclick = async () => { const m = $('a-dtm'); m.textContent = 'Bezig…'; const r = await ask({ type: 'sharenow' }); if (!r.ok) m.textContent = r.error || 'Delen mislukt.'; else render(); };
$('a-un').onclick = async () => { await ask({ type: 'unlink' }); render(); };
$('a-det2').onchange = async () => { await ask({ type: 'details', on: $('a-det2').checked }); render(); };
chrome.storage.onChanged.addListener(render);
render();
})();
