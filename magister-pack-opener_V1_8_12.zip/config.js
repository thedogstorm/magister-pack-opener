// Adres van de sync-functie van de website (Base44). De extensie stuurt hier je geopende packs naartoe, alleen als je bent gekoppeld.
// Leeg laten = de accountfunctie staat uit en er gaat niets uit de browser naar een server.
const MPO_SYNC_URL = 'https://stormproductionsgroup.base44.app/functions/syncGrades';
// Adres van de website zelf (voor de link "je website" in het tabblad Account).
const MPO_SITE = 'https://stormproductionsgroup.base44.app';
