// Cijfercalculator in Magister: een klein rekenmachientje rechtsonder. Klik erop, klik daarna op cijfers uit je Magister
// om ze toe te voegen, en zie meteen je gemiddelde. Rekent zoals de Cijfer Calculator op de website.
// Alles blijft in het geheugen van deze pagina: de cijfers worden nergens bewaard of verstuurd.
(() => {
  const root = MPO.root, S = chrome.storage.local;
  const CSS = `
.mc-b{position:fixed;right:18px;bottom:18px;width:42px;height:42px;padding:0;display:grid;place-items:center;pointer-events:auto;background:#0d1019;color:#f1dfa6;border:1px solid rgba(214,174,82,.7);box-shadow:0 6px 24px rgba(0,0,0,.45)}
.mc-b:hover,.mc-b.on{background:#141828;color:#fff3c4;border-color:#d6ae52}
.mc-b svg{width:22px;height:22px}
.mc-p{position:fixed;right:18px;bottom:70px;width:min(400px,calc(100vw - 36px));max-height:min(680px,calc(100vh - 92px));display:flex;flex-direction:column;pointer-events:auto;background:linear-gradient(180deg,#141828,#0b0e18);border:1px solid rgba(214,174,82,.55);color:#f4efe2;box-shadow:0 12px 40px rgba(0,0,0,.6);font-size:14px}
.mc-hd{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid rgba(214,174,82,.3);flex:none}
.mc-hd b{font-size:13px;letter-spacing:.3em;text-transform:uppercase;color:#d6ae52}
.mc-hd button{width:28px;height:28px;padding:0;background:none;border:1px solid rgba(214,174,82,.45);color:#e7d7a8;font-size:16px;line-height:1}
.mc-sc{overflow:auto;padding:0 14px 14px;overscroll-behavior:contain}
.mc-k{margin:16px 0 6px;font-size:11px;letter-spacing:.24em;text-transform:uppercase;color:#d6ae52}
.mc-res{flex:none;margin:12px 14px 6px;padding:10px 14px;background:#0b0e18;border:1px solid rgba(214,174,82,.3)}
.mc-res .mc-k{margin:0}
.mc-big{font-size:38px;font-weight:800;line-height:1.1;color:#f1dfa6;font-variant-numeric:tabular-nums}
.mc-3{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:8px;padding-top:8px;border-top:1px solid rgba(214,174,82,.2)}
.mc-3 i{display:block;font-style:normal;font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:#8f96b0}
.mc-3 b{font:600 15px system-ui,sans-serif;color:#f4efe2}
.mc-by{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;max-height:56px;overflow:auto}.mc-by:empty{display:none}
.mc-by span{padding:3px 8px;border:1px solid rgba(214,174,82,.3);font:12px system-ui,sans-serif;color:#cdbb86}
.mc-by span b{color:#f4efe2;margin-left:4px}
.mc-w{margin:8px 0 0;font:12px/1.4 system-ui,sans-serif;color:#ff8a8a}
.mc-t{margin:6px 0 0;font:12px/1.45 system-ui,sans-serif;color:#8f96b0}
.mc-r{display:grid;grid-template-columns:1fr 1fr 28px;gap:6px;align-items:center;padding:6px 0;border-top:1px solid rgba(214,174,82,.15)}
.mc-r small{grid-column:1/-1;font:11px system-ui,sans-serif;color:#8f96b0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mc-hr{display:grid;grid-template-columns:1fr 1fr 28px;gap:6px;font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:#8f96b0}
.mc-p input,.mc-p select{width:100%;min-width:0;padding:7px 8px;background:#0b0e18;color:#f4efe2;border:1px solid rgba(214,174,82,.35);font:14px system-ui,sans-serif;border-radius:0}
.mc-p input:focus,.mc-p select:focus{outline:0;border-color:#d6ae52}
.mc-p input.bad{border-color:#ff8a8a}
.mc-x{width:28px;height:30px;padding:0;background:none;color:#8f96b0;font-size:16px;border:1px solid rgba(214,174,82,.2)}
.mc-x:hover{color:#ff8a8a;border-color:#ff8a8a}
.mc-bt{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:8px}
.mc-pri{padding:8px 14px;background:linear-gradient(180deg,#f3d98a,#c99a2e);color:#1f1600;font-size:12px;letter-spacing:.14em;text-transform:uppercase}
.mc-gh{padding:8px 12px;background:none;border:1px solid rgba(214,174,82,.45);color:#e7d7a8;font-size:12px;letter-spacing:.14em;text-transform:uppercase}
.mc-ln{background:none;color:#8f96b0;font-size:11px;letter-spacing:.16em;text-transform:uppercase;padding:6px 2px}
.mc-ln:hover{color:#d6ae52}
.mc-ml{margin-top:8px;max-height:210px;overflow:auto;border:1px solid rgba(214,174,82,.2)}
.mc-m{display:grid;grid-template-columns:18px 1fr auto;gap:8px;align-items:center;width:100%;padding:7px 10px;background:none;color:#f4efe2;text-align:left;font-weight:400;border-top:1px solid rgba(214,174,82,.12)}
.mc-m:first-child{border-top:0}
.mc-m:hover{background:rgba(214,174,82,.08)}
.mc-m.on{background:rgba(214,174,82,.14)}
.mc-m .mc-ck{width:16px;height:16px;border:1px solid rgba(214,174,82,.55);display:grid;place-items:center;font-size:12px;color:#1f1600}
.mc-m.on .mc-ck{background:#d6ae52}
.mc-m .mc-tx{min-width:0}
.mc-m .mc-tx b{display:block;font:700 13px var(--f);letter-spacing:.04em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mc-m .mc-tx i{display:block;font:normal 11px system-ui,sans-serif;color:#8f96b0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mc-m .mc-gr{font-size:18px;font-weight:800;color:#f1dfa6;font-variant-numeric:tabular-nums}
.mc-em{padding:12px;font:12px/1.4 system-ui,sans-serif;color:#8f96b0}
.mc-f{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.mc-f label{display:block;font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:#8f96b0;margin-bottom:4px}
.mc-need{margin-top:10px;padding:10px 12px;border:1px solid rgba(214,174,82,.3);background:#0b0e18;font:13px/1.45 system-ui,sans-serif;color:#cfd3e2}
.mc-need b{font:800 26px var(--f);color:#f1dfa6;margin:0 4px}
@media (max-width:480px){.mc-p{right:8px;bottom:64px;width:calc(100vw - 16px)}.mc-b{right:10px;bottom:10px}}
`;
  try { const sh = new CSSStyleSheet(); sh.replaceSync(CSS); root.adoptedStyleSheets = [...root.adoptedStyleSheets, sh]; }
  catch (e) { const st = document.createElement('style'); st.textContent = CSS; root.appendChild(st); }

  // --- rekenregels (zoals de Cijfer Calculator op de website) ---
  const pd = s => { const t = String(s).trim().replace(',', '.'); return t === '' ? NaN : Number(t); };
  const fmt = (n, d = 1) => n.toFixed(d).replace('.', ',');
  const fw = w => String(Math.round(w * 100) / 100).replace('.', ',');
  const compute = rows => {
    let sum = 0, W = 0, U = 0, n = 0, bad = 0; const by = new Map();
    for (const r of rows) {
      if (String(r.grade).trim() === '') continue;
      const g = pd(r.grade), w = String(r.weight).trim() === '' ? 1 : pd(r.weight);   // lege weging telt als 1
      if (!(g >= 1 && g <= 10) || !(w >= 0)) { bad++; continue; }
      sum += g * w; W += w; U += g; n++;
      if (r.subject) { const o = by.get(r.subject) || { s: 0, w: 0, n: 0 }; o.s += g * w; o.w += w; o.n++; by.set(r.subject, o); }
    }
    return { n, bad, W, sum, weighted: W > 0 ? sum / W : null, unweighted: n ? U / n : null, by };
  };

  // --- toestand (alleen in het geheugen) ---
  let rows = [], seq = 0, grades = [], pending = 0, open = false, enabled = true, subj = '';

  // --- opbouw ---
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const btn = el('button', 'mc-b', '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><rect x="5" y="2.5" width="14" height="19" rx="1.5"/><rect x="7.5" y="5" width="9" height="4" fill="currentColor" stroke="none" opacity=".85"/><g fill="currentColor" stroke="none"><circle cx="8.7" cy="12.6" r="1.1"/><circle cx="12" cy="12.6" r="1.1"/><circle cx="15.3" cy="12.6" r="1.1"/><circle cx="8.7" cy="15.6" r="1.1"/><circle cx="12" cy="15.6" r="1.1"/><circle cx="15.3" cy="15.6" r="1.1"/><circle cx="8.7" cy="18.6" r="1.1"/><circle cx="12" cy="18.6" r="1.1"/><circle cx="15.3" cy="18.6" r="1.1"/></g></svg>');
  btn.type = 'button'; btn.title = 'Cijfercalculator'; btn.setAttribute('aria-label', 'Cijfercalculator openen');
  const panel = el('div', 'mc-p');
  panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'Cijfercalculator');
  panel.innerHTML = `<div class="mc-hd"><b>Cijfercalculator</b><button type="button" class="mc-cl" aria-label="Sluiten">×</button></div>
<div class="mc-res"><div class="mc-k">Gewogen gemiddelde</div><div class="mc-big mc-wa">—</div>
 <div class="mc-3"><div><i>Ongewogen</i><b class="mc-ua">—</b></div><div><i>Cijfers</i><b class="mc-nn">0</b></div><div><i>Totale weging</i><b class="mc-tw">0</b></div></div>
 <div class="mc-by"></div><p class="mc-w" hidden></p></div>
<div class="mc-sc">
 <div class="mc-k">Jouw berekening</div>
 <div class="mc-hr"><span>Cijfer</span><span>Weging</span><span></span></div>
 <div class="mc-rl"></div>
 <div class="mc-bt"><button type="button" class="mc-gh mc-ad">+ Eigen cijfer</button><button type="button" class="mc-ln mc-wi">Alles wissen</button></div>
 <div class="mc-k">Cijfers uit Magister</div>
 <select class="mc-sj" aria-label="Filter op vak"></select>
 <div class="mc-bt"><button type="button" class="mc-gh mc-all">Voeg alle toe</button></div>
 <div class="mc-ml"></div>
 <p class="mc-t mc-pn" hidden></p>
 <div class="mc-k">Wat moet ik halen?</div>
 <div class="mc-f"><div><label>Streefcijfer</label><input class="mc-tg" value="5,5" inputmode="decimal"></div><div><label>Weging volgende toets</label><input class="mc-nw" value="1" inputmode="decimal"></div></div>
 <div class="mc-need mc-nd"></div>
 <p class="mc-t">Een lege weging telt als 1. Cijfers buiten 1,0 – 10,0 tellen niet mee. Alles blijft in deze pagina: er wordt niets bewaard of verstuurd.</p>
</div>`;
  panel.hidden = true; btn.hidden = true;
  root.appendChild(panel); root.appendChild(btn);   // na de rest, dus bovenop
  const q = s => panel.querySelector(s);
  const rl = q('.mc-rl'), ml = q('.mc-ml'), sj = q('.mc-sj');

  // --- resultaat ---
  function upd() {
    const c = compute(rows);
    q('.mc-wa').textContent = c.weighted == null ? '—' : fmt(c.weighted);
    q('.mc-ua').textContent = c.unweighted == null ? '—' : fmt(c.unweighted);
    q('.mc-nn').textContent = c.n; q('.mc-tw').textContent = c.W ? fw(c.W) : '0';
    const by = q('.mc-by'); by.textContent = '';
    if (c.by.size > 1 || (c.by.size === 1 && rows.some(r => !r.subject))) for (const [k, o] of c.by) { if (o.w > 0) { const s = el('span'); s.textContent = k; const b = el('b'); b.textContent = fmt(o.s / o.w); s.appendChild(b); by.appendChild(s); } }
    const w = q('.mc-w'); w.hidden = !c.bad; if (c.bad) w.textContent = c.bad === 1 ? 'Eén cijfer valt buiten 1,0 – 10,0 (of heeft een ongeldige weging) en telt niet mee.' : c.bad + ' cijfers vallen buiten 1,0 – 10,0 (of hebben een ongeldige weging) en tellen niet mee.';
    const t = pd(q('.mc-tg').value), nwRaw = q('.mc-nw').value.trim(), nw = nwRaw === '' ? 1 : pd(nwRaw), nd = q('.mc-nd');
    if (!(t >= 1 && t <= 10) || !(nw > 0)) { nd.textContent = 'Vul een streefcijfer (1,0 – 10,0) en een weging groter dan 0 in.'; return; }
    const need = (t * (c.W + nw) - c.sum) / nw;
    if (need <= 1) nd.textContent = 'Je streefcijfer is al veilig: elk cijfer volstaat.';
    else if (need > 10) nd.textContent = 'Niet haalbaar met één toets van deze weging: je zou een ' + fmt(need) + ' nodig hebben, en hoger dan een 10 kan niet.';
    else nd.innerHTML = 'Je hebt minimaal een <b>' + fmt(Math.ceil(need * 10 - 1e-9) / 10) + '</b> nodig voor een ' + fmt(t) + '.';
  }

  // --- jouw berekening ---
  function renderRows() {
    rl.textContent = '';
    for (const r of rows) {
      const d = el('div', 'mc-r'), g = el('input'), w = el('input'), x = el('button', 'mc-x', '×');
      g.value = r.grade; g.placeholder = 'bijv. 7,5'; g.inputMode = 'decimal'; g.setAttribute('aria-label', 'Cijfer');
      w.value = r.weight; w.placeholder = '1'; w.inputMode = 'decimal'; w.setAttribute('aria-label', 'Weging');
      x.type = 'button'; x.setAttribute('aria-label', 'Verwijderen');
      const mark = () => { const gv = pd(g.value); g.classList.toggle('bad', g.value.trim() !== '' && !(gv >= 1 && gv <= 10)); const wv = pd(w.value); w.classList.toggle('bad', w.value.trim() !== '' && !(wv >= 0)); };
      g.oninput = () => { r.grade = g.value; mark(); upd(); };
      w.oninput = () => { r.weight = w.value; mark(); upd(); };
      x.onclick = () => { rows = rows.filter(z => z !== r); renderRows(); renderMag(); upd(); };
      d.append(g, w, x);
      if (r.subject || r.desc) { const s = el('small'); s.textContent = [r.subject, r.desc].filter(Boolean).join(' · '); d.appendChild(s); }
      rl.appendChild(d); mark();
    }
  }
  const addGrade = g => rows.push({ id: ++seq, src: g.id, subject: g.subject, desc: g.desc, grade: String(g.grade).replace('.', ','), weight: g.weight == null ? '1' : String(g.weight).replace('.', ',') });
  q('.mc-ad').onclick = () => { rows.push({ id: ++seq, grade: '', weight: '1' }); renderRows(); upd(); const i = rl.querySelectorAll('input'); if (i.length) i[i.length - 2].focus(); };
  q('.mc-wi').onclick = () => { rows = []; renderRows(); renderMag(); upd(); };

  // --- cijfers uit Magister ---
  const shown = () => grades.filter(g => !subj || g.subject === subj);
  function renderMag() {
    const subs = [...new Set(grades.map(g => g.subject).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'nl'));
    if (subj && !subs.includes(subj)) subj = '';
    sj.textContent = ''; sj.appendChild(new Option('Alle vakken', '')); subs.forEach(s => sj.appendChild(new Option(s, s))); sj.value = subj;
    ml.textContent = '';
    const list = shown();
    if (!list.length) { const e = el('div', 'mc-em'); e.textContent = grades.length ? 'Geen cijfers voor dit vak.' : 'Nog geen cijfers gevonden. Open Magister en wacht even tot de lijst is geladen.'; ml.appendChild(e); }
    for (const g of list) {
      const on = rows.some(r => r.src === g.id), b = el('button', 'mc-m' + (on ? ' on' : ''));
      b.type = 'button'; b.setAttribute('aria-pressed', on);
      b.innerHTML = '<span class="mc-ck">' + (on ? '✓' : '') + '</span><span class="mc-tx"><b></b><i></i></span><span class="mc-gr"></span>';
      b.querySelector('b').textContent = g.subject || 'Cijfer'; b.querySelector('i').textContent = [g.desc, g.weight != null ? 'weging ' + fw(g.weight) : ''].filter(Boolean).join(' · ');
      b.querySelector('.mc-gr').textContent = fmt(g.grade, String(g.grade).includes('.') && String(g.grade).split('.')[1].length > 1 ? 2 : 1);
      b.onclick = () => { const i = rows.findIndex(r => r.src === g.id); if (i >= 0) rows.splice(i, 1); else addGrade(g); renderRows(); renderMag(); upd(); };
      ml.appendChild(b);
    }
    const p = q('.mc-pn'); p.hidden = !pending; if (pending) p.textContent = pending === 1 ? 'Eén cijfer staat nog in een pack en verschijnt hier zodra je het opent.' : pending + ' cijfers staan nog in een pack en verschijnen hier zodra je ze opent.';
  }
  sj.onchange = () => { subj = sj.value; renderMag(); };
  q('.mc-all').onclick = () => { for (const g of shown()) if (!rows.some(r => r.src === g.id)) addGrade(g); renderRows(); renderMag(); upd(); };
  q('.mc-tg').oninput = q('.mc-nw').oninput = upd;

  // --- openen, sluiten, verbergen ---
  const setOpen = v => { open = v; btn.classList.toggle('on', v); btn.setAttribute('aria-expanded', v); refresh(); if (v) { renderMag(); if (MPOCalc.onWide) MPOCalc.onWide(); } };
  btn.onclick = () => setOpen(!open);
  q('.mc-cl').onclick = () => setOpen(false);
  // Toetsaanslagen in de calculator blijven in de calculator: Magister heeft sneltoetsen. We staan vóór de scripts van de pagina (document_start, capture op window);
  // typen in de invoervelden blijft gewoon werken, want we blokkeren alleen het doorgeven, niet de toets zelf.
  for (const ev of ['keydown', 'keyup', 'keypress']) window.addEventListener(ev, e => {
    if (!e.composedPath().includes(panel)) return;
    e.stopImmediatePropagation();
    if (ev === 'keydown' && e.key === 'Escape') setOpen(false);
  }, true);
  // Niet in beeld tijdens het openen van packs of op het slotscherm, en niet als de extensie uit staat.
  function refresh() {
    const gate = root.querySelector('.gate'), blocked = !enabled || MPO.busy || (gate && !gate.hidden);
    btn.hidden = !!blocked; panel.hidden = !!blocked || !open;
  }
  setInterval(refresh, 250);
  S.get('enabled', v => { enabled = v.enabled !== false; refresh(); });
  chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.enabled) { enabled = c.enabled.newValue !== false; refresh(); } });

  // content.js geeft hier de cijfers door waarvan het pack al open is (of die er al waren), nooit cijfers die nog in een pack zitten
  globalThis.MPOCalc = {
    setGrades(list, pend) { grades = list; pending = pend || 0; if (open) renderMag(); },
    wide: () => open && !panel.hidden,   // paneel open: laat content.js tot 300 cijfers ophalen
    onWide: null,
  };
  renderRows(); renderMag(); upd();
})();
