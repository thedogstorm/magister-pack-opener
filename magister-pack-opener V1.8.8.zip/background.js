// Sturen van geopende packs naar het account op de website. Doet niets zolang er niet is gekoppeld.
importScripts('config.js');
const S = chrome.storage.local;
const get = k => new Promise(r => S.get(k, r));
const set = o => new Promise(r => S.set(o, r));
const site = () => (typeof MPO_SITE === 'string' ? MPO_SITE.replace(/\/+$/, '') : '');
const allowed = async () => !!site() && chrome.permissions.contains({ origins: [new URL(site()).origin + '/*'] });
// Het Magister-id gaat nooit mee: alleen een afgeleid nummer, zodat dezelfde kaart niet dubbel telt.
const hex = async t => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)))].map(b => b.toString(16).padStart(2, '0')).join('');

async function queue(cards) {
  const { acct, outbox = [] } = await get(['acct', 'outbox']);
  if (!acct) return;
  const m = new Map(outbox.map(c => [c.key, c]));
  cards.forEach(c => m.set(c.key, { ...(m.get(c.key) || {}), ...c }));
  await set({ outbox: [...m.values()] });
}
let busy = null;
const flush = () => busy || (busy = doFlush().finally(() => { busy = null; }));
async function doFlush() {
  const { acct, outbox = [] } = await get(['acct', 'outbox']);
  if (!acct || !outbox.length || !(await allowed())) return;
  for (let i = 0; i < outbox.length; i += 200) {
    const batch = outbox.slice(i, i + 200), snap = new Map(batch.map(c => [c.key, JSON.stringify(c)]));
    const r = await fetch(site() + '/api/sync', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + acct.token }, body: JSON.stringify({ cards: batch }) });
    if (r.status === 401) { await set({ acct: null, outbox: [], acctErr: 'De koppeling is verbroken op de website. Koppel opnieuw.' }); return; }
    if (!r.ok) throw new Error('Synchroniseren mislukt (' + r.status + ')');
    const cur = (await get('outbox')).outbox || [];
    await set({ outbox: cur.filter(c => snap.get(c.key) !== JSON.stringify(c)), lastSync: Date.now(), acctErr: '' });
  }
}
async function link(code, details) {
  if (!site()) throw new Error('De website is nog niet ingesteld (config.js).');
  if (!(await allowed())) throw new Error('Geen toestemming voor ' + new URL(site()).host + '.');
  const r = await fetch(site() + '/api/link', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code, name: /Edg\//.test(navigator.userAgent) ? 'Edge' : 'Chrome' }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Koppelen mislukt (' + r.status + ')');
  await set({ acct: { token: j.token, email: j.email, details: !!details }, acctErr: '' });
  const cards = [];   // eerder geopende packs: alleen het niveau
  for (const [k, v] of Object.entries(await get(null))) if (/^s\d+$/.test(k)) for (const [id, t] of Object.entries(v)) cards.push({ key: await hex('mpo:' + k.slice(1) + ':' + id), tier: t });
  await queue(cards); await flush();
}
async function unlink() {
  const { acct } = await get('acct');
  if (acct && (await allowed())) await fetch(site() + '/api/link', { method: 'DELETE', headers: { Authorization: 'Bearer ' + acct.token } }).catch(() => {});
  await set({ acct: null, outbox: [], acctErr: '' });
}
chrome.runtime.onMessage.addListener((m, sender, send) => {
  if (sender.id !== chrome.runtime.id) return;
  (async () => {
    if (m.type === 'card') {
      const { acct } = await get('acct'); if (!acct) return;
      const c = { key: await hex('mpo:' + m.pid + ':' + m.id), tier: m.tier, openedAt: m.openedAt };
      if (acct.details && m.d) Object.assign(c, { vak: m.d.subject, cijfer: m.d.grade, omschrijving: m.d.desc, weging: m.d.weight });
      await queue([c]); await flush().catch(() => {});
    } else if (m.type === 'flush') await flush();
    else if (m.type === 'link') await link(String(m.code || ''), m.details);
    else if (m.type === 'unlink') await unlink();
    else if (m.type === 'details') { const { acct } = await get('acct'); if (acct) await set({ acct: { ...acct, details: !!m.on } }); }
  })().then(() => send({ ok: true }), e => send({ ok: false, error: String(e.message || e) }));
  return true;
});
chrome.runtime.onStartup.addListener(() => flush().catch(() => {}));
