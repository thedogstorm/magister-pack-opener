// Adres van de website waaraan accounts gekoppeld worden, bijvoorbeeld 'https://jouwsite.nl' (zonder / aan het eind).
// Leeg laten = de accountfunctie staat uit en er gaat niets uit de browser naar een server.
const MPO_SITE = '';
