(async () => {
const $ = id => document.getElementById(id);
const el = (t, x, c) => { const e = document.createElement(t); if (x != null) e.textContent = x; if (c) e.className = c; return e; };
const cmp = (a, b) => { const p = a.split('.').map(Number), q = b.split('.').map(Number); for (let i = 0; i < 3; i++) if ((p[i] || 0) !== (q[i] || 0)) return (p[i] || 0) - (q[i] || 0); return 0; };
const VERS = await (await fetch('versions.json')).json();
const CUR = chrome.runtime.getManifest().version;
MPO.setLogo(chrome.runtime.getURL('logo.png'));

// Tabbladen
document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => {
  document.querySelectorAll('.tabs button').forEach(x => x.classList.toggle('on', x === b));
  ['p', 'v', 'n', 't', 'h', 'a'].forEach(id => $(id).hidden = id !== b.dataset.t);
});

// Installatie-instructies achter een knop; vinkjes blijven bewaard
$('insb').onclick = () => {
  const open = $('ins').hidden; $('ins').hidden = !open;
  $('insb').textContent = open ? 'Installatie-instructies verbergen' : 'Installatie-instructies tonen';
  $('insb').setAttribute('aria-expanded', String(open));
};
const boxes = [...document.querySelectorAll('#ins label.s input')];
try { const v = JSON.parse(localStorage.getItem('mpo-steps') || '[]'); boxes.forEach((b, i) => b.checked = !!v[i]); } catch (e) {}
boxes.forEach(b => b.onchange = () => { try { localStorage.setItem('mpo-steps', JSON.stringify(boxes.map(x => x.checked))); } catch (e) {} });

// Paneel
$('lv').textContent = 'v' + CUR;
(VERS.find(x => x.v === CUR) || VERS[0]).notes.forEach(n => $('new').append(el('li', n)));

// Alle versies (alleen tekst: oudere zips zitten niet in de extensie)
VERS.forEach(x => {
  const d = el('details', null, 'ver'); d.open = x.v === CUR;
  const s = el('summary'); s.append(el('b', 'v' + x.v));
  if (x.v === CUR) s.append(el('em', 'Geïnstalleerd'));
  const ul = el('ul'); x.notes.forEach(n => ul.append(el('li', n)));
  const bd = el('div', null, 'bd'); bd.append(ul); d.append(s, bd); $('vl').append(d);
});

// De extensie als zip, op dit moment opgebouwd uit de eigen bestanden
const FILES = ["manifest.json", "inject.js", "overlay.js", "content.js", "popup.html", "popup.js", "panel.html", "panel.css", "panel.js", "tester.js", "versions.json", "background.js", "config.js", "account.js", "logo.png", "icons/icon16.png", "icons/icon32.png", "icons/icon48.png", "icons/icon128.png"];
const crcT = (() => { const t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc = u => { let c = ~0; for (let i = 0; i < u.length; i++) c = crcT[(c ^ u[i]) & 255] ^ (c >>> 8); return ~c >>> 0; };
async function makeZip() {
  const te = new TextEncoder(), parts = [], cd = []; let off = 0;
  for (const f of FILES) {
    const u = new Uint8Array(await (await fetch(chrome.runtime.getURL(f))).arrayBuffer()), n = te.encode(f), c = crc(u);
    const lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(12, 0x21, true);
    lh.setUint32(14, c, true); lh.setUint32(18, u.length, true); lh.setUint32(22, u.length, true); lh.setUint16(26, n.length, true);
    const ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(14, 0x21, true);
    ch.setUint32(16, c, true); ch.setUint32(20, u.length, true); ch.setUint32(24, u.length, true); ch.setUint16(28, n.length, true); ch.setUint32(42, off, true);
    parts.push(lh, n, u); cd.push(ch, n); off += 30 + n.length + u.length;
  }
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, FILES.length, true); end.setUint16(10, FILES.length, true);
  end.setUint32(12, cd.reduce((a, p) => a + p.byteLength, 0), true); end.setUint32(16, off, true);
  return new Blob([...parts, ...cd, end], { type: 'application/zip' });
}
$('dl').onclick = async () => {
  try {
    const a = el('a'); a.href = URL.createObjectURL(await makeZip()); a.download = 'magister-pack-opener_V' + CUR.replace(/\./g, '_') + '.zip';
    document.body.append(a); a.click(); a.remove(); $('msg').textContent = 'Zip gemaakt van versie ' + CUR + '.';
  } catch (e) { $('msg').textContent = 'Zip maken lukte niet: ' + (e.message || e); }
};

// Versiecontrole: leest manifest.json (en versions.json) uit een zip, alles blijft in je browser
async function zipEntry(buf, re) {
  const v = new DataView(buf), u8 = new Uint8Array(buf), td = new TextDecoder();
  let e = -1;
  for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 65557); i--) if (v.getUint32(i, true) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error('Dit is geen zip-bestand.');
  let n = v.getUint16(e + 10, true), p = v.getUint32(e + 16, true);
  for (let k = 0; k < n && v.getUint32(p, true) === 0x02014b50; k++) {
    const m = v.getUint16(p + 10, true), cs = v.getUint32(p + 20, true), fl = v.getUint16(p + 28, true), xl = v.getUint16(p + 30, true), cl = v.getUint16(p + 32, true), off = v.getUint32(p + 42, true);
    if (re.test(td.decode(u8.subarray(p + 46, p + 46 + fl)))) {
      const ds = off + 30 + v.getUint16(off + 26, true) + v.getUint16(off + 28, true), data = u8.subarray(ds, ds + cs);
      return m === 0 ? td.decode(data) : await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
    }
    p += 46 + fl + xl + cl;
  }
  return null;
}
$('vf').onchange = async () => {
  const f = $('vf').files[0], out = $('vr'); out.textContent = ''; if (!f) return;
  const say = (t, c) => out.append(el('p', t, c));
  const list = arr => arr.forEach(x => { out.append(el('h3', 'v' + x.v)); const ul = el('ul'); x.notes.forEach(n => ul.append(el('li', n))); out.append(ul); });
  try {
    const buf = await f.arrayBuffer(), isJson = /\.json$/i.test(f.name);
    const mt = isJson ? new TextDecoder().decode(buf) : await zipEntry(buf, /(^|\/)manifest\.json$/);
    if (!mt) throw new Error('Geen manifest.json in dit bestand gevonden.');
    const m = JSON.parse(mt); if (!m.version) throw new Error('Geen versienummer gevonden.');
    say('Dit bestand: v' + m.version + (m.name ? ' (' + m.name + ')' : ''), 'big2');
    if (m.name && !/pack opener/i.test(m.name)) say('Let op: dit lijkt niet Magister Pack Opener.', 'er');
    const c = cmp(m.version, CUR);
    if (c === 0) say('Dit is dezelfde versie als jouw geïnstalleerde extensie (v' + CUR + ').', 'ok');
    else if (c > 0) {
      say('Deze zip is nieuwer dan jouw geïnstalleerde v' + CUR + '. Installeer hem om te updaten (zie de instructies op het tabblad Paneel).', 'er');
      let nv = VERS; if (!isJson) { try { const vt = await zipEntry(buf, /(^|\/)versions\.json$/); if (vt) nv = JSON.parse(vt); } catch (e) {} }
      const ch = nv.filter(x => cmp(x.v, CUR) > 0 && cmp(x.v, m.version) <= 0).reverse();
      if (ch.length) { say('Dit is er sinds jouw versie veranderd:'); list(ch); } else say('Wat er nieuw is, staat in het bedieningspaneel van die versie.', 'mut');
    } else {
      say('Deze zip is ouder dan jouw geïnstalleerde v' + CUR + '.', 'mut');
      const ch = VERS.filter(x => cmp(x.v, m.version) > 0 && cmp(x.v, CUR) <= 0).reverse();
      if (ch.length) { say('Sinds die versie is veranderd:'); list(ch); }
    }
  } catch (e) { say(e.message || 'Dit bestand kon ik niet lezen.', 'er'); }
};

// ---- Niveaus ----
const TN = [['Common', '#e2474b', -1, 'onder 5,5', 4.8], ['Rare', '#cfd6e3', 5.5, 'vanaf 5,5', 6.4], ['Legendary', '#f5a623', 7, 'vanaf 7', 7.9], ['Mythic', '#8a6cff', 8.5, 'vanaf 8,5', 8.9], ['Icon', '#ffe9a8', 9.5, 'vanaf 9,5', 9.8], ['Perfect', '#f6d675', 10, 'alleen een 10', 10]];
TN.forEach(([n, c, , r, s]) => {
  const row = el('div', null, 'tier'); row.style.setProperty('--c', c);
  const b = el('button', 'Bekijk'); b.onclick = () => { if (!MPO.busy) MPO.open([{ id: 'n' + n, subject: 'Wiskunde', desc: 'Voorbeeld', weight: 2, grade: s }]); };
  row.append(el('b', n), el('span', r), b); $('tl').append(row);
});
$('cg').oninput = () => {
  const g = parseFloat($('cg').value.replace(',', '.')), r = $('cr');
  if (!(g >= 1 && g <= 10)) { r.textContent = ''; return; }
  const t = TN.reduce((k, x, i) => g >= x[2] ? i : k, 0); r.textContent = TN[t][0]; r.style.color = TN[t][1];
};

// ---- Hulp bij foutmeldingen ----
const HELP = [
  [/API\s*401|\b401\b/, 'API 401: niet ingelogd of sessie verlopen', 'De extensie leest het inlogtoken uit Magister zelf. Is dat verlopen of nog niet geladen, dan weigert Magister het. Herlaad Magister (F5) en log zo nodig opnieuw in. De extensie probeert het daarna vanzelf opnieuw.'],
  [/API\s*403|\b403\b/, 'API 403: geen toegang', 'Magister laat dit account de cijfers niet ophalen. Meestal zit je in het verkeerde profiel (bijvoorbeeld een ouderaccount) of heeft de school het uitgezet. Log in als leerling.'],
  [/API\s*404|\b404\b/, 'API 404: niet gevonden', 'Magister kent het opgevraagde adres niet. Mogelijk gebruikt je school een andere Magister-versie of is er iets veranderd. Check op het tabblad Versies of je de nieuwste versie hebt.'],
  [/API\s*429|\b429\b/, 'API 429: te veel verzoeken', 'Magister vindt dat er te vaak gevraagd is. Wacht een paar minuten en herlaad dan Magister.'],
  [/API\s*5\d\d|\b50[0-4]\b/, 'API 500, 502 of 503: storing bij Magister', 'Het probleem zit bij Magister of je school, niet bij de extensie. Probeer het later opnieuw.'],
  [/failed to fetch|network/i, 'Failed to fetch: geen verbinding', 'De extensie kon Magister niet bereiken. Controleer je internet, vpn of een adblocker of schoolfilter die magister.net blokkeert.'],
  [/synchroniseren/i, 'Open Magister om te synchroniseren', 'De extensie heeft nog niets opgehaald. Open magister.net in een tabblad en log in; de cijfers worden dan vanzelf opgehaald.'],
  [/open eerst|tabblad/i, 'Open eerst Magister in een tabblad', '“Oude cijfers ook als packs” werkt alleen als er een Magister-tabblad open staat. Open Magister en druk daarna opnieuw op de knop.'],
  [/verschijnt niet|geen scherm|geen pack|niets/i, 'Het packs-scherm verschijnt niet', 'Check of Pack Opener in de popup aanstaat. Nieuwe cijfers worden elke 30 seconden gezocht, dus wacht even of herlaad Magister. Alleen cijfers van 1 t/m 10 worden een pack; letters en V/G niet. Heb je een oudere versie? Update naar de nieuwste.'],
  [/controleren|hangt|blijft/i, '“Cijfers controleren…” blijft staan', 'Dat scherm verdwijnt vanzelf na maximaal 6 seconden. Blijft het langer staan, herlaad dan de pagina en update naar de nieuwste versie.'],
  [/weg|kwijt|verdwenen|bijgewerkt|update|leeg/i, 'Mijn statistieken zijn weg na een update', 'Chrome bewaart de gegevens per geïnstalleerde extensie. Verwijder je de extensie, of laad je de nieuwe versie uit een andere map, dan begin je met een lege teller. Update daarom in dezelfde map en klik op vernieuwen (↻), of maak eerst een back-up via Mijn statistieken en zet die terug na het installeren.'],
  [/startpagina|laatste cijfers|widget|kaart/i, 'Mijn cijfers staan nog zichtbaar op de startpagina', 'De extensie zoekt de kaart op de kop “Laatste cijfers” of “Cijferoverzicht” en verbergt hem zolang er packs klaarstaan. Heeft de kaart een andere kop, of toont een andere extensie je cijfers op een andere manier, dan wordt hij niet herkend. Klik dan met de rechtermuisknop op die kaart, kies Inspecteren en stuur de HTML door, dan kan hij worden toegevoegd.'],
  [/statistiek|dubbel|totaal|klopt niet/i, 'Mijn statistieken kloppen niet', 'Elk cijfer telt één keer mee, ook als je het opnieuw als pack opent. Packs van vóór versie 1.8.2 tellen alleen mee als ze in je laatste 50 cijfers staan.'],
];
HELP.forEach(([re, t, d]) => { const x = el('details', null, 'ver'), s = el('summary'), bd = el('div', null, 'bd'); s.append(el('b', t)); bd.append(el('p', d)); x.append(s, bd); x._re = re; x._t = (t + ' ' + d).toLowerCase(); $('hl').append(x); });
$('hq').oninput = () => {
  const q = $('hq').value.trim(); let hit = 0;
  [...$('hl').children].forEach(x => { const m = !q || x._re.test(q) || x._t.includes(q.toLowerCase()); x.hidden = !m; x.open = !!q && m; if (q && m) hit++; });
  $('hn').hidden = !(q && !hit);
};


if (location.hash === '#account') document.querySelector('.tabs [data-t=a]').click();
})();
