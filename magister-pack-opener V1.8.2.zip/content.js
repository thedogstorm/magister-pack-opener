(() => {
const S = chrome.storage.local;
const get = k => new Promise(r => S.get(k, r));
const set = o => new Promise(r => S.set(o, r));
const sleep = ms => new Promise(r => setTimeout(r, ms));
let packs = [], pid = null, syncing = false, dismissed = false, enabled = true;

// Zolang we nog niet zeker weten of er packs klaarstaan, dekken we de cijferpagina af (hooguit GUARD ms).
const FRESH = 45000, GUARD = 6000;
let init = false, loaded = false, lastOk = 0, hint = 0, until = Date.now() + GUARD, navUntil = 0, wasGrades = false;
let firstDone;
const first = new Promise(r => firstDone = r);

const realGrades = () => /cijfers/i.test(location.href);
const isGrades = () => realGrades() || Date.now() < navUntil;   // navUntil: net op "cijfers" geklikt, URL volgt zo
const stale = () => Date.now() - lastOk > FRESH;
const tok = () => document.documentElement.dataset.mpoTok || '';

// Roept de Magister-API aan met het token dat de pagina zelf al gebruikt (inject.js).
async function api(path) {
  for (let i = 0; i < 40 && !tok(); i++) await sleep(500);
  const r = await fetch(path, { headers: { Authorization: 'Bearer ' + tok() } });
  if (r.status === 401) delete document.documentElement.dataset.mpoTok;
  if (!r.ok) throw new Error('API ' + r.status + ' ' + path.split('?')[0]);
  return r.json();
}

const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const norm = g => {
  const n = parseFloat(String(g.waarde).replace(',', '.')), v = g.vak || {};
  return n >= 1 && n <= 10
    ? { id: String(g.kolomId ?? `${v.code}|${g.omschrijving}|${g.ingevoerdOp}`), subject: cap(v.omschrijving || v.code || 'Vak'), desc: g.omschrijving || '', weight: g.weegfactor, grade: n, at: g.ingevoerdOp || '' }
    : null;
};

// Statistieken: per cijfer-id alleen het niveau (0-5), nooit het cijfer zelf.
// Omdat het per id is opgeslagen, kan een cijfer maar één keer meetellen, ook niet na "oude cijfers ook als packs".
async function addStats(list) {
  const sk = 's' + pid, st = (await get(sk))[sk] || {};
  let ch = false;
  for (const [id, t] of list) if (st[id] !== t) { st[id] = t; ch = true; }
  if (ch) await set({ [sk]: st });
}

// Alleen de id's van geopende cijfers worden bewaard, nooit de cijfers zelf.
let again = false, lastCount = 0;
async function sync() {
  if (syncing) { again = true; return; }
  if (!enabled) return;
  syncing = true;
  try {
    if (!pid) { const a = await api('/api/account'), pe = a.Persoon || a.persoon || {}; pid = pe.Id ?? pe.id; }
    const key = 'u' + pid, rq = (await get('requeue')).requeue;
    // Gewoon: de laatste 50. Bij "ook oude cijfers": tot 300 cijfers.
    let items = [];
    for (let sk = 0; sk < (rq ? 300 : 50); sk += 50) {
      const d = await api(`/api/personen/${pid}/cijfers/laatste?top=50&skip=${sk}`), page = d.items || d.Items || [];
      items = items.concat(page.map(norm).filter(Boolean));
      if (page.length < 50) break;
    }
    items = [...new Map(items.map(x => [x.id, x])).values()];
    let u = (await get(key))[key];
    if (u) await addStats(items.filter(x => u.opened.includes(x.id)).map(x => [x.id, MPO.tierOf(x.grade)]));   // eerder geopende packs meetellen
    if (!u) u = { base: rq ? [] : items.map(x => x.id), opened: [] };  // eerste keer: bestaande cijfers overslaan, tenzij je ze wilt
    else if (rq) { u.base = []; u.opened = []; }   // opnieuw: ook al geopende cijfers worden weer packs
    await set({ [key]: u });
    if (rq) { if ((await get('requeue')).requeue === rq) await set({ requeue: 0 }); dismissed = false; }   // een nieuwere klik tijdens het ophalen blijft staan
    packs = items.filter(x => !u.base.includes(x.id) && !u.opened.includes(x.id)).sort((a, b) => a.at < b.at ? -1 : 1);
    if (packs.length > lastCount) dismissed = false;
    lastCount = packs.length;
    loaded = true; lastOk = Date.now(); hint = packs.length;
    await set({ pending: packs.length, school: location.hostname, synced: Date.now(), err: '', lastPid: pid });
  } catch (e) {
    console.warn('[Pack Opener]', e);
    until = 0;   // ophalen mislukt: niet eindeloos afdekken
    await set({ err: String(e.message || e) });
  } finally {
    syncing = false;
    firstDone();
    ui();
    if (again) { again = false; sync(); }
  }
}

const h = s => { const t = document.createElement('template'); t.innerHTML = s; return t.content.firstElementChild; };
const gate = h('<div class="gate" hidden><div><div class="gi">' + MPO.logo('gi') + '</div><h2></h2><p>Je cijfers blijven verborgen tot je ze uit een pack haalt.</p><button class="nx">Pack openen</button><button class="gh"></button></div></div>');
const pill = h('<button class="pill" hidden></button>');
MPO.root.append(gate, pill);
const q = (e, s) => e.querySelector(s);

// Het logo uit de map van de extensie; lukt dat niet, dan blijft het ingebouwde exemplaar.
const probe = u => new Promise(r => { const i = new Image(); i.onload = () => r(u); i.onerror = () => r(null); i.src = u; });
(async () => {
  const u = await probe(chrome.runtime.getURL('logo.png'));
  if (u) { MPO.setLogo(u); q(gate, '.gi').innerHTML = MPO.logo('gi'); }
})();

let last = '';
function ui() {
  if (!init) return;
  const g = isGrades(), live = Date.now() < until;
  // Voor de eerste sync gebruiken we het aantal van de vorige keer, zodat het scherm er meteen staat.
  const n = loaded ? packs.length : (live ? hint : 0);
  const have = enabled && n > 0 && !MPO.busy;
  // Nog niet (recent) gecontroleerd en we staan op cijfers: eerst afdekken, dan pas kijken.
  const check = enabled && g && !MPO.busy && n === 0 && live && (!loaded || stale());
  const show = (have && (g || !dismissed)) || check;
  const sig = [show, have && !show, check, n, realGrades(), MPO.busy].join();
  if (sig === last) return;
  last = sig;
  gate.hidden = !show;
  pill.hidden = !(have && !show);
  q(gate, 'h2').textContent = check ? 'Cijfers controleren\u2026' : n === 1 ? 'Nieuw cijfer!' : n + ' nieuwe cijfers!';
  q(gate, 'p').hidden = q(gate, '.nx').hidden = q(gate, '.gh').hidden = check;
  q(gate, '.gh').textContent = realGrades() ? 'Terug' : 'Later';
  pill.textContent = n + (n === 1 ? ' pack klaar' : ' packs klaar');
}

// Reageer meteen op navigatie, niet pas bij de volgende tik van de timer.
function nav() {
  if (!init) return;
  const g = isGrades();
  if (g && !wasGrades) {
    until = Date.now() + GUARD;
    if (stale()) sync();   // vers bekijken of er nieuwe cijfers zijn
  }
  wasGrades = g;
  ui();
}

async function openPacks() {
  if (!loaded) await first;   // te snel geklikt: wacht tot de cijfers zijn opgehaald
  if (MPO.busy) return;       // dubbel klikken: er loopt al een pack-opening
  if (!packs.length) { ui(); return; }
  await MPO.open([...packs], async p => {
    const key = 'u' + pid, u = (await get(key))[key] || { base: [], opened: [] };
    if (!u.opened.includes(p.id)) u.opened.push(p.id);
    packs = packs.filter(x => x.id !== p.id);
    lastCount = packs.length;
    await set({ [key]: u, pending: packs.length });
    await addStats([[p.id, MPO.tierOf(p.grade)]]);
  });
  ui();
}

q(gate, '.nx').onclick = openPacks;
pill.onclick = openPacks;
q(gate, '.gh').onclick = () => { if (realGrades()) history.back(); else { dismissed = true; ui(); } };

get(['enabled', 'pending']).then(v => {
  enabled = v.enabled !== false;
  hint = v.pending || 0;
  init = true;
  wasGrades = isGrades();
  ui();
  sync();
});
chrome.storage.onChanged.addListener(c => {
  if (c.enabled) enabled = c.enabled.newValue !== false;
  if (c.enabled || (c.requeue && c.requeue.newValue)) sync();
});

window.addEventListener('hashchange', nav);
window.addEventListener('popstate', nav);
window.addEventListener('mpo-nav', nav);   // pushState/replaceState, doorgegeven door inject.js
// Al bij de klik op "Cijfers" afdekken, nog voordat Magister zijn pagina opbouwt.
document.addEventListener('click', e => {
  const a = e.target && e.target.closest && e.target.closest('a[href]');
  if (a && /cijfers/i.test(a.getAttribute('href') || '')) { navUntil = Date.now() + 1500; nav(); }
}, true);
document.addEventListener('visibilitychange', () => { if (!document.hidden && stale()) sync(); });
setInterval(nav, 200);
setInterval(() => { if (!document.hidden && !MPO.busy) sync(); }, 30000);
})();
