const $ = s => document.querySelector(s), S = chrome.storage.local;
const load = cb => S.get(['enabled', 'pending', 'school', 'synced', 'err', 'requeue'], cb);
const show = v => {
  $('#n').textContent = v.pending || 0;
  const st = $('#st');
  st.className = v.err ? 'err' : '';
  st.textContent = v.err ? 'Kon cijfers niet ophalen: ' + v.err : v.synced ? v.school : 'Open Magister om te synchroniseren.';
};
load(v => { $('#on').checked = v.enabled !== false; show(v); });
$('#on').onchange = e => S.set({ enabled: e.target.checked });
$('#rq').onclick = () => {
  const b = $('#rq'), st = $('#st');
  b.disabled = true; st.className = ''; st.textContent = 'Bezig\u2026';
  S.set({ requeue: Date.now() });   // een nieuwe waarde per klik, zodat elke klik opgepikt wordt
  let t = 0;
  const iv = setInterval(() => load(v => {
    if (!v.requeue) { clearInterval(iv); b.disabled = false; show(v); }
    else if (++t > 16) { clearInterval(iv); b.disabled = false; st.textContent = 'Open eerst Magister in een tabblad. Zodra die geladen is, worden je oude cijfers als packs klaargezet.'; }
  }), 500);
};

// Statistieken
const TN = [['Common', '#e2474b'], ['Rare', '#cfd6e3'], ['Legendary', '#f5a623'], ['Mythic', '#8a6cff'], ['Icon', '#ffe9a8'], ['Perfect', '#f6d675']];
const view = on => { $('#main').hidden = on; $('#stats').hidden = !on; };
$('#stb').onclick = () => S.get('lastPid', r => {
  const k = 's' + r.lastPid;
  S.get(k, d => {
    const m = r.lastPid === undefined ? {} : d[k] || {}, c = TN.map(() => 0);
    Object.values(m).forEach(t => { if (c[t] !== undefined) c[t]++; });
    const tot = c.reduce((a, b) => a + b, 0), hi = c.reduce((a, n, i) => n ? i : a, -1);
    $('#tot').textContent = tot;
    $('#best').textContent = tot ? 'Zeldzaamste: ' + TN[hi][0] : 'Nog geen packs geopend.';
    const box = $('#tiers'); box.textContent = '';
    TN.forEach(([name, col], i) => {
      const r = document.createElement('div'); r.className = 'tr'; r.style.setProperty('--c', col);
      r.innerHTML = '<span></span><i><u></u></i><b></b>';
      r.children[0].textContent = name; r.children[2].textContent = c[i];
      r.querySelector('u').style.width = tot ? (c[i] / tot * 100) + '%' : '0';
      box.append(r);
    });
    view(true);
  });
});
$('#back').onclick = () => view(false);

// Bedieningspaneel: de online pagina, die altijd de nieuwste versies toont.
const SITE = '';   // zet hier het adres van je eigen website, bijv. 'https://jouwnaam.netlify.app'
const ARTIFACT = 'https://claude.ai/artifact/2xoSGbZmCetooDdPkbgUXa';   // tijdelijk, zolang SITE leeg is
const PANEL = SITE || ARTIFACT;
const VER = chrome.runtime.getManifest().version;
$('#ver').textContent = 'Versie ' + VER;
// Het versienummer gaat mee in de link (#v1-8-3), zodat het paneel kan zien of je een nieuwere versie kunt downloaden.
$('#cp').onclick = () => chrome.tabs.create({ url: PANEL + '#v' + VER.replace(/\./g, '-') });

// Back-up en terugzetten: statistieken en welke packs al open zijn. Terugzetten voegt samen, dus nooit dubbel tellen.
const keep = k => /^(s|u)\d+$/.test(k);
const enc = t => { let b = ''; new TextEncoder().encode(t).forEach(c => b += String.fromCharCode(c)); return btoa(b); };
const dec = c => new TextDecoder().decode(Uint8Array.from(atob(c), x => x.charCodeAt(0)));
const bm = t => { $('#bm').textContent = t; };
$('#bk').onclick = () => S.get(null, all => {
  const data = {}; Object.keys(all).filter(keep).forEach(k => data[k] = all[k]);
  const code = 'MPO1:' + enc(JSON.stringify(data));
  $('#rt').value = code; $('#bx').hidden = false;
  navigator.clipboard.writeText(code).then(() => bm('Back-up gekopieerd. Bewaar de code ergens veilig.'), () => bm('Kopieer de code hieronder zelf en bewaar hem veilig.'));
});
$('#rs').onclick = () => { $('#bx').hidden = false; $('#rt').value = ''; $('#rt').focus(); bm('Plak je back-upcode en kies “Zet terug”.'); };
$('#rs2').onclick = () => {
  let data;
  try { const c = $('#rt').value.replace(/\s+/g, ''); if (!c.startsWith('MPO1:')) throw 0; data = JSON.parse(dec(c.slice(5))); } catch (e) { bm('Dit is geen geldige back-upcode.'); return; }
  S.get(null, cur => {
    const out = {}; let best = -1, bp;
    for (const [k, v] of Object.entries(data)) {
      if (!keep(k) || !v || typeof v !== 'object') continue;
      if (k[0] === 's') {
        const m = { ...(cur[k] || {}) };
        for (const [id, t] of Object.entries(v)) if (Number.isInteger(t) && t >= 0 && t < 6) m[id] = t;
        out[k] = m; const n = Object.keys(m).length; if (n > best) { best = n; bp = k.slice(1); }
      } else if (Array.isArray(v.base) && Array.isArray(v.opened)) {
        const c = cur[k] || { base: [], opened: [] };
        out[k] = { base: [...new Set([...c.base, ...v.base.map(String)])], opened: [...new Set([...c.opened, ...v.opened.map(String)])] };
      }
    }
    if (!Object.keys(out).length) { bm('Geen gegevens gevonden in deze code.'); return; }
    if (cur.lastPid === undefined && bp) out.lastPid = Number(bp);
    S.set(out, () => { bm('Teruggezet. Elk cijfer telt nog steeds maar één keer.'); $('#bx').hidden = true; $('#stb').click(); });
  });
};
